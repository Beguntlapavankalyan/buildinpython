import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_parquet_using_full_path,
                                            write_parquet_or_csv, write_txt)
from pyspark.sql import functions as F
from pyspark.sql.functions import col, concat_ws, rpad, trim, when

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

# @params: [JOB_NAME]
args = getResolvedOptions(
    sys.argv,
    ["lnk_Veh_standard_outputpath", "ds_standard_vehicle", "Vehicle_Standard"],
)

lnk_Veh_standard_outputpath = args["lnk_Veh_standard_outputpath"]
ds_standard_vehicle = args["ds_standard_vehicle"]
Vehicle_Standard = args["Vehicle_Standard"]

logging.info("Reading ds_standard_vehicle file")
lnk_filteredf = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=ds_standard_vehicle,
    force_spark_read=True,
)

lnk_filter = lnk_filteredf.select(
    F.col("SEQ_NO").cast("string").substr(1, 20).alias("SEQ_NO"),
    trim(F.col("COUNT").cast("string").substr(1, 2)).alias("COUNT"),
    F.col("MANUFACTURER").cast("string").substr(1, 40).alias("MANUFACTURER"),
    F.col("MODEL_YR").cast("string").substr(1, 4).alias("MODEL_YR"),
    F.col("MAKE_TXT").cast("string").substr(1, 50).alias("MAKE_TXT"),
    F.col("MODEL_TXT").cast("string").substr(1, 50).alias("MODEL_TXT"),
    F.col("TRIM_TXT").cast("string").substr(1, 150).alias("TRIM_TXT"),
    F.col("MODEL_CLASS_TXT").cast("string").substr(1, 35).alias("MODEL_CLASS_TXT"),
    F.col("ACTIVITY_DATE").cast("string").substr(1, 10).alias("ACTIVITY_DATE"),
    F.col("DISPOSAL_DATE").cast("string").substr(1, 10).alias("DISPOSAL_DATE"),
    F.col("REGISTRATION_STATUS")
    .cast("string")
    .substr(1, 1)
    .alias("REGISTRATION_STATUS"),
    F.col("PURCHASE_FLAG").cast("string").substr(1, 1).alias("PURCHASE_FLAG"),
    F.col("VEHICLE_FLAG").cast("string").substr(1, 1).alias("VEHICLE_FLAG"),
    F.col("BNBU").cast("string").substr(1, 1).alias("BNBU"),
    F.col("IMPORT").cast("string").substr(1, 2).alias("IMPORT"),
    F.col("HOUSEHOLD").cast("string").substr(1, 1).alias("HOUSEHOLD"),
    F.col("HH_BNBU").cast("string").substr(1, 1).alias("HH_BNBU"),
)

logging.info("Filtering for rows where SEQ_NO is not empty")
output_link_0 = lnk_filter.filter(col("SEQ_NO") != "")
all_SeqNum = output_link_0.select("SEQ_NO")


def create_layout(lnk_filter, count):
    # Define the base columns that are always included
    base_columns = [
        "SEQ_NO",
        "MANUFACTURER",
        "MODEL_YR",
        "MAKE_TXT",
        "MODEL_TXT",
        "TRIM_TXT",
        "MODEL_CLASS_TXT",
        "ACTIVITY_DATE",
        "DISPOSAL_DATE",
        "REGISTRATION_STATUS",
        "PURCHASE_FLAG",
        "VEHICLE_FLAG",
        "BNBU",
        "IMPORT",
    ]
    # Add "HH_BNBU" only for the first DataFrame
    if count == 1:
        columns = base_columns + ["HH_BNBU"]
    else:
        columns = base_columns

    logging.info("Construct the select expression with conditional aliasing")
    return lnk_filter.filter(F.col("COUNT") == str(count)).select(
        *[
            (
                F.col(col_name).alias(f"{col_name}_{count}")
                if col_name != "SEQ_NO"
                else F.col("SEQ_NO").alias("SEQ_NO")
            )
            for col_name in columns
        ]
    )


output_links = [create_layout(lnk_filter, count) for count in range(1, 12)]

Unique_SeqNum = all_SeqNum.dropDuplicates(["SEQ_NO"])

jn_seqNum = Unique_SeqNum.select("SEQ_NO")
jn_seqNum_count = len(jn_seqNum.columns)

# Initialize joined_df with jn_seqNum
logging.info("Joining the DataFrames")
joined_df = jn_seqNum
veh_unique_seqNum = Unique_SeqNum.select("SEQ_NO")
dfs = output_links

for i, df in enumerate(dfs, start=1):
    joined_df = joined_df.join(df.alias(f"lnk_layout_{i}"), ["SEQ_NO"], "left")

logging.info("Renaming the column 'HH_BNBU_1' to 'HH_BNBU'")
joined_df = joined_df.withColumnRenamed("HH_BNBU_1", "HH_BNBU")

lnk_Veh_standard = joined_df.select(joined_df["*"])

columnslength = {
    "SEQ_NO": 20,
    "MANUFACTURER_1": 40,
    "MODEL_YR_1": 4,
    "MAKE_TXT_1": 50,
    "MODEL_TXT_1": 50,
    "TRIM_TXT_1": 150,
    "MODEL_CLASS_TXT_1": 35,
    "ACTIVITY_DATE_1": 10,
    "DISPOSAL_DATE_1": 10,
    "REGISTRATION_STATUS_1": 1,
    "PURCHASE_FLAG_1": 1,
    "VEHICLE_FLAG_1": 1,
    "BNBU_1": 1,
    "IMPORT_1": 2,
    "MANUFACTURER_2": 40,
    "MODEL_YR_2": 4,
    "MAKE_TXT_2": 50,
    "MODEL_TXT_2": 50,
    "TRIM_TXT_2": 150,
    "MODEL_CLASS_TXT_2": 35,
    "ACTIVITY_DATE_2": 10,
    "DISPOSAL_DATE_2": 10,
    "REGISTRATION_STATUS_2": 1,
    "PURCHASE_FLAG_2": 1,
    "VEHICLE_FLAG_2": 1,
    "BNBU_2": 1,
    "IMPORT_2": 2,
    "MANUFACTURER_3": 40,
    "MODEL_YR_3": 4,
    "MAKE_TXT_3": 50,
    "MODEL_TXT_3": 50,
    "TRIM_TXT_3": 150,
    "MODEL_CLASS_TXT_3": 35,
    "ACTIVITY_DATE_3": 10,
    "DISPOSAL_DATE_3": 10,
    "REGISTRATION_STATUS_3": 1,
    "PURCHASE_FLAG_3": 1,
    "VEHICLE_FLAG_3": 1,
    "BNBU_3": 1,
    "IMPORT_3": 2,
    "MANUFACTURER_4": 40,
    "MODEL_YR_4": 4,
    "MAKE_TXT_4": 50,
    "MODEL_TXT_4": 50,
    "TRIM_TXT_4": 150,
    "MODEL_CLASS_TXT_4": 35,
    "ACTIVITY_DATE_4": 10,
    "DISPOSAL_DATE_4": 10,
    "REGISTRATION_STATUS_4": 1,
    "PURCHASE_FLAG_4": 1,
    "VEHICLE_FLAG_4": 1,
    "BNBU_4": 1,
    "IMPORT_4": 2,
    "MANUFACTURER_5": 40,
    "MODEL_YR_5": 4,
    "MAKE_TXT_5": 50,
    "MODEL_TXT_5": 50,
    "TRIM_TXT_5": 150,
    "MODEL_CLASS_TXT_5": 35,
    "ACTIVITY_DATE_5": 10,
    "DISPOSAL_DATE_5": 10,
    "REGISTRATION_STATUS_5": 1,
    "PURCHASE_FLAG_5": 1,
    "VEHICLE_FLAG_5": 1,
    "BNBU_5": 1,
    "IMPORT_5": 2,
    "MANUFACTURER_6": 40,
    "MODEL_YR_6": 4,
    "MAKE_TXT_6": 50,
    "MODEL_TXT_6": 50,
    "TRIM_TXT_6": 150,
    "MODEL_CLASS_TXT_6": 35,
    "ACTIVITY_DATE_6": 10,
    "DISPOSAL_DATE_6": 10,
    "REGISTRATION_STATUS_6": 1,
    "PURCHASE_FLAG_6": 1,
    "VEHICLE_FLAG_6": 1,
    "BNBU_6": 1,
    "IMPORT_6": 2,
    "MANUFACTURER_7": 40,
    "MODEL_YR_7": 4,
    "MAKE_TXT_7": 50,
    "MODEL_TXT_7": 50,
    "TRIM_TXT_7": 150,
    "MODEL_CLASS_TXT_7": 35,
    "ACTIVITY_DATE_7": 10,
    "DISPOSAL_DATE_7": 10,
    "REGISTRATION_STATUS_7": 1,
    "PURCHASE_FLAG_7": 1,
    "VEHICLE_FLAG_7": 1,
    "BNBU_7": 1,
    "IMPORT_7": 2,
    "MANUFACTURER_8": 40,
    "MODEL_YR_8": 4,
    "MAKE_TXT_8": 50,
    "MODEL_TXT_8": 50,
    "TRIM_TXT_8": 150,
    "MODEL_CLASS_TXT_8": 35,
    "ACTIVITY_DATE_8": 10,
    "DISPOSAL_DATE_8": 10,
    "REGISTRATION_STATUS_8": 1,
    "PURCHASE_FLAG_8": 1,
    "VEHICLE_FLAG_8": 1,
    "BNBU_8": 1,
    "IMPORT_8": 2,
    "MANUFACTURER_9": 40,
    "MODEL_YR_9": 4,
    "MAKE_TXT_9": 50,
    "MODEL_TXT_9": 50,
    "TRIM_TXT_9": 150,
    "MODEL_CLASS_TXT_9": 35,
    "ACTIVITY_DATE_9": 10,
    "DISPOSAL_DATE_9": 10,
    "REGISTRATION_STATUS_9": 1,
    "PURCHASE_FLAG_9": 1,
    "VEHICLE_FLAG_9": 1,
    "BNBU_9": 1,
    "IMPORT_9": 2,
    "MANUFACTURER_10": 40,
    "MODEL_YR_10": 4,
    "MAKE_TXT_10": 50,
    "MODEL_TXT_10": 50,
    "TRIM_TXT_10": 150,
    "MODEL_CLASS_TXT_10": 35,
    "ACTIVITY_DATE_10": 10,
    "DISPOSAL_DATE_10": 10,
    "REGISTRATION_STATUS_10": 1,
    "PURCHASE_FLAG_10": 1,
    "VEHICLE_FLAG_10": 1,
    "BNBU_10": 1,
    "IMPORT_10": 2,
    "MANUFACTURER_11": 40,
    "MODEL_YR_11": 4,
    "MAKE_TXT_11": 50,
    "MODEL_TXT_11": 50,
    "TRIM_TXT_11": 150,
    "MODEL_CLASS_TXT_11": 35,
    "ACTIVITY_DATE_11": 10,
    "DISPOSAL_DATE_11": 10,
    "REGISTRATION_STATUS_11": 1,
    "PURCHASE_FLAG_11": 1,
    "VEHICLE_FLAG_11": 1,
    "BNBU_11": 1,
    "IMPORT_11": 2,
    "HH_BNBU": 1,
}

for column in lnk_Veh_standard.columns:
    lnk_Veh_standard = lnk_Veh_standard.withColumn(
        column, when(col(column).isNull(), "").otherwise(col(column))
    )

for col_name, length in columnslength.items():
    lnk_Veh_standard = lnk_Veh_standard.withColumn(
        col_name, rpad(lnk_Veh_standard[col_name].cast("string"), length, " ")
    )

lnk_Veh_standard_csv = lnk_Veh_standard

Vehicle_Standard11 = lnk_Veh_standard.withColumn(
    "concatenated_data",
    concat_ws(
        "",
        "SEQ_NO",
        "MANUFACTURER_1",
        "MODEL_YR_1",
        "MAKE_TXT_1",
        "MODEL_TXT_1",
        "TRIM_TXT_1",
        "MODEL_CLASS_TXT_1",
        "ACTIVITY_DATE_1",
        "DISPOSAL_DATE_1",
        "REGISTRATION_STATUS_1",
        "PURCHASE_FLAG_1",
        "VEHICLE_FLAG_1",
        "BNBU_1",
        "IMPORT_1",
        "MANUFACTURER_2",
        "MODEL_YR_2",
        "MAKE_TXT_2",
        "MODEL_TXT_2",
        "TRIM_TXT_2",
        "MODEL_CLASS_TXT_2",
        "ACTIVITY_DATE_2",
        "DISPOSAL_DATE_2",
        "REGISTRATION_STATUS_2",
        "PURCHASE_FLAG_2",
        "VEHICLE_FLAG_2",
        "BNBU_2",
        "IMPORT_2",
        "MANUFACTURER_3",
        "MODEL_YR_3",
        "MAKE_TXT_3",
        "MODEL_TXT_3",
        "TRIM_TXT_3",
        "MODEL_CLASS_TXT_3",
        "ACTIVITY_DATE_3",
        "DISPOSAL_DATE_3",
        "REGISTRATION_STATUS_3",
        "PURCHASE_FLAG_3",
        "VEHICLE_FLAG_3",
        "BNBU_3",
        "IMPORT_3",
        "MANUFACTURER_4",
        "MODEL_YR_4",
        "MAKE_TXT_4",
        "MODEL_TXT_4",
        "TRIM_TXT_4",
        "MODEL_CLASS_TXT_4",
        "ACTIVITY_DATE_4",
        "DISPOSAL_DATE_4",
        "REGISTRATION_STATUS_4",
        "PURCHASE_FLAG_4",
        "VEHICLE_FLAG_4",
        "BNBU_4",
        "IMPORT_4",
        "MANUFACTURER_5",
        "MODEL_YR_5",
        "MAKE_TXT_5",
        "MODEL_TXT_5",
        "TRIM_TXT_5",
        "MODEL_CLASS_TXT_5",
        "ACTIVITY_DATE_5",
        "DISPOSAL_DATE_5",
        "REGISTRATION_STATUS_5",
        "PURCHASE_FLAG_5",
        "VEHICLE_FLAG_5",
        "BNBU_5",
        "IMPORT_5",
        "MANUFACTURER_6",
        "MODEL_YR_6",
        "MAKE_TXT_6",
        "MODEL_TXT_6",
        "TRIM_TXT_6",
        "MODEL_CLASS_TXT_6",
        "ACTIVITY_DATE_6",
        "DISPOSAL_DATE_6",
        "REGISTRATION_STATUS_6",
        "PURCHASE_FLAG_6",
        "VEHICLE_FLAG_6",
        "BNBU_6",
        "IMPORT_6",
        "MANUFACTURER_7",
        "MODEL_YR_7",
        "MAKE_TXT_7",
        "MODEL_TXT_7",
        "TRIM_TXT_7",
        "MODEL_CLASS_TXT_7",
        "ACTIVITY_DATE_7",
        "DISPOSAL_DATE_7",
        "REGISTRATION_STATUS_7",
        "PURCHASE_FLAG_7",
        "VEHICLE_FLAG_7",
        "BNBU_7",
        "IMPORT_7",
        "MANUFACTURER_8",
        "MODEL_YR_8",
        "MAKE_TXT_8",
        "MODEL_TXT_8",
        "TRIM_TXT_8",
        "MODEL_CLASS_TXT_8",
        "ACTIVITY_DATE_8",
        "DISPOSAL_DATE_8",
        "REGISTRATION_STATUS_8",
        "PURCHASE_FLAG_8",
        "VEHICLE_FLAG_8",
        "BNBU_8",
        "IMPORT_8",
        "MANUFACTURER_9",
        "MODEL_YR_9",
        "MAKE_TXT_9",
        "MODEL_TXT_9",
        "TRIM_TXT_9",
        "MODEL_CLASS_TXT_9",
        "ACTIVITY_DATE_9",
        "DISPOSAL_DATE_9",
        "REGISTRATION_STATUS_9",
        "PURCHASE_FLAG_9",
        "VEHICLE_FLAG_9",
        "BNBU_9",
        "IMPORT_9",
        "MANUFACTURER_10",
        "MODEL_YR_10",
        "MAKE_TXT_10",
        "MODEL_TXT_10",
        "TRIM_TXT_10",
        "MODEL_CLASS_TXT_10",
        "ACTIVITY_DATE_10",
        "DISPOSAL_DATE_10",
        "REGISTRATION_STATUS_10",
        "PURCHASE_FLAG_10",
        "VEHICLE_FLAG_10",
        "BNBU_10",
        "IMPORT_10",
        "MANUFACTURER_11",
        "MODEL_YR_11",
        "MAKE_TXT_11",
        "MODEL_TXT_11",
        "TRIM_TXT_11",
        "MODEL_CLASS_TXT_11",
        "ACTIVITY_DATE_11",
        "DISPOSAL_DATE_11",
        "REGISTRATION_STATUS_11",
        "PURCHASE_FLAG_11",
        "VEHICLE_FLAG_11",
        "BNBU_11",
        "IMPORT_11",
        "HH_BNBU",
    ),
)

Vehicle_Standard1 = Vehicle_Standard11.select("concatenated_data")

logging.info("Writing the Vehicle_Standard file")
write_txt(
    df=Vehicle_Standard1,
    s3_bucket_and_folder=lnk_Veh_standard_outputpath,
    local_folder="",
    file_name=Vehicle_Standard,
    delimiter="",
    txt_extension=".txt",
    force_ignore_txt=False,
    force_txt=False,
    header=False,
)

logging.info("Writing the Vehicle_Standard file")
write_parquet_or_csv(
    df=lnk_Veh_standard_csv,
    s3_bucket_and_folder=lnk_Veh_standard_outputpath,
    local_folder="",
    file_name=Vehicle_Standard + "_csv",
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)
