import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_csvs_by_prefix_with_header,
                                            read_parquet_using_full_path,
                                            write_parquet_or_csv)
from pyspark.sql.functions import length, rpad, when

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

args = getResolvedOptions(
    sys.argv,
    [
        "output_folder",
        "input_folder_ethnic",
        "demo_geo_ethnic_ds_input_file",
        "ethnic_codes_input_file",
        "sq_demogeo_csv_output_file",
    ],
)

# Aws Buckets
input_folder_ethnic = args["input_folder_ethnic"]
output_folder = args["output_folder"]

# Input Files
demo_geo_ethnic_ds_input_file = args["demo_geo_ethnic_ds_input_file"]
ethnic_codes_input_file = args["ethnic_codes_input_file"]

# Output Files
sq_demogeo_csv_output_file = args["sq_demogeo_csv_output_file"]

logging.info("Reading demo_geo_ethnic_ds_input_file file")
lnk_geo_demo_ethnic_ds = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=demo_geo_ethnic_ds_input_file,
    force_spark_read=True,
)

logging.info("Reading input_folder_ethnic file")
lnk_ethnic_codes = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=input_folder_ethnic,
    local_folder="",
    csvs_prefix=ethnic_codes_input_file,
    header=True,
    delimiter=",",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

lnk_ethnic_codes = lnk_ethnic_codes.withColumnRenamed("Ethic_cd", "Ethnic_cd")


logging.info(
    "Creating new DFs for lnk_ethnic_codes to join with various ethnic codes of lnk_geo_demo_ethnic_ds"
)
lnk_ethnic_codes_1 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_1"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_1"),
)

lnk_ethnic_codes_2 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_2"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_2"),
)

lnk_ethnic_codes_3 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_3"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_3"),
)

lnk_ethnic_codes_4 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_4"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_4"),
)

lnk_ethnic_codes_5 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_5"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_5"),
)

lnk_ethnic_codes_6 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_6"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_6"),
)

lnk_ethnic_codes_7 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_7"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_7"),
)

lnk_ethnic_codes_8 = lnk_ethnic_codes.select(
    lnk_ethnic_codes.Ethnic_cd.alias("Ethnic_cd_8"),
    lnk_ethnic_codes.Exp_Group_Code.alias("Ethnic_Group_Code_8"),
)


# dropping unwanted columns
columns_to_drop = [
    "Ethnic_Code_Desc_1",
    "Ethnic_Group_Code_1",
    "Ethnic_Group_Code_Desc_1",
    "Ethnic_Group_Code_2",
    "Ethnic_Group_Code_3",
    "Ethnic_Group_Code_4",
    "Ethnic_Group_Code_5",
    "Ethnic_Group_Code_6",
    "Ethnic_Group_Code_7",
    "Ethnic_Group_Code_8",
]

lnk_geo_demo_ethnic_ds = lnk_geo_demo_ethnic_ds.drop(*columns_to_drop)

logging.info("Joining lnk_etnic_df and lnk_ethnic_codes for getting required fields")
lnk_etnic_df = (
    lnk_geo_demo_ethnic_ds.join(
        lnk_ethnic_codes_1,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_1 == lnk_ethnic_codes_1.Ethnic_cd_1],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_2,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_2 == lnk_ethnic_codes_2.Ethnic_cd_2],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_3,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_3 == lnk_ethnic_codes_3.Ethnic_cd_3],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_4,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_4 == lnk_ethnic_codes_4.Ethnic_cd_4],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_5,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_5 == lnk_ethnic_codes_5.Ethnic_cd_5],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_6,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_6 == lnk_ethnic_codes_6.Ethnic_cd_6],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_7,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_7 == lnk_ethnic_codes_7.Ethnic_cd_7],
        how="leftouter",
    )
    .join(
        lnk_ethnic_codes_8,
        [lnk_geo_demo_ethnic_ds.Ethnic_Code_8 == lnk_ethnic_codes_8.Ethnic_cd_8],
        how="leftouter",
    )
    .select(
        lnk_geo_demo_ethnic_ds.MANUFACTURER,
        lnk_geo_demo_ethnic_ds.MODEL_YR,
        lnk_geo_demo_ethnic_ds.MAKE_TXT,
        lnk_geo_demo_ethnic_ds.MODEL_TXT,
        lnk_geo_demo_ethnic_ds.TRIM_TXT,
        lnk_geo_demo_ethnic_ds.MODEL_CLASS_TXT,
        lnk_geo_demo_ethnic_ds.ACTIVITY_DATE,
        lnk_geo_demo_ethnic_ds.MAX_ACTIVITY_DATE,
        lnk_geo_demo_ethnic_ds.DISPOSAL_DATE,
        lnk_geo_demo_ethnic_ds.REGISTRATION_STATUS,
        lnk_geo_demo_ethnic_ds.BNBU,
        lnk_geo_demo_ethnic_ds.NVDB_PURCH_TYPE,
        lnk_geo_demo_ethnic_ds.VIN,
        lnk_geo_demo_ethnic_ds.SEQ_NO,
        lnk_geo_demo_ethnic_ds.ZIP,
        lnk_geo_demo_ethnic_ds.ZIP4,
        lnk_geo_demo_ethnic_ds.COUNTRY_CD,
        lnk_geo_demo_ethnic_ds.DRIVEWHEEL_TXT,
        lnk_geo_demo_ethnic_ds.CYLINDER,
        lnk_geo_demo_ethnic_ds.TAX_HP,
        lnk_geo_demo_ethnic_ds.INDUCTION_TY,
        lnk_geo_demo_ethnic_ds.STYLE,
        lnk_geo_demo_ethnic_ds.MAX_DOOR_CT,
        lnk_geo_demo_ethnic_ds.VEH_LENGTH,
        lnk_geo_demo_ethnic_ds.VEH_WT,
        lnk_geo_demo_ethnic_ds.MATCH_TYPE,
        lnk_geo_demo_ethnic_ds.VEHICLE_INT_ID,
        lnk_geo_demo_ethnic_ds.HOUSEHOLD,
        lnk_geo_demo_ethnic_ds.COUNTS,
        lnk_geo_demo_ethnic_ds.VIN_PATTERN,
        lnk_geo_demo_ethnic_ds.SEQ_NO20,
        lnk_geo_demo_ethnic_ds.I1_Combined_Age,
        lnk_geo_demo_ethnic_ds.I1_Gender_Code,
        lnk_geo_demo_ethnic_ds.Number_of_Children_18_or_Less,
        lnk_geo_demo_ethnic_ds.Ethnic_Insight_Match_Flag,
        lnk_geo_demo_ethnic_ds.Ethnicity_Detail,
        lnk_geo_demo_ethnic_ds.Exp_Group_Code,
        lnk_geo_demo_ethnic_ds.e_Tech_Group,
        lnk_geo_demo_ethnic_ds.Income,
        lnk_geo_demo_ethnic_ds.PURCH_TYPE,
        lnk_geo_demo_ethnic_ds.Autocount_Purchase_Date,
        lnk_geo_demo_ethnic_ds.DLR_Name,
        lnk_geo_demo_ethnic_ds.DLR_Number,
        lnk_geo_demo_ethnic_ds.DLR_Type,
        lnk_geo_demo_ethnic_ds.Lender_Type,
        lnk_geo_demo_ethnic_ds.LHDR_NAME,
        lnk_geo_demo_ethnic_ds.State_Code,
        lnk_geo_demo_ethnic_ds.StateAbbr,
        lnk_geo_demo_ethnic_ds.County_Cd,
        lnk_geo_demo_ethnic_ds.County_Name,
        lnk_geo_demo_ethnic_ds.Census_Tract,
        lnk_geo_demo_ethnic_ds.Census_Block_Group,
        lnk_geo_demo_ethnic_ds.Block_ID,
        lnk_geo_demo_ethnic_ds.MCD_CCD_Code,
        lnk_geo_demo_ethnic_ds.CBSA_CODE,
        lnk_geo_demo_ethnic_ds.DMA_Code,
        lnk_geo_demo_ethnic_ds.DMA_Name,
        when(length(lnk_geo_demo_ethnic_ds.I1_Birth_Date_CCYYMM) == 0, "")
        .when(
            length(lnk_geo_demo_ethnic_ds.I1_Birth_Date_CCYYMM) == 4,
            rpad(lnk_geo_demo_ethnic_ds.I1_Birth_Date_CCYYMM, 6, " "),
        )
        .otherwise(lnk_geo_demo_ethnic_ds.I1_Birth_Date_CCYYMM)
        .alias("I1_Birth_Date_CCYYMM"),
        lnk_geo_demo_ethnic_ds.Mosaic_Household,
        lnk_geo_demo_ethnic_ds.Presence_of_Child_Age_0_18_V3,
        lnk_geo_demo_ethnic_ds.Estimated_Current_Home_Value,
        lnk_geo_demo_ethnic_ds.Marital_Status_1,
        lnk_geo_demo_ethnic_ds.Person_1_Occupation_Group_V2,
        lnk_geo_demo_ethnic_ds.Education_Individual_1,
        lnk_geo_demo_ethnic_ds.Dwelling_Type,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_1,
        lnk_ethnic_codes_1.Ethnic_Group_Code_1,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_2,
        lnk_ethnic_codes_2.Ethnic_Group_Code_2,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_3,
        lnk_ethnic_codes_3.Ethnic_Group_Code_3,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_4,
        lnk_ethnic_codes_4.Ethnic_Group_Code_4,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_5,
        lnk_ethnic_codes_5.Ethnic_Group_Code_5,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_6,
        lnk_ethnic_codes_6.Ethnic_Group_Code_6,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_7,
        lnk_ethnic_codes_7.Ethnic_Group_Code_7,
        lnk_geo_demo_ethnic_ds.Ethnic_Code_8,
        lnk_ethnic_codes_8.Ethnic_Group_Code_8,
    )
)

logging.info("Writing lnk_etnic_df to output folder")
write_parquet_or_csv(
    df=lnk_etnic_df,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=sq_demogeo_csv_output_file,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

spark.stop()
