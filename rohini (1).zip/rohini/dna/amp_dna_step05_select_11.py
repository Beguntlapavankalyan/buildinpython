import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_parquet_using_full_path,
                                            write_parquet_or_csv, write_txt)
from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.functions import (asc, col, concat, concat_ws, desc, expr,
                                   format_string, lag, lit, row_number, rpad,
                                   substring, trim, when)

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

args = getResolvedOptions(
    sys.argv,
    [
        "inputpath",
        "outputfilename1",
        "outputfilename2",
        "outputfilename3",
        "outputfilename4",
        "outputfilepath",
    ],
)

inputpath = args["inputpath"]
outputfilename1 = args["outputfilename1"]
outputfilename2 = args["outputfilename2"]
outputfilename3 = args["outputfilename3"]
outputfilename4 = args["outputfilename4"]
outputfilepath = args["outputfilepath"]

logging.info("Read the input data from the input path")
lnk_evd_data_in_df = read_parquet_using_full_path(
    glue_context=glue_context, spark=spark, full_path=inputpath, force_spark_read=True
)

lnk_evd_data_in_filtered = lnk_evd_data_in_df.select(
    F.col("SEQUENCE_NUMBER").cast("string"),
    F.col("VEHICLE_INT_ID").cast("string"),
    F.col("ACTIVITY_DATE").cast("string"),
    F.col("FIRST_NAME").cast("string"),
    F.col("MIDDLE_NAME").cast("string"),
    F.col("LAST_NAME").cast("string"),
    F.col("RANGE").cast("string"),
    F.col("PRE_DIRECTIONAL").cast("string"),
    F.col("STREET_NAME").cast("string"),
    F.col("SUFFIX").cast("string"),
    F.col("POST_DIRECTIONAL").cast("string"),
    F.col("RR_NUMBER").cast("string"),
    F.col("RR_BOX").cast("string"),
    F.col("POB").cast("string"),
    F.col("SCND_DESIGNATION").cast("string"),
    F.col("SCND_RANGE").cast("string"),
    F.col("CITY_NAME").cast("string"),
    F.col("STATE_ABBR").cast("string"),
    F.col("ZIP").cast("string"),
    F.col("ZIP4").cast("string"),
    F.col("PURCHASED_VEHICLE").cast("string"),
    F.col("CURRENT_VEHICLE_FLAG").cast("string"),
    F.col("VIN").cast("string").alias("VIN"),
    F.col("VIN_PATTERN").cast("string"),
    F.col("WMI").cast("string"),
    F.col("MDYR").cast("string"),
    F.col("SOURCE_TY").cast("string"),
    F.col("svActivityDate").cast("Date"),
    F.col("svSeqNum").cast("bigint"),
    F.col("DISPOSAL_DATE").cast("string"),
    F.col("svDisposalDate").cast("Date"),
    F.col("BNBU").cast("string"),
    F.col("COUNTRY_CD").cast("string"),
    F.col("MANUFACTURER").cast("string"),
    F.col("MODEL_YR").cast("string"),
    F.col("MAKE_TEXT").cast("string"),
    F.col("MODEL_TEXT").cast("string"),
    F.col("MODEL_CLS_CD").cast("string"),
    F.col("MODEL_CLASS_TEXT").cast("string"),
    F.col("STYLE").cast("string"),
    F.col("MIN_DOOR_CT").cast("string"),
    F.col("MAX_DOOR_CT").cast("string"),
    F.col("TRANS_CD").cast("string"),
    F.col("TRANS_TY").cast("string"),
    F.col("DRIVEWHEEL_TY").cast("string"),
    F.col("WHEEL_BASE").cast("string"),
    F.col("VEH_LENGTH").cast("string"),
    F.col("TIRE_SIZE").cast("string"),
    F.col("VEH_WT").cast("string"),
    F.col("CYLINDER").cast("string"),
    F.col("CAM_CONFIG").cast("string"),
    F.col("TAX_HP").cast("string"),
    F.col("FUEL_DELIVERY_TY").cast("string"),
    F.col("FUEL_TY").cast("string"),
    F.col("DISPLACEMENT").cast("string"),
    F.col("IMPORT").cast("string"),
    F.col("TRIM_TEXT").cast("string"),
    F.col("GEAR_CT").cast("string"),
    F.col("DLR_Name").cast("string"),
    F.col("DLR_Number").cast("string"),
    F.col("DLR_Type").cast("string"),
    F.col("LHDR_NAME").cast("string"),
    F.col("MSRP").cast("string"),
    F.col("REGISTRATION_STATUS").cast("string"),
    F.col("PURCHASE_FLAG").cast("string"),
    F.col("PURCH_TYPE").cast("string"),
    F.col("Lender_Type").cast("string"),
    F.col("MAX_ACTIVITY_DT").cast("string"),
    F.col("SEQ_NO").cast("string"),
    F.col("rpt_bnbu_in").cast("string"),
    F.col("report_period_yr").cast("string"),
    F.col("report_period_mm").cast("string"),
    F.col("MATCH_TYPE").cast("string"),
    F.col("input_vin").cast("string"),
    F.col("Autocount_purch_date").cast("string"),
    F.col("MAKE_CD").cast("string"),
    F.col("MODEL_CD").cast("string"),
)

# Applying filter condition
lnk_evd_data_in = lnk_evd_data_in_filtered.filter(F.col("PURCHASED_VEHICLE") == "N")

srt_selected_veh = lnk_evd_data_in.orderBy(
    lnk_evd_data_in.SEQ_NO, lnk_evd_data_in.svSeqNum, col("svActivityDate").desc()
)
window_spec = Window.partitionBy("svSeqNum").orderBy(
    "SEQ_NO", "svSeqNum", col("svActivityDate").desc()
)
srt_selected_veh_df = srt_selected_veh.withColumn(
    "prev_key", lag(col("SEQ_NO")).over(window_spec)
)
srt_selected_veh_df = srt_selected_veh_df.withColumn(
    "clusterKeyChange", when(col("SEQ_NO") != col("prev_key"), 1).otherwise(0)
)
window_spec_clkey = Window.partitionBy("SEQ_NO", "clusterKeyChange").orderBy(
    "SEQ_NO", "svSeqNum", col("svActivityDate").desc(), "clusterKeyChange"
)

srt_selected_veh_df = srt_selected_veh_df.withColumn(
    "svCounter", row_number().over(window_spec_clkey)
)

lnk_fn = srt_selected_veh_df.filter(srt_selected_veh_df.svCounter < 11)

lnk_purchased_filtered_df = lnk_evd_data_in_filtered.withColumn(
    "filter_col",
    when((col("rpt_bnbu_in") == "X") & (col("PURCHASED_VEHICLE") == "Y"), 1)
    .when(
        (trim(col("VIN")) == trim(col("input_vin")))
        & (
            col("report_period_yr").cast("int") - 2
            <= col("ACTIVITY_DATE").substr(1, 4).cast("int")
        ),
        1,
    )
    .otherwise(0),
)

lnk_purchased_filtered = lnk_purchased_filtered_df.filter(col("filter_col") == 1)

lnk_purchased = lnk_purchased_filtered.select(
    F.col("SEQUENCE_NUMBER").alias("SEQUENCE_NUMBER"),
    F.col("VEHICLE_INT_ID").alias("VEHICLE_INT_ID"),
    F.col("ACTIVITY_DATE").alias("ACTIVITY_DATE"),
    F.col("FIRST_NAME").alias("FIRST_NAME"),
    F.col("MIDDLE_NAME").alias("MIDDLE_NAME"),
    F.col("LAST_NAME").alias("LAST_NAME"),
    F.col("RANGE").alias("RANGE"),
    F.col("PRE_DIRECTIONAL").alias("PRE_DIRECTIONAL"),
    F.col("STREET_NAME").alias("STREET_NAME"),
    F.col("SUFFIX").alias("SUFFIX"),
    F.col("POST_DIRECTIONAL").alias("POST_DIRECTIONAL"),
    F.col("RR_NUMBER").alias("RR_NUMBER"),
    F.col("RR_BOX").alias("RR_BOX"),
    F.col("POB").alias("POB"),
    F.col("SCND_DESIGNATION").alias("SCND_DESIGNATION"),
    F.col("SCND_RANGE").alias("SCND_RANGE"),
    F.col("CITY_NAME").alias("CITY_NAME"),
    F.col("STATE_ABBR").alias("STATE_ABBR"),
    F.col("ZIP").alias("ZIP"),
    F.col("ZIP4").alias("ZIP4"),
    when(F.col("rpt_bnbu_in") == "X", "N").otherwise("Y").alias("PURCHASED_VEHICLE"),
    F.col("CURRENT_VEHICLE_FLAG").alias("CURRENT_VEHICLE_FLAG"),
    F.col("VIN").alias("VIN"),
    F.col("VIN_PATTERN").alias("VIN_PATTERN"),
    F.col("WMI").alias("WMI"),
    F.col("MDYR").alias("MDYR"),
    F.col("SOURCE_TY").alias("SOURCE_TY"),
    F.col("svActivityDate").alias("svActivityDate"),
    F.col("svSeqNum").alias("svSeqNum"),
    F.when(F.col("DISPOSAL_DATE") == "1900-01-01", "")
    .otherwise(F.col("DISPOSAL_DATE"))
    .alias("DISPOSAL_DATE"),
    F.col("svDisposalDate").alias("svDisposalDate"),
    F.when(F.col("rpt_bnbu_in") == "X", F.col("BNBU"))
    .otherwise(F.col("rpt_bnbu_in"))
    .alias("BNBU"),
    F.col("COUNTRY_CD").alias("COUNTRY_CD"),
    F.col("MANUFACTURER").alias("MANUFACTURER"),
    F.col("MODEL_YR").alias("MODEL_YR"),
    F.col("MAKE_TEXT").alias("MAKE_TEXT"),
    F.col("MODEL_TEXT").alias("MODEL_TEXT"),
    F.col("MODEL_CLS_CD").alias("MODEL_CLS_CD"),
    F.col("MODEL_CLASS_TEXT").alias("MODEL_CLASS_TEXT"),
    F.col("STYLE").alias("STYLE"),
    F.col("MIN_DOOR_CT").alias("MIN_DOOR_CT"),
    F.col("MAX_DOOR_CT").alias("MAX_DOOR_CT"),
    F.col("TRANS_CD").alias("TRANS_CD"),
    F.col("TRANS_TY").alias("TRANS_TY"),
    F.col("DRIVEWHEEL_TY").alias("DRIVEWHEEL_TY"),
    F.col("WHEEL_BASE").alias("WHEEL_BASE"),
    F.col("VEH_LENGTH").alias("VEH_LENGTH"),
    F.col("TIRE_SIZE").alias("TIRE_SIZE"),
    F.col("VEH_WT").alias("VEH_WT"),
    F.col("CYLINDER").alias("CYLINDER"),
    F.col("CAM_CONFIG").alias("CAM_CONFIG"),
    F.col("TAX_HP").alias("TAX_HP"),
    F.col("FUEL_DELIVERY_TY").alias("FUEL_DELIVERY_TY"),
    F.col("FUEL_TY").alias("FUEL_TY"),
    F.col("DISPLACEMENT").alias("DISPLACEMENT"),
    F.col("IMPORT").alias("IMPORT"),
    F.col("TRIM_TEXT").alias("TRIM_TEXT"),
    F.col("GEAR_CT").alias("GEAR_CT"),
    F.col("DLR_Name").alias("DLR_Name"),
    F.col("DLR_Number").alias("DLR_Number"),
    F.col("DLR_Type").alias("DLR_Type"),
    F.col("LHDR_NAME").alias("LHDR_NAME"),
    F.col("MSRP").alias("MSRP"),
    F.col("REGISTRATION_STATUS").alias("REGISTRATION_STATUS"),
    F.col("PURCHASE_FLAG").alias("PURCHASE_FLAG"),
    F.col("PURCH_TYPE").alias("PURCH_TYPE"),
    F.col("Lender_Type").alias("Lender_Type"),
    F.col("MAX_ACTIVITY_DT").alias("MAX_ACTIVITY_DT"),
    F.col("SEQ_NO").alias("SEQ_NO"),
    F.col("rpt_bnbu_in").alias("rpt_bnbu_in"),
    F.col("report_period_yr").alias("report_period_yr"),
    F.col("report_period_mm").alias("report_period_mm"),
    F.col("MATCH_TYPE").alias("MATCH_TYPE"),
    F.col("Autocount_purch_date").alias("Autocount_purch_date"),
    F.col("MAKE_CD").alias("MAKE_CD"),
    F.col("MODEL_CD").alias("MODEL_CD"),
)

lnk_dedupe = lnk_purchased.dropDuplicates(["SEQUENCE_NUMBER"])

logging.info("Select and rename the columns based on the mapping")
lnk_purchased_vin = lnk_dedupe.select(
    F.col("SEQUENCE_NUMBER").alias("SEQUENCE_NUMBER"),
    F.col("VEHICLE_INT_ID").alias("VEHICLE_INT_ID"),
    F.col("ACTIVITY_DATE").alias("ACTIVITY_DATE"),
    F.col("FIRST_NAME").alias("FIRST_NAME"),
    F.col("MIDDLE_NAME").alias("MIDDLE_NAME"),
    F.col("LAST_NAME").alias("LAST_NAME"),
    F.col("RANGE").alias("RANGE"),
    F.col("PRE_DIRECTIONAL").alias("PRE_DIRECTIONAL"),
    F.col("STREET_NAME").alias("STREET_NAME"),
    F.col("SUFFIX").alias("SUFFIX"),
    F.col("POST_DIRECTIONAL").alias("POST_DIRECTIONAL"),
    F.col("RR_NUMBER").alias("RR_NUMBER"),
    F.col("RR_BOX").alias("RR_BOX"),
    F.col("POB").alias("POB"),
    F.col("SCND_DESIGNATION").alias("SCND_DESIGNATION"),
    F.col("SCND_RANGE").alias("SCND_RANGE"),
    F.col("CITY_NAME").alias("CITY_NAME"),
    F.col("STATE_ABBR").alias("STATE_ABBR"),
    F.col("ZIP").alias("ZIP"),
    F.col("ZIP4").alias("ZIP4"),
    F.col("PURCHASED_VEHICLE").alias("PURCHASED_VEHICLE"),
    F.col("CURRENT_VEHICLE_FLAG").alias("CURRENT_VEHICLE_FLAG"),
    F.col("VIN").alias("VIN"),
    F.col("VIN_PATTERN").alias("VIN_PATTERN"),
    F.col("WMI").alias("WMI"),
    F.col("MDYR").alias("MDYR"),
    F.col("SOURCE_TY").alias("SOURCE_TY"),
    F.col("svActivityDate").alias("svActivityDate"),
    F.col("svSeqNum").alias("svSeqNum"),
    F.col("DISPOSAL_DATE").alias("DISPOSAL_DATE"),
    F.col("svDisposalDate").alias("svDisposalDate"),
    F.col("BNBU").alias("BNBU"),
    F.col("COUNTRY_CD").alias("COUNTRY_CD"),
    F.col("MANUFACTURER").alias("MANUFACTURER"),
    F.col("MODEL_YR").alias("MODEL_YR"),
    F.col("MAKE_TEXT").alias("MAKE_TEXT"),
    F.col("MODEL_TEXT").alias("MODEL_TEXT"),
    F.col("MODEL_CLS_CD").alias("MODEL_CLS_CD"),
    F.col("MODEL_CLASS_TEXT").alias("MODEL_CLASS_TEXT"),
    F.col("STYLE").alias("STYLE"),
    F.col("MIN_DOOR_CT").alias("MIN_DOOR_CT"),
    F.col("MAX_DOOR_CT").alias("MAX_DOOR_CT"),
    F.col("TRANS_CD").alias("TRANS_CD"),
    F.col("TRANS_TY").alias("TRANS_TY"),
    F.col("DRIVEWHEEL_TY").alias("DRIVEWHEEL_TY"),
    F.col("WHEEL_BASE").alias("WHEEL_BASE"),
    F.col("VEH_LENGTH").alias("VEH_LENGTH"),
    F.col("TIRE_SIZE").alias("TIRE_SIZE"),
    F.col("VEH_WT").alias("VEH_WT"),
    F.col("CYLINDER").alias("CYLINDER"),
    F.col("CAM_CONFIG").alias("CAM_CONFIG"),
    F.col("TAX_HP").alias("TAX_HP"),
    F.col("FUEL_DELIVERY_TY").alias("FUEL_DELIVERY_TY"),
    F.col("FUEL_TY").alias("FUEL_TY"),
    F.col("DISPLACEMENT").alias("DISPLACEMENT"),
    F.col("IMPORT").alias("IMPORT"),
    F.col("TRIM_TEXT").alias("TRIM_TEXT"),
    F.col("GEAR_CT").alias("GEAR_CT"),
    F.col("DLR_Name").alias("DLR_Name"),
    F.col("DLR_Number").alias("DLR_Number"),
    F.col("DLR_Type").alias("DLR_Type"),
    F.col("LHDR_NAME").alias("LHDR_NAME"),
    F.col("MSRP").alias("MSRP"),
    F.col("REGISTRATION_STATUS").alias("REGISTRATION_STATUS"),
    F.col("PURCHASE_FLAG").alias("PURCHASE_FLAG"),
    F.col("PURCH_TYPE").alias("PURCH_TYPE"),
    F.col("Lender_Type").alias("Lender_Type"),
    F.col("MAX_ACTIVITY_DT").alias("MAX_ACTIVITY_DT"),
    F.col("SEQ_NO").alias("SEQ_NO"),
    F.col("rpt_bnbu_in").alias("rpt_bnbu_in"),
    F.col("report_period_yr").alias("report_period_yr"),
    F.col("report_period_mm").alias("report_period_mm"),
    F.col("MATCH_TYPE").alias("MATCH_TYPE"),
    F.col("Autocount_purch_date").alias("Autocount_purch_date"),
    F.col("MAKE_CD").alias("MAKE_CD"),
    F.col("MODEL_CD").alias("MODEL_CD"),
)

lnk_seq = lnk_dedupe.select(F.col("SEQUENCE_NUMBER").alias("SEQUENCE_NUMBER"))

cols_drop = ["input_vin", "prev_key", "clusterKeyChange", "svCounter"]
lnk_fn = lnk_fn.drop(*cols_drop)

excluded_columns_lnk_fn = ["SEQUENCE_NUMBER"]
columns_to_select_lnk_household = [
    col for col in lnk_fn.columns if col not in excluded_columns_lnk_fn
]
lnk_household = lnk_seq.join(lnk_fn, "SEQUENCE_NUMBER", how="inner").select(
    lnk_seq["SEQUENCE_NUMBER"], *columns_to_select_lnk_household
)

column_count = len(lnk_household.columns)

lnk_evd_data = lnk_household.union(lnk_purchased_vin)

# Perform sorting
lnk_count1 = lnk_evd_data.orderBy(
    asc("SEQ_NO"), asc("svSeqNum"), desc("svActivityDate")
)

# Define the window specification
windowSpec = Window.partitionBy("SEQ_NO").orderBy(
    asc("SEQ_NO"), asc("svSeqNum"), desc("svActivityDate")
)

# Add a row number column to identify the first occurrence within each partition
lnk_count1 = lnk_count1.withColumn("row_num", row_number().over(windowSpec))

logging.info("Create the clusterKeyChange column")
lnk_count1 = lnk_count1.withColumn(
    "clusterKeyChange", when(col("row_num") == 1, lit(True)).otherwise(lit(False))
)

# Drop the temporary row_num column
lnk_count1 = lnk_count1.drop("row_num")

# Assuming lnk_count is your DataFrame
windowSpec = Window.partitionBy("SEQ_NO").orderBy(
    asc("SEQ_NO"), asc("svSeqNum"), desc("svActivityDate")
)

lnk_count1 = lnk_count1.withColumn("svCounter", row_number().over(windowSpec))

lnk_count1 = lnk_count1.withColumn(
    "svActivityDate",
    F.when(
        F.col("ACTIVITY_DATE").isNull() | (F.trim(F.col("ACTIVITY_DATE")) == ""),
        F.lit(" " * 10),
    ).otherwise(
        F.expr(
            "concat(substring(ACTIVITY_DATE, 6, 2), '/', substring(ACTIVITY_DATE, 9, 2), '/', substring(ACTIVITY_DATE, 1, 4))"
        )
    ),
)

logging.info("Create the svDisposalDate column")
lnk_count1 = lnk_count1.withColumn(
    "svDisposalDate",
    F.when(F.col("DISPOSAL_DATE") == "1900-01-01", "").otherwise(
        F.col("DISPOSAL_DATE")
    ),
)

logging.info("Create the svDisposalDate column")
lnk_count1 = lnk_count1.withColumn(
    "svDisposalDate",
    F.when(F.col("svDisposalDate") == "01/01/1900", "").otherwise(
        F.col("svDisposalDate")
    ),
)

lnk_count1 = lnk_count1.withColumn(
    "svDisposalDate",
    F.when(
        F.col("svDisposalDate").isNull() | (F.trim(F.col("svDisposalDate")) == ""),
        F.lit(" " * 10),
    ).otherwise(
        F.expr(
            "concat(substring(svDisposalDate, 6, 2), '/', substring(svDisposalDate, 9, 2), '/', substring(svDisposalDate, 1, 4))"
        )
    ),
)

lnk_count1 = lnk_count1.withColumn(
    "svMaxActDate",
    F.when(
        F.col("MAX_ACTIVITY_DT").isNull() | (F.trim(F.col("MAX_ACTIVITY_DT")) == ""),
        F.lit(" " * 10),
    ).otherwise(
        F.expr(
            "concat(substring(MAX_ACTIVITY_DT, 6, 2), '/', substring(MAX_ACTIVITY_DT, 9, 2), '/', substring(MAX_ACTIVITY_DT, 1, 4))"
        )
    ),
)

logging.info("Applying common filter condition for all final dataframes")
filter_condition = lnk_count1.filter(F.col("svCounter") < 12)

rpt_bnbu_in_case_expr = "CASE WHEN rpt_bnbu_in = 'X' THEN 'Y' WHEN PURCHASED_VEHICLE = 'Y' THEN 'N' ELSE 'Y' END"

lnk_ds_output = filter_condition.select(
    when(col("MANUFACTURER").isNull(), lit(" " * 40))
    .otherwise(substring(col("MANUFACTURER"), -39, 40))
    .alias("MANUFACTURER"),
    when(col("MODEL_YR").isNull(), lit(" " * 4))
    .otherwise(substring(col("MODEL_YR"), -4, 4))
    .alias("MODEL_YR"),
    when(col("MAKE_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MAKE_TEXT"), -49, 50))
    .alias("MAKE_TXT"),
    when(col("MODEL_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MODEL_TEXT"), -49, 50))
    .alias("MODEL_TXT"),
    when(col("TRIM_TEXT").isNull(), lit(" " * 150))
    .otherwise(substring(col("TRIM_TEXT"), -149, 150))
    .alias("TRIM_TXT"),
    when(col("MODEL_CLASS_TEXT").isNull(), lit(" " * 35))
    .otherwise(substring(col("MODEL_CLASS_TEXT"), -34, 35))
    .alias("MODEL_CLASS_TXT"),
    col("svActivityDate").alias("ACTIVITY_DATE"),
    col("svMaxActDate").alias("MAX_ACTIVITY_DATE"),
    col("svDisposalDate").alias("DISPOSAL_DATE"),
    when(col("REGISTRATION_STATUS").isNull(), lit(" "))
    .otherwise(substring(col("REGISTRATION_STATUS"), -1, 1))
    .alias("REGISTRATION_STATUS"),
    when(col("BNBU").isNull(), lit(" "))
    .otherwise(substring(col("BNBU"), -1, 1))
    .alias("BNBU"),
    col("PURCH_TYPE").alias("NVDB_PURCH_TYPE"),
    when(col("VIN").isNull(), lit(" " * 17))
    .otherwise(substring(col("VIN"), -17, 17))
    .alias("VIN"),
    when(col("MSRP").isNull(), lit(" " * 15))
    .otherwise(substring(col("MSRP"), -14, 15))
    .alias("MSRP"),
    when(col("IMPORT").isNull(), lit(" "))
    .otherwise(substring(col("IMPORT"), -1, 1))
    .alias("IMPORT"),
    col("PURCHASED_VEHICLE").alias("PURCHASE_FLAG"),
    when(col("SEQUENCE_NUMBER").isNull(), lit(" " * 10))
    .otherwise(substring(col("SEQUENCE_NUMBER"), -10, 10))
    .alias("SEQUENCE_NUMBER"),
    when(col("FIRST_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("FIRST_NAME"), -19, 20))
    .alias("FIRST_NAME"),
    when(col("MIDDLE_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("MIDDLE_NAME"), -19, 20))
    .alias("MIDDLE_NAME"),
    when(col("LAST_NAME").isNull(), lit(" " * 35))
    .otherwise(substring(col("LAST_NAME"), -34, 35))
    .alias("LAST_NAME"),
    trim(col("RANGE")).alias("ADDRESS"),
    when(col("CITY_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("CITY_NAME"), -19, 20))
    .alias("CITY"),
    when(col("STATE_ABBR").isNull(), lit(" " * 2))
    .otherwise(substring(col("STATE_ABBR"), -1, 2))
    .alias("STATE"),
    when(col("ZIP").isNull(), lit("0" * 5))
    .otherwise(substring(col("ZIP"), -4, 5))
    .alias("ZIP"),
    when(col("ZIP4").isNull(), lit(" " * 4))
    .otherwise(substring(col("ZIP4"), -3, 4))
    .alias("ZIP4"),
    when(col("COUNTRY_CD").isNull(), lit(" " * 3))
    .otherwise(substring(col("COUNTRY_CD"), -3, 3))
    .alias("COUNTRY_CD"),
    col("DRIVEWHEEL_TY").alias("DRIVEWHEEL_TXT"),
    when(col("DISPLACEMENT").isNull(), lit(" " * 20))
    .otherwise(substring(col("DISPLACEMENT"), -19, 20))
    .alias("DISPLACEMENT"),
    when(col("CYLINDER").isNull(), lit(" " * 20))
    .otherwise(substring(col("CYLINDER"), -19, 20))
    .alias("CYLINDER"),
    when(col("CAM_CONFIG").isNull(), lit(" " * 35))
    .otherwise(substring(col("CAM_CONFIG"), -34, 35))
    .alias("CAM_CONFIG"),
    when(col("TAX_HP").isNull(), lit(" " * 40))
    .otherwise(substring(col("TAX_HP"), -39, 40))
    .alias("TAX_HP"),
    when(col("FUEL_DELIVERY_TY").isNull(), lit(" " * 40))
    .otherwise(substring(col("FUEL_DELIVERY_TY"), -39, 40))
    .alias("FUEL_DELIVERY_TYPE"),
    when(col("FUEL_TY").isNull(), lit(" " * 75))
    .otherwise(substring(col("FUEL_TY"), -74, 75))
    .alias("FUEL_TY"),
    when(col("STYLE").isNull(), lit(" " * 100))
    .otherwise(substring(col("STYLE"), -99, 100))
    .alias("STYLE"),
    when(col("MIN_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MIN_DOOR_CT"), -14, 15))
    .alias("MIN_DOOR_CT"),
    when(col("MAX_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MAX_DOOR_CT"), -14, 15))
    .alias("MAX_DOOR_CT"),
    when(col("TRANS_TY").isNull(), lit(" " * 50))
    .otherwise(substring(col("TRANS_TY"), -49, 50))
    .alias("TRANS_TY"),
    when(col("GEAR_CT").isNull(), lit(" " * 20))
    .otherwise(substring(col("GEAR_CT"), -19, 20))
    .alias("GEAR_CT"),
    when(col("WHEEL_BASE").isNull(), lit(" " * 50))
    .otherwise(substring(col("WHEEL_BASE"), -49, 50))
    .alias("WHEEL_BASE"),
    when(col("VEH_LENGTH").isNull(), lit(" " * 20))
    .otherwise(substring(col("VEH_LENGTH"), -19, 20))
    .alias("VEH_LENGTH"),
    when(col("VEH_WT").isNull(), lit(" " * 100))
    .otherwise(substring(col("VEH_WT"), -99, 100))
    .alias("VEH_WT"),
    when(col("TIRE_SIZE").isNull(), lit(" " * 100))
    .otherwise(substring(col("TIRE_SIZE"), -99, 100))
    .alias("TIRE_SIZE"),
    when(
        col("report_period_yr").isNull() | col("report_period_mm").isNull(),
        lit(" " * 7),
    )
    .otherwise(concat(col("report_period_yr"), col("report_period_mm")))
    .alias("YEARMNTH"),
    when(col("MATCH_TYPE").isNull(), lit(" "))
    .otherwise(substring(col("MATCH_TYPE"), -1, 1))
    .alias("MATCH_TYPE"),
    when(col("VEHICLE_INT_ID").isNull(), lit(" " * 26))
    .otherwise(substring(col("VEHICLE_INT_ID"), -26, 26))
    .alias("VEHICLE_INT_ID"),
    expr(rpt_bnbu_in_case_expr).alias("HOUSEHOLD"),
    when(col("MODEL_CLS_CD").isNull(), lit(" " * 8))
    .otherwise(substring(col("MODEL_CLS_CD"), -8, 8))
    .alias("MODEL_CLASS_CD"),
    substring(col("svCounter"), -2, 2).alias("COUNT"),
    trim(col("MAKE_CD")).alias("MAKE_CD"),
    trim(col("MODEL_CD")).alias("MODEL_CD"),
    lit(" " * 10).alias("ACTIVITY_DATEH"),
    when(col("VIN_PATTERN").isNull(), lit(" " * 14))
    .otherwise(substring(col("VIN_PATTERN"), -13, 14))
    .alias("VIN_PATTERN"),
    col("Autocount_purch_date").alias("Autocount_Purchase_Date"),
    when(col("DLR_Name").isNull(), lit(" " * 125))
    .otherwise(substring(col("DLR_Name"), -124, 125))
    .alias("DLR_Name"),
    when(col("DLR_Number").isNull(), lit(" " * 30))
    .otherwise(substring(col("DLR_Number"), -29, 30))
    .alias("DLR_Number"),
    when(col("DLR_Type").isNull(), lit(" " * 6))
    .otherwise(substring(col("DLR_Type"), -5, 6))
    .alias("DLR_Type"),
    when(col("LHDR_NAME").isNull(), lit(" " * 100))
    .otherwise(substring(col("LHDR_NAME"), -99, 100))
    .alias("LHDR_NAME"),
    lit(" ").alias("VIO_FLAG"),
    when(col("VEHICLE_INT_ID").isNull(), lit(" " * 26))
    .otherwise(substring(col("VEHICLE_INT_ID"), -25, 26))
    .alias("VID"),
    when(col("rpt_bnbu_in") == "X", " ").otherwise(col("rpt_bnbu_in")).alias("HH_BNBU"),
    col("SEQ_NO"),
    col("PURCH_TYPE"),
    col("Lender_Type"),
    col("PURCHASED_VEHICLE"),
)

lnk_veh_one = filter_condition.select(
    when(col("MANUFACTURER").isNull(), lit(" " * 40))
    .otherwise(substring(col("MANUFACTURER"), -39, 40))
    .alias("MANUFACTURER"),
    when(col("MODEL_YR").isNull(), lit(" " * 4))
    .otherwise(substring(col("MODEL_YR"), -4, 4))
    .alias("MODEL_YR"),
    when(col("MAKE_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MAKE_TEXT"), -49, 50))
    .alias("MAKE_TXT"),
    when(col("MODEL_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MODEL_TEXT"), -49, 50))
    .alias("MODEL_TXT"),
    when(col("TRIM_TEXT").isNull(), lit(" " * 150))
    .otherwise(substring(col("TRIM_TEXT"), -149, 150))
    .alias("TRIM_TXT"),
    when(col("MODEL_CLASS_TEXT").isNull(), lit(" " * 35))
    .otherwise(substring(col("MODEL_CLASS_TEXT"), -34, 35))
    .alias("MODEL_CLASS_TXT"),
    col("svActivityDate").alias("ACTIVITY_DATE"),
    col("svDisposalDate").alias("DISPOSAL_DATE"),
    when(col("REGISTRATION_STATUS").isNull(), lit(" "))
    .otherwise(substring(col("REGISTRATION_STATUS"), -1, 1))
    .alias("REGISTRATION_STATUS"),
    when(col("BNBU").isNull(), lit(" "))
    .otherwise(substring(col("BNBU"), -1, 1))
    .alias("BNBU"),
    when(col("VIN").isNull(), lit(" " * 17))
    .otherwise(substring(col("VIN"), -17, 17))
    .alias("VIN"),
    when(col("MSRP").isNull(), lit(" " * 15))
    .otherwise(substring(col("MSRP"), -14, 15))
    .alias("MSRP"),
    when(col("IMPORT").isNull(), lit(" "))
    .otherwise(substring(col("IMPORT"), -1, 1))
    .alias("IMPORT"),
    col("PURCHASED_VEHICLE").alias("PURCHASE_FLAG"),
    when(col("DISPLACEMENT").isNull(), lit(" " * 20))
    .otherwise(substring(col("DISPLACEMENT"), -19, 20))
    .alias("DISPLACEMENT"),
    when(col("CYLINDER").isNull(), lit(" " * 20))
    .otherwise(substring(col("CYLINDER"), -19, 20))
    .alias("CYLINDER"),
    when(col("TAX_HP").isNull(), lit(" " * 40))
    .otherwise(substring(col("TAX_HP"), -39, 40))
    .alias("TAX_HP"),
    when(col("FUEL_DELIVERY_TY").isNull(), lit(" " * 40))
    .otherwise(substring(col("FUEL_DELIVERY_TY"), -39, 40))
    .alias("FUEL_DELIVERY_TYPE"),
    when(col("FUEL_TY").isNull(), lit(" " * 75))
    .otherwise(substring(col("FUEL_TY"), -74, 75))
    .alias("FUEL_TY"),
    when(col("STYLE").isNull(), lit(" " * 100))
    .otherwise(substring(col("STYLE"), -99, 100))
    .alias("STYLE"),
    when(col("MIN_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MIN_DOOR_CT"), -14, 15))
    .alias("MIN_DOOR_CT"),
    when(col("MAX_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MAX_DOOR_CT"), -14, 15))
    .alias("MAX_DOOR_CT"),
    when(col("WHEEL_BASE").isNull(), lit(" " * 50))
    .otherwise(substring(col("WHEEL_BASE"), -49, 50))
    .alias("WHEEL_BASE"),
    when(col("VEH_WT").isNull(), lit(" " * 100))
    .otherwise(substring(col("VEH_WT"), -99, 100))
    .alias("VEH_WT"),
    when(col("TIRE_SIZE").isNull(), lit(" " * 100))
    .otherwise(substring(col("TIRE_SIZE"), -99, 100))
    .alias("TIRE_SIZE"),
    when(col("VIN_PATTERN").isNull(), lit(" " * 14))
    .otherwise(substring(col("VIN_PATTERN"), -13, 14))
    .alias("VIN_PATTERN"),
    col("svCounter").substr(-2, 2).alias("COUNT"),
    when(col("MATCH_TYPE").isNull(), lit(" "))
    .otherwise(substring(col("MATCH_TYPE"), -1, 1))
    .alias("MATCH_TYPE"),
    col("PURCH_TYPE"),
    col("SEQ_NO"),
)

lnk_veh_standard = filter_condition.select(
    substring(col("svCounter"), -2, 2).alias("COUNT"),
    when(col("MANUFACTURER").isNull(), lit(" " * 40))
    .otherwise(substring(col("MANUFACTURER"), -39, 40))
    .alias("MANUFACTURER"),
    when(col("MODEL_YR").isNull(), lit(" " * 4))
    .otherwise(substring(col("MODEL_YR"), -4, 4))
    .alias("MODEL_YR"),
    when(col("MAKE_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MAKE_TEXT"), -49, 50))
    .alias("MAKE_TXT"),
    when(col("MODEL_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MODEL_TEXT"), -49, 50))
    .alias("MODEL_TXT"),
    when(col("TRIM_TEXT").isNull(), lit(" " * 150))
    .otherwise(substring(col("TRIM_TEXT"), -149, 150))
    .alias("TRIM_TXT"),
    when(col("MODEL_CLASS_TEXT").isNull(), lit(" " * 35))
    .otherwise(substring(col("MODEL_CLASS_TEXT"), -34, 35))
    .alias("MODEL_CLASS_TXT"),
    col("svActivityDate").alias("ACTIVITY_DATE"),
    col("svDisposalDate").alias("DISPOSAL_DATE"),
    when(col("REGISTRATION_STATUS").isNull(), lit(" "))
    .otherwise(substring(col("REGISTRATION_STATUS"), -1, 1))
    .alias("REGISTRATION_STATUS"),
    col("PURCH_TYPE").alias("PURCHASE_FLAG"),
    col("PURCHASED_VEHICLE").alias("VEHICLE_FLAG"),
    when(col("BNBU").isNull(), lit(" "))
    .otherwise(substring(col("BNBU"), -1, 1))
    .alias("BNBU"),
    when(col("IMPORT").isNotNull(), expr("lpad(IMPORT, 1, ' ')"))
    .otherwise(lit(" " * 2))
    .alias("IMPORT"),
    expr(rpt_bnbu_in_case_expr).alias("HOUSEHOLD"),
    expr("CASE WHEN rpt_bnbu_in = 'X' THEN ' ' ELSE rpt_bnbu_in END").alias("HH_BNBU"),
    col("SEQ_NO"),
)

lnk_qa_veh = filter_condition.select(
    when(col("MANUFACTURER").isNull(), lit(" " * 40))
    .otherwise(substring(col("MANUFACTURER"), -39, 40))
    .alias("MANUFACTURER"),
    when(col("MODEL_YR").isNull(), lit(" " * 4))
    .otherwise(substring(col("MODEL_YR"), -4, 4))
    .alias("MODEL_YR"),
    when(col("MAKE_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MAKE_TEXT"), -49, 50))
    .alias("MAKE_TXT"),
    when(col("MODEL_TEXT").isNull(), lit(" " * 50))
    .otherwise(substring(col("MODEL_TEXT"), -49, 50))
    .alias("MODEL_TXT"),
    when(col("TRIM_TEXT").isNull(), lit(" " * 150))
    .otherwise(substring(col("TRIM_TEXT"), -149, 150))
    .alias("TRIM_TXT"),
    when(col("MODEL_CLASS_TEXT").isNull(), lit(" " * 35))
    .otherwise(substring(col("MODEL_CLASS_TEXT"), -34, 35))
    .alias("MODEL_CLASS_TXT"),
    col("svActivityDate").alias("ACTIVITY_DATE"),
    col("svMaxActDate").alias("MAX_ACTIVITY_DATE"),
    col("svDisposalDate").alias("DISPOSAL_DATE"),
    when(col("REGISTRATION_STATUS").isNull(), lit(" "))
    .otherwise(substring(col("REGISTRATION_STATUS"), -1, 1))
    .alias("VIO_FLAG"),
    when(col("BNBU").isNull(), lit(" "))
    .otherwise(substring(col("BNBU"), -1, 1))
    .alias("BNBU"),
    when(col("VIN").isNull(), lit(" " * 17))
    .otherwise(substring(col("VIN"), -17, 17))
    .alias("VIN"),
    when(col("MSRP").isNull(), lit(" " * 15))
    .otherwise(substring(col("MSRP"), -14, 15))
    .alias("MSRP"),
    when(col("IMPORT").isNull(), lit(" "))
    .otherwise(substring(col("IMPORT"), -1, 1))
    .alias("IMPORT"),
    lit(" " * 8).alias("FILLER_8"),
    col("PURCHASED_VEHICLE").alias("PURCHASE_FLAG"),
    when(col("SEQUENCE_NUMBER").isNull(), lit(" " * 10))
    .otherwise(substring(col("SEQUENCE_NUMBER"), -10, 10))
    .alias("SEQUENCE_NUMBER"),
    when(col("FIRST_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("FIRST_NAME"), -19, 20))
    .alias("FIRST_NAME"),
    when(col("MIDDLE_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("MIDDLE_NAME"), -19, 20))
    .alias("MIDDLE_NAME"),
    when(col("LAST_NAME").isNull(), lit(" " * 35))
    .otherwise(substring(col("LAST_NAME"), -34, 35))
    .alias("LAST_NAME"),
    trim(col("RANGE")).alias("ADDRESS"),
    when(col("CITY_NAME").isNull(), lit(" " * 20))
    .otherwise(substring(col("CITY_NAME"), -19, 20))
    .alias("CITY"),
    when(col("STATE_ABBR").isNull(), lit(" " * 2))
    .otherwise(substring(col("STATE_ABBR"), -1, 2))
    .alias("STATE"),
    when(col("ZIP").isNull(), lit("0" * 5))
    .otherwise(substring(col("ZIP"), -4, 5))
    .alias("ZIP"),
    when(col("ZIP4").isNull(), lit(" " * 4))
    .otherwise(substring(col("ZIP4"), -3, 4))
    .alias("ZIP4"),
    lit(" " * 2).alias("FILLER_2"),
    substring(col("COUNTRY_CD"), -3, 3).alias("COUNTRY_CD"),
    lit(" " * 11).alias("FILLER_11"),
    col("DRIVEWHEEL_TY").alias("DRIVEWHEEL_TXT"),
    when(col("DISPLACEMENT").isNull(), lit(" " * 20))
    .otherwise(substring(col("DISPLACEMENT"), -19, 20))
    .alias("DISPLACEMENT"),
    when(col("CYLINDER").isNull(), lit(" " * 20))
    .otherwise(substring(col("CYLINDER"), -19, 20))
    .alias("CYLINDER"),
    substring(col("CAM_CONFIG"), -34, 35).alias("CAM_CONFIG"),
    when(col("TAX_HP").isNull(), lit(" " * 40))
    .otherwise(substring(col("TAX_HP"), -39, 40))
    .alias("TAX_HP"),
    when(col("FUEL_DELIVERY_TY").isNull(), lit(" " * 40))
    .otherwise(substring(col("FUEL_DELIVERY_TY"), -39, 40))
    .alias("FUEL_DELIVERY_TYPE"),
    when(col("FUEL_TY").isNull(), lit(" " * 75))
    .otherwise(substring(col("FUEL_TY"), -74, 75))
    .alias("FUEL_TY"),
    when(col("STYLE").isNull(), lit(" " * 100))
    .otherwise(substring(col("STYLE"), -99, 100))
    .alias("STYLE"),
    when(col("MIN_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MIN_DOOR_CT"), -14, 15))
    .alias("MIN_DOOR_CT"),
    when(col("MAX_DOOR_CT").isNull(), lit(" " * 15))
    .otherwise(substring(col("MAX_DOOR_CT"), -14, 15))
    .alias("MAX_DOOR_CT"),
    substring(col("TRANS_TY"), -49, 50).alias("TRANS_TY"),
    substring(col("GEAR_CT"), -19, 20).alias("GEAR_CT"),
    lit(" " * 20).alias("FILLER_20"),
    substring(col("WHEEL_BASE"), -49, 50).alias("WHEEL_BASE"),
    substring(col("VEH_LENGTH"), -19, 20).alias("VEH_LENGTH"),
    when(col("VEH_WT").isNull(), lit(" " * 100))
    .otherwise(substring(col("VEH_WT"), -99, 100))
    .alias("VEH_WT"),
    when(col("TIRE_SIZE").isNull(), lit(" " * 100))
    .otherwise(substring(col("TIRE_SIZE"), -99, 100))
    .alias("TIRE_SIZE"),
    when(
        col("report_period_yr").isNull() | col("report_period_mm").isNull(),
        lit(" " * 7),
    )
    .otherwise(concat(col("report_period_yr"), col("report_period_mm")))
    .alias("YEARMNTH"),
    when(col("MATCH_TYPE").isNull(), lit(" "))
    .otherwise(substring(col("MATCH_TYPE"), -1, 1))
    .alias("MATCH_TYPE"),
    when(col("VEHICLE_INT_ID").isNull(), lit(" " * 26))
    .otherwise(substring(col("VEHICLE_INT_ID"), -26, 26))
    .alias("VEHICLE_INT_ID"),
    expr(rpt_bnbu_in_case_expr).alias("HOUSEHOLD"),
    lit(" " * 11).alias("FILLER_11_1"),
    substring(col("MODEL_CLS_CD"), -7, 8).alias("MODEL_CLASS_CD"),
    substring(col("svCounter"), -2, 2).alias("COUNT"),
    lit(" " * 10).alias("ACTIVITY_DATEH"),
    col("PURCH_TYPE").alias("NVDB_PURCH_TYPE"),
    col("Autocount_purch_date").alias("Autocount_Purchase_Date"),
    when((trim(col("svDisposalDate")) == ""), "Y")
    .otherwise("N")
    .alias("REGISTRATION_STATUS"),
    col("PURCH_TYPE"),
    col("MAKE_CD"),
    col("MODEL_CD"),
    col("VIN_PATTERN"),
    col("SEQ_NO"),
    col("DLR_Name"),
    col("DLR_Number"),
    col("DLR_Type"),
    col("Lender_Type"),
    col("LHDR_NAME"),
)

columnslength = {
    "MANUFACTURER": 40,
    "MODEL_YR": 4,
    "MAKE_TXT": 50,
    "MODEL_TXT": 50,
    "TRIM_TXT": 150,
    "MODEL_CLASS_TXT": 35,
    "ACTIVITY_DATE": 10,
    "DISPOSAL_DATE": 10,
    "REGISTRATION_STATUS": 1,
    "BNBU": 1,
    "PURCH_TYPE": 1,
    "VIN": 17,
    "MSRP": 15,
    "IMPORT": 1,
    "PURCHASE_FLAG": 1,
    "DISPLACEMENT": 20,
    "CYLINDER": 20,
    "TAX_HP": 40,
    "FUEL_DELIVERY_TYPE": 40,
    "FUEL_TY": 75,
    "STYLE": 100,
    "MIN_DOOR_CT": 15,
    "MAX_DOOR_CT": 15,
    "WHEEL_BASE": 50,
    "VEH_WT": 100,
    "TIRE_SIZE": 100,
    "VIN_PATTERN": 14,
    "COUNT": 2,
    "MATCH_TYPE": 1,
    "SEQ_NO": 20,
}

for column in lnk_veh_one.columns:
    lnk_veh_one = lnk_veh_one.withColumn(
        column, when(col(column).isNull(), "").otherwise(col(column))
    )

for col_name, length in columnslength.items():
    lnk_veh_one = lnk_veh_one.withColumn(
        col_name, rpad(lnk_veh_one[col_name].cast("string"), length, " ")
    )

Vehicle_One = lnk_veh_one.withColumn(
    "concatenated_data",
    concat_ws(
        "",
        "MANUFACTURER",
        "MODEL_YR",
        "MAKE_TXT",
        "MODEL_TXT",
        "TRIM_TXT",
        "MODEL_CLASS_TXT",
        "ACTIVITY_DATE",
        "DISPOSAL_DATE",
        "REGISTRATION_STATUS",
        "BNBU",
        "PURCH_TYPE",
        "VIN",
        "MSRP",
        "IMPORT",
        "PURCHASE_FLAG",
        "DISPLACEMENT",
        "CYLINDER",
        "TAX_HP",
        "FUEL_DELIVERY_TYPE",
        "FUEL_TY",
        "STYLE",
        "MIN_DOOR_CT",
        "MAX_DOOR_CT",
        "WHEEL_BASE",
        "VEH_WT",
        "TIRE_SIZE",
        "VIN_PATTERN",
        "COUNT",
        "MATCH_TYPE",
        "SEQ_NO",
    ),
)

fourty_percent = "%-40s"
fifty_percent = "%-50s"
thirty_five_percent = "%-35s"
ten_percent = "%-10s"
fifteen_percent = "%-15s"
twenty_percent = "%-20s"
eleven_percent = "%-11s"
hundred_percent = "%-100s"

columnslength1 = {
    "MANUFACTURER": fourty_percent,
    "MODEL_YR": "%-4s",
    "MAKE_TXT": fifty_percent,
    "MODEL_TXT": fifty_percent,
    "TRIM_TXT": "%-150s",
    "MODEL_CLASS_TXT": thirty_five_percent,
    "ACTIVITY_DATE": ten_percent,
    "MAX_ACTIVITY_DATE": ten_percent,
    "DISPOSAL_DATE": ten_percent,
    "VIO_FLAG": "%-1s",
    "BNBU": "%-1s",
    "PURCH_TYPE": "%-1s",
    "VIN": "%-17s",
    "MSRP": fifteen_percent,
    "IMPORT": "%-1s",
    "FILLER_8": "%-8s",
    "PURCHASE_FLAG": "%-1s",
    "SEQUENCE_NUMBER": ten_percent,
    "FIRST_NAME": twenty_percent,
    "MIDDLE_NAME": twenty_percent,
    "LAST_NAME": thirty_five_percent,
    "ADDRESS": "%-80s",
    "CITY": twenty_percent,
    "STATE": "%-2s",
    "ZIP": "%-5s",
    "ZIP4": "%-4s",
    "FILLER_2": "%-2s",
    "COUNTRY_CD": "%-3s",
    "FILLER_11": eleven_percent,
    "DRIVEWHEEL_TXT": thirty_five_percent,
    "DISPLACEMENT": twenty_percent,
    "CYLINDER": twenty_percent,
    "CAM_CONFIG": thirty_five_percent,
    "TAX_HP": fourty_percent,
    "FUEL_DELIVERY_TYPE": fourty_percent,
    "FUEL_TY": "%-75s",
    "STYLE": hundred_percent,
    "MIN_DOOR_CT": fifteen_percent,
    "MAX_DOOR_CT": fifteen_percent,
    "TRANS_TY": fifty_percent,
    "GEAR_CT": twenty_percent,
    "FILLER_20": twenty_percent,
    "WHEEL_BASE": fifty_percent,
    "VEH_LENGTH": twenty_percent,
    "VEH_WT": hundred_percent,
    "TIRE_SIZE": hundred_percent,
    "YEARMNTH": "%-7s",
    "MATCH_TYPE": "%-1s",
    "VEHICLE_INT_ID": "%-26s",
    "HOUSEHOLD": "%-1s",
    "FILLER_11_1": eleven_percent,
    "MODEL_CLASS_CD": "%-8s",
    "COUNT": "%-2s",
    "MAKE_CD": "%-6s",
    "MODEL_CD": "%-6s",
    "ACTIVITY_DATEH": ten_percent,
    "VIN_PATTERN": "%-14s",
    "SEQ_NO": twenty_percent,
    "NVDB_PURCH_TYPE": "%-1s",
    "Autocount_Purchase_Date": ten_percent,
    "DLR_Name": "%-125s",
    "DLR_Number": "%-30s",
    "DLR_Type": "%-6s",
    "Lender_Type": eleven_percent,
    "LHDR_NAME": hundred_percent,
    "REGISTRATION_STATUS": "%-1s",
}

col_sel = [
    "MANUFACTURER",
    "MODEL_YR",
    "MAKE_TXT",
    "MODEL_TXT",
    "TRIM_TXT",
    "MODEL_CLASS_TXT",
    "ACTIVITY_DATE",
    "MAX_ACTIVITY_DATE",
    "DISPOSAL_DATE",
    "VIO_FLAG",
    "BNBU",
    "PURCH_TYPE",
    "VIN",
    "MSRP",
    "IMPORT",
    "FILLER_8",
    "PURCHASE_FLAG",
    "SEQUENCE_NUMBER",
    "FIRST_NAME",
    "MIDDLE_NAME",
    "LAST_NAME",
    "ADDRESS",
    "CITY",
    "STATE",
    "ZIP",
    "ZIP4",
    "FILLER_2",
    "COUNTRY_CD",
    "FILLER_11",
    "DRIVEWHEEL_TXT",
    "DISPLACEMENT",
    "CYLINDER",
    "CAM_CONFIG",
    "TAX_HP",
    "FUEL_DELIVERY_TYPE",
    "FUEL_TY",
    "STYLE",
    "MIN_DOOR_CT",
    "MAX_DOOR_CT",
    "TRANS_TY",
    "GEAR_CT",
    "FILLER_20",
    "WHEEL_BASE",
    "VEH_LENGTH",
    "VEH_WT",
    "TIRE_SIZE",
    "YEARMNTH",
    "MATCH_TYPE",
    "VEHICLE_INT_ID",
    "HOUSEHOLD",
    "FILLER_11_1",
    "MODEL_CLASS_CD",
    "COUNT",
    "MAKE_CD",
    "MODEL_CD",
    "ACTIVITY_DATEH",
    "VIN_PATTERN",
    "SEQ_NO",
    "NVDB_PURCH_TYPE",
    "Autocount_Purchase_Date",
    "DLR_Name",
    "DLR_Number",
    "DLR_Type",
    "Lender_Type",
    "LHDR_NAME",
    "REGISTRATION_STATUS",
]

lnk_qa_veh = lnk_qa_veh.select(*col_sel)

for column in lnk_qa_veh.columns:
    lnk_qa_veh = lnk_qa_veh.withColumn(
        column, when(col(column).isNull(), "").otherwise(col(column))
    )

lnk_qa_veh = lnk_qa_veh.select(
    concat(
        *[format_string(columnslength1.get(c), c) for c in lnk_qa_veh.columns]
    ).alias("concatenated_data")
)

logging.info("Writing lnk_qa_veh to output")
lnk_qa_veh = lnk_qa_veh.select("concatenated_data")
write_txt(
    df=lnk_qa_veh,
    s3_bucket_and_folder=outputfilepath,
    local_folder="",
    file_name=outputfilename4,
    delimiter="",
    txt_extension=".txt",
    force_ignore_txt=False,
    force_txt=False,
    header=False,
)

logging.info("Writing Vehicle_One to output")
Vehicle_One = Vehicle_One.select("concatenated_data")
write_txt(
    df=Vehicle_One,
    s3_bucket_and_folder=outputfilepath,
    local_folder="",
    file_name=outputfilename2,
    delimiter="",
    txt_extension=".txt",
    force_ignore_txt=False,
    force_txt=False,
    header=False,
)

logging.info("Writing lnk_veh_standard to output")
write_parquet_or_csv(
    df=lnk_veh_standard,
    s3_bucket_and_folder=outputfilepath,
    local_folder="",
    file_name=outputfilename3,
    delimiter="|",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

logging.info("Writing lnk_ds_output to output")
write_parquet_or_csv(
    df=lnk_ds_output,
    s3_bucket_and_folder=outputfilepath,
    local_folder="",
    file_name=outputfilename1,
    delimiter="|",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)
