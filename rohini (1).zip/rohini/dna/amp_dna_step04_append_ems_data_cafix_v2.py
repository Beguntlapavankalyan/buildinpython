import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_csvs_by_prefix_with_header,
                                            read_parquet_using_full_path,
                                            write_parquet_or_csv)
from pyspark.sql.functions import col, lpad, rpad, substring, trim, when
from pyspark.sql.types import DecimalType

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

args = getResolvedOptions(
    sys.argv,
    [
        "ds_ca_fix",
        "ds_dna_extract",
        "db2_evd",
        "ds_ems_input",
        "ds_ems_output_updated",
        "sq_fixed_seq_num_op_file",
        "ds_full_vehicle_file",
        "sq_debug_file",
        "ds_vehicle_detail",
        "outputpath",
        "db2_evd_file",
    ],
)

ds_ca_fix = args["ds_ca_fix"]
ds_dna_extract = args["ds_dna_extract"]
db2_evd = args["db2_evd"]
ds_ems_input = args["ds_ems_input"]
ds_ems_output_updated = args["ds_ems_output_updated"]
sq_fixed_seq_num_op_file = args["sq_fixed_seq_num_op_file"]
ds_full_vehicle_file = args["ds_full_vehicle_file"]
sq_debug_file = args["sq_debug_file"]
ds_vehicle_detail = args["ds_vehicle_detail"]
outputpath = args["outputpath"]
db2_evd_file = args["db2_evd_file"]

logging.info("Reading first input csv file for ds_ems_input")
lnk_ems_input = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=ds_ems_input,
    force_spark_read=True,
)

logging.info("Reading second input csv file for db2_evd")
lnk_evd2 = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=db2_evd,
    local_folder="",
    csvs_prefix=db2_evd_file,
    header=True,
    delimiter="|",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

logging.info("Reading third input csv file for lnk_fixed_seq_numbers")
lnk_fixed_seq_numbers = read_parquet_using_full_path(
    glue_context=glue_context, spark=spark, full_path=ds_ca_fix, force_spark_read=True
)

logging.info("Reading fourth input csv file for lnk_option1_emsoutput_2312_updated")
lnk_option1_emsoutput_2312_updated = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=ds_ems_output_updated,
    force_spark_read=True,
)

logging.info("Reading fifth input csv file for lnk_vehicle_data_all_data")
lnk_vehicle_data_all_data = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=ds_dna_extract,
    force_spark_read=True,
)

logging.info(
    "Creating DataFrame with each column extracted from the lnk_fixed_seq_numbers file"
)
lnk_ca_fix = lnk_fixed_seq_numbers.select(
    lnk_fixed_seq_numbers["record_id"].alias("record_id"),
    lnk_fixed_seq_numbers["record_id_rdr"].alias("SEQUENCE_NUMBER"),
)

fixed_length = 10
lnk_seq_num = lnk_ca_fix.withColumn(
    "sequence_number",
    lpad(substring(col("sequence_number"), 1, fixed_length), fixed_length, " "),
).withColumn(
    "record_id", lpad(substring(col("record_id"), 1, fixed_length), fixed_length, " ")
)

# Create a DataFrame with each column extracted from the lnk_vehicle_data_all_data file
lnk_vehicle = lnk_vehicle_data_all_data.select(
    "SEQUENCE_NUMBER",
    "VEHICLE_INT_ID",
    "ACTIVITY_DATE",
    "FIRST_NAME",
    "MIDDLE_NAME",
    "LAST_NAME",
    "RANGE",
    "PRE_DIRECTIONAL",
    "STREET_NAME",
    "SUFFIX",
    "POST_DIRECTIONAL",
    "RR_NUMBER",
    "RR_BOX",
    "POB",
    "SCND_DESIGNATION",
    "SCND_RANGE",
    "CITY_NAME",
    "STATE_ABBR",
    "ZIP",
    "ZIP4",
    "PURCHASED_VEHICLE",
    "CURRENT_VEHICLE_FLAG",
    "VIN",
    "VIN_PATTERN",
    "WMI",
    "MDYR",
    "SOURCE_TY",
    "svActivityDate",
    "svSeqNum",
    "DISPOSAL_DATE",
    "svDisposalDate",
    "BNBU",
    "COUNTRY_CD",
    "MANUFACTURER",
    "MODEL_YR",
    "MAKE_TEXT",
    "MODEL_TEXT",
    "MODEL_CLS_CD",
    "MODEL_CLASS_TEXT",
    "STYLE",
    "MIN_DOOR_CT",
    "MAX_DOOR_CT",
    "TRANS_CD",
    "TRANS_TY",
    "DRIVEWHEEL_TY",
    "WHEEL_BASE",
    "VEH_LENGTH",
    "TIRE_SIZE",
    "VEH_WT",
    "CYLINDER",
    "CAM_CONFIG",
    "TAX_HP",
    "FUEL_DELIVERY_TY",
    "FUEL_TY",
    "DISPLACEMENT",
    "IMPORT",
    "TRIM_TEXT",
    "GEAR_CT",
    "DLR_Name",
    "DLR_Number",
    "DLR_Type",
    "LHDR_NAME",
    "MSRP",
    # "REGISTRATION_STATUS",
    col("PURCHASED_VEHICLE").alias("PURCHASE_FLAG").cast("String"),
    "PURCH_TYPE",
    "Lender_Type",
    "MAX_ACTIVITY_DT",
    "Autocount_purch_date",
    "MAKE_CD",
    "MODEL_CD",
)

lnk_vehicle = lnk_vehicle.withColumn(
    "MODEL_YR",
    when(trim(col("MODEL_YR")) != "", rpad(trim(col("MODEL_YR")), 4, "0"))
    .otherwise(trim(col("MODEL_YR")))
    .cast("string"),
)

lnk_vehicle = lnk_vehicle.withColumn(
    "REGISTRATION_STATUS",
    when(
        (trim(col("DISPOSAL_DATE")) != "")
        & (trim(col("DISPOSAL_DATE")) != "1900-01-01"),
        "N",
    ).otherwise(trim(col("CURRENT_VEHICLE_FLAG"))),
)

lnk_vehicle = lnk_vehicle.withColumn(
    "PURCH_TYPE", when(col("PURCH_TYPE") == "L", "N").otherwise("Y")
)


# performing join on SEQUENCE_NUMBER
lnk_vehs = lnk_vehicle.join(lnk_seq_num, "SEQUENCE_NUMBER", "leftouter").select(
    lnk_vehicle.SEQUENCE_NUMBER,
    lnk_vehicle.VEHICLE_INT_ID,
    lnk_vehicle.ACTIVITY_DATE,
    lnk_vehicle.FIRST_NAME,
    lnk_vehicle.MIDDLE_NAME,
    lnk_vehicle.LAST_NAME,
    lnk_vehicle.RANGE,
    lnk_vehicle.PRE_DIRECTIONAL,
    lnk_vehicle.STREET_NAME,
    lnk_vehicle.SUFFIX,
    lnk_vehicle.POST_DIRECTIONAL,
    lnk_vehicle.RR_NUMBER,
    lnk_vehicle.RR_BOX,
    lnk_vehicle.POB,
    lnk_vehicle.SCND_DESIGNATION,
    lnk_vehicle.SCND_RANGE,
    lnk_vehicle.CITY_NAME,
    lnk_vehicle.STATE_ABBR,
    lnk_vehicle.ZIP,
    lnk_vehicle.ZIP4,
    lnk_vehicle.PURCHASED_VEHICLE,
    lnk_vehicle.CURRENT_VEHICLE_FLAG,
    lnk_vehicle.VIN,
    trim(lnk_vehicle.VIN_PATTERN).alias("VIN_PATTERN"),
    lnk_vehicle.WMI,
    lnk_vehicle.MDYR,
    lnk_vehicle.SOURCE_TY,
    lnk_vehicle.svActivityDate,
    lnk_vehicle.svSeqNum,
    lnk_vehicle.DISPOSAL_DATE,
    lnk_vehicle.svDisposalDate,
    lnk_vehicle.BNBU,
    lnk_vehicle.COUNTRY_CD,
    lnk_vehicle.MANUFACTURER,
    lnk_vehicle.MODEL_YR,
    lnk_vehicle.MAKE_TEXT,
    lnk_vehicle.MODEL_TEXT,
    lnk_vehicle.MODEL_CLS_CD,
    lnk_vehicle.MODEL_CLASS_TEXT,
    lnk_vehicle.STYLE,
    lnk_vehicle.MIN_DOOR_CT,
    lnk_vehicle.MAX_DOOR_CT,
    lnk_vehicle.TRANS_CD,
    lnk_vehicle.TRANS_TY,
    lnk_vehicle.DRIVEWHEEL_TY,
    lnk_vehicle.WHEEL_BASE,
    lnk_vehicle.VEH_LENGTH,
    lnk_vehicle.TIRE_SIZE,
    lnk_vehicle.VEH_WT,
    lnk_vehicle.CYLINDER,
    lnk_vehicle.CAM_CONFIG,
    lnk_vehicle.TAX_HP,
    lnk_vehicle.FUEL_DELIVERY_TY,
    lnk_vehicle.FUEL_TY,
    lnk_vehicle.DISPLACEMENT,
    lnk_vehicle.IMPORT,
    lnk_vehicle.TRIM_TEXT,
    lnk_vehicle.GEAR_CT,
    lnk_vehicle.DLR_Name,
    lnk_vehicle.DLR_Number,
    lnk_vehicle.DLR_Type,
    lnk_vehicle.LHDR_NAME,
    lnk_vehicle.MSRP,
    lnk_vehicle.REGISTRATION_STATUS,
    lnk_vehicle.PURCHASE_FLAG,
    lnk_vehicle.PURCH_TYPE,
    lnk_seq_num.record_id,
    lnk_vehicle.Lender_Type,
    lnk_vehicle.MAX_ACTIVITY_DT,
    lnk_vehicle.Autocount_purch_date,
    lnk_vehicle.MAKE_CD,
    lnk_vehicle.MODEL_CD,
)

# filter the data
sq_fixed_seq_num_df = lnk_vehs.filter(trim(lnk_seq_num.record_id) != "")

logging.info("Performing transformation logic to change column name")
lnk_fixed_seq = lnk_vehs.withColumn(
    "SEQUENCE_NUMBER",
    when(trim(col("record_id")) != "", col("record_id")).otherwise(
        col("SEQUENCE_NUMBER")
    ),
)

lnk_fixed_seq = lnk_fixed_seq.withColumn(
    "svSeqNum",
    when(
        trim(col("record_id")) != "", col("record_id").cast(DecimalType(12, 2))
    ).otherwise(col("SEQUENCE_NUMBER").cast(DecimalType(12, 2))),
)
lnk_fixed_debug = lnk_fixed_seq.alias("veh")

# removing duplicates lnk_fixed_seq
lnk_vehicle_data_in = lnk_fixed_seq.dropDuplicates(["SEQUENCE_NUMBER", "VIN"])

# performing join on lnk_evd2
lnk_vehicle_data = lnk_evd2.join(lnk_vehicle_data_in, "VIN_PATTERN", "inner").select(
    lnk_vehicle_data_in.SEQUENCE_NUMBER,
    lnk_vehicle_data_in.VEHICLE_INT_ID,
    lnk_vehicle_data_in.ACTIVITY_DATE,
    lnk_vehicle_data_in.FIRST_NAME,
    lnk_vehicle_data_in.MIDDLE_NAME,
    lnk_vehicle_data_in.LAST_NAME,
    lnk_vehicle_data_in.RANGE,
    lnk_vehicle_data_in.PRE_DIRECTIONAL,
    lnk_vehicle_data_in.STREET_NAME,
    lnk_vehicle_data_in.SUFFIX,
    lnk_vehicle_data_in.POST_DIRECTIONAL,
    lnk_vehicle_data_in.RR_NUMBER,
    lnk_vehicle_data_in.RR_BOX,
    lnk_vehicle_data_in.POB,
    lnk_vehicle_data_in.SCND_DESIGNATION,
    lnk_vehicle_data_in.SCND_RANGE,
    lnk_vehicle_data_in.CITY_NAME,
    lnk_vehicle_data_in.STATE_ABBR,
    lnk_vehicle_data_in.ZIP,
    lnk_vehicle_data_in.ZIP4,
    lnk_vehicle_data_in.PURCHASED_VEHICLE,
    lnk_vehicle_data_in.CURRENT_VEHICLE_FLAG,
    lnk_vehicle_data_in.VIN,
    lnk_vehicle_data_in.VIN_PATTERN,
    lnk_vehicle_data_in.WMI,
    lnk_vehicle_data_in.MDYR,
    lnk_vehicle_data_in.SOURCE_TY,
    lnk_vehicle_data_in.svActivityDate,
    lnk_vehicle_data_in.svSeqNum,
    lnk_vehicle_data_in.DISPOSAL_DATE,
    lnk_vehicle_data_in.svDisposalDate,
    lnk_vehicle_data_in.BNBU,
    lnk_vehicle_data_in.COUNTRY_CD,
    lnk_vehicle_data_in.MANUFACTURER,
    lnk_vehicle_data_in.MODEL_YR,
    lnk_vehicle_data_in.MAKE_TEXT,
    lnk_vehicle_data_in.MODEL_TEXT,
    lnk_vehicle_data_in.MODEL_CLS_CD,
    lnk_vehicle_data_in.MODEL_CLASS_TEXT,
    lnk_vehicle_data_in.STYLE,
    lnk_vehicle_data_in.MIN_DOOR_CT,
    lnk_vehicle_data_in.MAX_DOOR_CT,
    lnk_vehicle_data_in.TRANS_CD,
    lnk_vehicle_data_in.TRANS_TY,
    lnk_vehicle_data_in.DRIVEWHEEL_TY,
    lnk_vehicle_data_in.WHEEL_BASE,
    lnk_vehicle_data_in.VEH_LENGTH,
    lnk_vehicle_data_in.TIRE_SIZE,
    lnk_vehicle_data_in.VEH_WT,
    lnk_vehicle_data_in.CYLINDER,
    lnk_vehicle_data_in.CAM_CONFIG,
    lnk_vehicle_data_in.TAX_HP,
    lnk_vehicle_data_in.FUEL_DELIVERY_TY,
    lnk_vehicle_data_in.FUEL_TY,
    lnk_vehicle_data_in.DISPLACEMENT,
    lnk_vehicle_data_in.IMPORT,
    lnk_vehicle_data_in.TRIM_TEXT,
    lnk_vehicle_data_in.GEAR_CT,
    lnk_vehicle_data_in.DLR_Name,
    lnk_vehicle_data_in.DLR_Number,
    lnk_vehicle_data_in.DLR_Type,
    lnk_vehicle_data_in.LHDR_NAME,
    lnk_vehicle_data_in.MSRP,
    lnk_vehicle_data_in.REGISTRATION_STATUS,
    lnk_vehicle_data_in.PURCHASE_FLAG,
    lnk_vehicle_data_in.PURCH_TYPE,
    lnk_vehicle_data_in.Lender_Type,
    lnk_vehicle_data_in.MAX_ACTIVITY_DT,
    lnk_vehicle_data_in.Autocount_purch_date,
    lnk_vehicle_data_in.MAKE_CD,
    lnk_vehicle_data_in.MODEL_CD,
)

logging.info(
    "Creating DataFrame with each column extracted from the lnk_option1_emsoutput_2312_updated file"
)
lnk_in_match = lnk_option1_emsoutput_2312_updated.select(
    lnk_option1_emsoutput_2312_updated["SEQ_NO"],
    lnk_option1_emsoutput_2312_updated["Total_Enhancement_Match_Type"].alias(
        "MATCH_TYPE"
    ),
).withColumn("SEQ_NO", col("SEQ_NO"))

logging.info("Performing join on lnk_in_match and lnk_ems_input")
lnk_sort = lnk_in_match.join(lnk_ems_input, on="SEQ_NO", how="inner").select(
    lnk_in_match["SEQ_NO"],
    lnk_ems_input["rpt_bnbu_in"],
    lnk_ems_input["report_period_yr"],
    lnk_ems_input["report_period_mm"],
    lnk_in_match["MATCH_TYPE"],
    lnk_ems_input["svSeqNum"],
    lnk_ems_input["vin"].alias("input_vin"),
)

# creating new data frame and performing join on ink_sort and join_evd
lnk_evd_data_in = lnk_sort.join(lnk_vehicle_data, "svSeqNum", "inner").select(
    lnk_vehicle_data.SEQUENCE_NUMBER,
    lnk_vehicle_data.VEHICLE_INT_ID,
    lnk_vehicle_data.ACTIVITY_DATE,
    lnk_vehicle_data.FIRST_NAME,
    lnk_vehicle_data.MIDDLE_NAME,
    lnk_vehicle_data.LAST_NAME,
    lnk_vehicle_data.RANGE,
    lnk_vehicle_data.PRE_DIRECTIONAL,
    lnk_vehicle_data.STREET_NAME,
    lnk_vehicle_data.SUFFIX,
    lnk_vehicle_data.POST_DIRECTIONAL,
    lnk_vehicle_data.RR_NUMBER,
    lnk_vehicle_data.RR_BOX,
    lnk_vehicle_data.POB,
    lnk_vehicle_data.SCND_DESIGNATION,
    lnk_vehicle_data.SCND_RANGE,
    lnk_vehicle_data.CITY_NAME,
    lnk_vehicle_data.STATE_ABBR,
    lnk_vehicle_data.ZIP,
    lnk_vehicle_data.ZIP4,
    lnk_vehicle_data.PURCHASED_VEHICLE,
    lnk_vehicle_data.CURRENT_VEHICLE_FLAG,
    lnk_vehicle_data.VIN,
    lnk_vehicle_data.VIN_PATTERN,
    lnk_vehicle_data.WMI,
    lnk_vehicle_data.MDYR,
    lnk_vehicle_data.SOURCE_TY,
    lnk_vehicle_data.svActivityDate,
    lnk_vehicle_data.svSeqNum,
    lnk_vehicle_data.DISPOSAL_DATE,
    lnk_vehicle_data.svDisposalDate,
    lnk_vehicle_data.BNBU,
    lnk_vehicle_data.COUNTRY_CD,
    lnk_vehicle_data.MANUFACTURER,
    lnk_vehicle_data.MODEL_YR,
    lnk_vehicle_data.MAKE_TEXT,
    lnk_vehicle_data.MODEL_TEXT,
    lnk_vehicle_data.MODEL_CLS_CD,
    lnk_vehicle_data.MODEL_CLASS_TEXT,
    lnk_vehicle_data.STYLE,
    lnk_vehicle_data.MIN_DOOR_CT,
    lnk_vehicle_data.MAX_DOOR_CT,
    lnk_vehicle_data.TRANS_CD,
    lnk_vehicle_data.TRANS_TY,
    lnk_vehicle_data.DRIVEWHEEL_TY,
    lnk_vehicle_data.WHEEL_BASE,
    lnk_vehicle_data.VEH_LENGTH,
    lnk_vehicle_data.TIRE_SIZE,
    lnk_vehicle_data.VEH_WT,
    lnk_vehicle_data.CYLINDER,
    lnk_vehicle_data.CAM_CONFIG,
    lnk_vehicle_data.TAX_HP,
    lnk_vehicle_data.FUEL_DELIVERY_TY,
    lnk_vehicle_data.FUEL_TY,
    lnk_vehicle_data.DISPLACEMENT,
    lnk_vehicle_data.IMPORT,
    lnk_vehicle_data.TRIM_TEXT,
    lnk_vehicle_data.GEAR_CT,
    lnk_vehicle_data.DLR_Name,
    lnk_vehicle_data.DLR_Number,
    lnk_vehicle_data.DLR_Type,
    lnk_vehicle_data.LHDR_NAME,
    lnk_vehicle_data.MSRP,
    lnk_vehicle_data.REGISTRATION_STATUS,
    lnk_vehicle_data.PURCHASE_FLAG,
    lnk_vehicle_data.PURCH_TYPE,
    lnk_vehicle_data.Lender_Type,
    lnk_vehicle_data.MAX_ACTIVITY_DT,
    lnk_sort.SEQ_NO,
    lnk_sort.rpt_bnbu_in,
    lnk_sort.report_period_yr,
    lnk_sort.report_period_mm,
    lnk_sort.MATCH_TYPE,
    lnk_sort.input_vin,
    lnk_vehicle_data.Autocount_purch_date,
    lnk_vehicle_data.MAKE_CD,
    lnk_vehicle_data.MODEL_CD,
)

logging.info("Writing output_file for sq_fixed_seq_num_df")
write_parquet_or_csv(
    df=sq_fixed_seq_num_df,
    s3_bucket_and_folder=outputpath,
    local_folder="",
    file_name=sq_fixed_seq_num_op_file,
    delimiter="|",
    csv_extension=".csv",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

logging.info("Writing output_file for ds_full_vehicle_file")
write_parquet_or_csv(
    df=lnk_vehicle_data_in,
    s3_bucket_and_folder=outputpath,
    local_folder="",
    file_name=ds_full_vehicle_file,
    delimiter="|",
    csv_extension=".csv",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

logging.info("Writing output_file for sq_debug_file")
write_parquet_or_csv(
    df=lnk_evd_data_in,
    s3_bucket_and_folder=outputpath,
    local_folder="",
    file_name=sq_debug_file,
    delimiter="|",
    csv_extension=".csv",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

logging.info("Writing output_file for ds_vehicle_detail")
write_parquet_or_csv(
    df=lnk_evd_data_in,
    s3_bucket_and_folder=outputpath,
    local_folder="",
    file_name=ds_vehicle_detail,
    delimiter="|",
    csv_extension=".csv",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

spark.stop()
