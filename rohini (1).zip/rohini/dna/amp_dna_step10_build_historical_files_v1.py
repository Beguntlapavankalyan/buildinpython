import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_csvs_by_prefix_with_header,
                                            read_parquet_using_full_path,
                                            write_parquet_or_csv)
from pyspark.sql import functions as F
from pyspark.sql.functions import col, trim

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

logging.info("Reading the Input arguments for step10")
args = getResolvedOptions(
    sys.argv,
    [
        "sq_historical_file_path",
        "sq_historical_file",
        "ds_demographicdatawithgeo",
        "output_folder",
        "lnk_geo_demo_output",
        "lnk_age_csv_output",
        "lnk_gender_out_output",
        "lnk_ethnic_cd_output",
        "lnk_income_out_output",
    ],
)

sq_historical_file_path = args["sq_historical_file_path"]
sq_historical_file = args["sq_historical_file"]
ds_demographicdatawithgeo = args["ds_demographicdatawithgeo"]
output_folder = args["output_folder"]
lnk_geo_demo_output = args["lnk_geo_demo_output"]
lnk_age_csv_output = args["lnk_age_csv_output"]
lnk_gender_out_output = args["lnk_gender_out_output"]
lnk_ethnic_cd_output = args["lnk_ethnic_cd_output"]
lnk_income_out_output = args["lnk_income_out_output"]

logging.info("Reading the Input files for step10")
lnk_historical = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=sq_historical_file_path,
    local_folder="",
    csvs_prefix=sq_historical_file,
    header=True,
    delimiter="|",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

logging.info("Reading the second input file")
lnk_monthly = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=ds_demographicdatawithgeo,
    force_spark_read=True,
)

logging.info("Perform the Union Operation")
lnk_demo_veh = lnk_historical.union(lnk_monthly)

logging.info("Removing the duplicates")
lnk_demo_veh = lnk_demo_veh.withColumn(
    "CombinedAge",
    F.when(F.col("CombinedAge").isNull(), "").otherwise(F.col("CombinedAge")),
)
lnk_demo_veh = lnk_demo_veh.withColumn("CombinedAge", trim(col("CombinedAge")))

lnk_demo_veh = lnk_demo_veh.withColumn(
    "Income", F.when(F.col("Income").isNull(), "").otherwise(F.col("Income"))
)

lnk_demo_veh = lnk_demo_veh.withColumn("Income", trim(col("Income")))

lnk_trim_data = lnk_demo_veh.drop_duplicates(["vin"])

# Perform the transformations
lnk_geo_demo = lnk_trim_data.select(
    "MANUFACTURER",
    "MODEL_YR",
    "MAKE_TXT",
    "MODEL_TXT",
    "TRIM_TXT",
    "MODEL_CLASS_TXT",
    "ACTIVITY_DATE",
    "MAX_ACTIVITY_DATE",
    "DISPOSAL_DATE",
    "REGISTRATION_STATUS",
    "BNBU",
    "PURCH_TYPE",
    "VIN",
    "SEQ_NO",
    "ZIP",
    "ZIP4",
    "COUNTRY_CD",
    "DRIVEWHEEL_TXT",
    "CYLINDER",
    "TAX_HP",
    "INDUCTION_TY",
    "STYLE",
    "MAX_DOOR_CT",
    "VEH_LENGTH",
    "VEH_WT",
    "MATCH_TYPE",
    "VEHICLE_INT_ID",
    "HOUSEHOLD",
    "COUNTS",
    "VIN_PATTERN",
    "SEQ_NO20",
    "CombinedAge",
    "GenderCode",
    "Number_of_Children",
    "Ethnic_Insight_Match_Flag",
    "Ethnicity_Detail",
    "Exp_Group_Code",
    "e_Tech_Group",
    "Income",
    "NVDB_PURCH_TYPE",
    "Autocount_Purchase_Date",
    "DLR_Name",
    "DLR_Number",
    "DLR_Type",
    "Lender_Type",
    "LHDR_NAME",
    "State_Code",
    "StateAbbr",
    "County_Cd",
    "County_Name",
    "Census_Tract",
    "Census_Block_Group",
    "Block_ID",
    "MCD_CCD_Code",
    "CBSA_CODE",
    "DMA_Code",
    "DMA_Name",
    "ZipCode",
    "FILLER_OCC_GROUP",
    "FILLER5",
    "FILLER7",
    "FILLER99",
    "FILLER98",
    "FILLER97",
    "FILLER_WORK_HARD",
    "FILLER_PENNY",
    "FILLER_CALL_CENTER",
    "FILLER35",
    "FILLER4",
)

logging.info("Applying the filter conditions for output dataframes")
filter_condition = lnk_trim_data.filter(col("SEQ_NO20").substr(1, 4) > "2016")
lnk_age = filter_condition.select(col("CombinedAge").alias("I1_Combined_Age"))
lnk_gender = filter_condition.select(col("GenderCode").alias("I1_Gender_Code"))
lnk_ethnic = filter_condition.select(col("Exp_Group_Code").alias("Exp_Group_Code"))
lnk_income = filter_condition.select(col("Income").alias("Estimated_Income_Range_V6"))

logging.info("Perform the Aggregations")
lnk_age_csv = lnk_age.groupBy("I1_Combined_Age").count()
lnk_gender_out = lnk_gender.groupBy("I1_Gender_Code").count()
lnk_ethnic_cd = lnk_ethnic.groupBy("Exp_Group_Code").count()
lnk_income_out = lnk_income.groupBy("Estimated_Income_Range_V6").count()

logging.info("Writing the lnk_geo_demo_output file")
write_parquet_or_csv(
    df=lnk_geo_demo,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=lnk_geo_demo_output,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

logging.info("Writing the lnk_age_csv_output file")
write_parquet_or_csv(
    df=lnk_age_csv,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=lnk_age_csv_output,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

logging.info("Writing lnk_gender_out_output file")
write_parquet_or_csv(
    df=lnk_gender_out,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=lnk_gender_out_output,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

logging.info("Writing lnk_ethnic_cd_output file")
write_parquet_or_csv(
    df=lnk_ethnic_cd,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=lnk_ethnic_cd_output,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

logging.info("Writing lnk_income_out_output file")
write_parquet_or_csv(
    df=lnk_income_out,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=lnk_income_out_output,
    delimiter="|",
    force_ignore_parquet=True,
    force_ignore_csv=False,
    force_csv=True,
    header=True,
)

spark.stop()
