import json
import logging
import os
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR


def lambda_handler(event, context):  # NOSONAR
    sns_client = boto3.client("sns")
    s3_client = boto3.client("s3")
    amp_dna_email_notification = os.getenv("amp_dna_email_notification")
    logging.info(f"Received event: {event}")

    try:
        # Extract error details
        event_data = json.loads(event["errordetails"]["Cause"])
        logging.info(f"Parsed event data: {event_data}")

        lambda_job_name = "one of the lambda job in stepfunction got failed"
        lambda_job_error = event_data.get(
            "errorMessage", "there is no errorMessage in lambda failure"
        )
        jobdetails = {
            "lambda_job_name": lambda_job_name,
            "lambda_job_error": lambda_job_error,
        }
        logging.info(f"Job details: {jobdetails}")

        client_name = event["parameters"]["segment"]
        year = event["parameters"]["year"]
        month = event["parameters"]["month"]
        job_audit_bucket_name = event["job_audit_bucket_name"]

        """
        # Extract input parameters
        execution_input = event.get("resultset", {}).get("Execution", {}).get("Input", {})
        client_name = execution_input["parameters"]["segment"]
        year = execution_input["parameters"]["year"]
        month = execution_input["parameters"]["month"]

        job_audit_bucket_name = execution_input["job_audit_bucket_name"]
        amp_dna_email_notification = execution_input
        """
        # Prepare SNS message
        sns_topic_arn = amp_dna_email_notification
        subject = f"Glue Job failed for {client_name}_year={year}_month={month}"
        message_body = f"AMP_Segment=  {client_name}\n  glue_job_details: {jobdetails}"

        # Construct message_json
        message_json = json.dumps({"subject": subject, "message_body": message_body})

        # Send message to SNS topic
        sns_client.publish(TopicArn=sns_topic_arn, Message=message_json)

        print("Message sent to SNS topic.")

        # Create header and data row for CSV
        header = [
            "segment",
            "year",
            "month",
            "stepfunction state name",
            "status Description",
        ]
        data = [client_name, year, month, lambda_job_name, lambda_job_error]

        # Create properties file content
        properties_content = f"""
        segment={client_name}
        year={year}
        month={month}
        stepfunction_state_name={lambda_job_name}
        status_description={lambda_job_error}
        """
        logging.info(f"Properties Content: {properties_content}")

        # Save properties content to S3
        properties_key = (
            f"segment={client_name}/{client_name}_year_{year}_month_{month}.jobaudit"
        )

        # Delete existing file if it exists
        try:
            s3_client.delete_object(Bucket=job_audit_bucket_name, Key=properties_key)
            logging.info(
                f"Deleted existing file: s3://{job_audit_bucket_name}/{properties_key}"
            )
        except s3_client.exceptions.NoSuchKey:
            logging.error(
                f"No existing file to delete: s3://{job_audit_bucket_name}/{properties_key}"
            )
        except Exception as e:
            logging.error(f"Error deleting existing file: {e}")

        try:
            s3_client.put_object(
                Bucket=job_audit_bucket_name,
                Key=properties_key,
                Body=properties_content,
            )
            logging.info(
                f"Properties file saved to s3://{job_audit_bucket_name}/{properties_key}"
            )
        except Exception as e:
            logging.error(f"Error saving properties file to S3: {e}")

        return {
            "statusCode": 200,
            "body": "Message sent to SNS topic and properties file updated successfully",
        }

    except Exception as e:
        logging.error(f"Error processing event: {e}")
        return {"statusCode": 500, "body": f"Error processing event: {e}"}
