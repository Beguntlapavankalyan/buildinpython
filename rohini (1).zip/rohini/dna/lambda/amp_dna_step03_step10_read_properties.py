import json
import logging
import os
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

# Initialize AWS clients
sns_client = boto3.client("sns")


def lambda_handler(event, context):  # NOSONAR
    """
    This Lambda function reads the properties file from the resultset,
    reads the content of the file, and provides inputs to the Step Function 2.
    :param event: resultset
    :param context: None
    :return: JSON object
    """
    # Retrieve environment variables
    logging.info("Retrieving environment variables")

    job_audit_bucket_name = os.getenv("job_audit_bucket_name")
    environment = os.getenv("environment")
    amp_dna_trigger_email = os.getenv("amp_dna_trigger_email")
    amp_dna_trigger_qa_email = os.getenv("amp_dna_trigger_qa_email")
    amp_dna_processing = os.getenv("amp_dna_processing")
    amp_test_dna = os.getenv("amp_test_dna")
    amp_dna_step03_glue_job_name = os.getenv("amp_dna_step03_glue_job_name")
    amp_dna_step04_glue_job_name = os.getenv("amp_dna_step04_glue_job_name")
    amp_dna_step05_glue_job_name = os.getenv("amp_dna_step05_glue_job_name")
    amp_dna_step06_glue_job_name = os.getenv("amp_dna_step06_glue_job_name")
    amp_dna_step07_glue_job_name = os.getenv("amp_dna_step07_glue_job_name")
    amp_dna_step08_glue_job_name = os.getenv("amp_dna_step08_glue_job_name")
    amp_dna_step09_glue_job_name = os.getenv("amp_dna_step09_glue_job_name")
    amp_dna_step9_1_glue_job_name = os.getenv("amp_dna_step9_1_glue_job_name")
    amp_dna_step10_glue_job_name = os.getenv("amp_dna_step10_glue_job_name")
    amp_dna_qa_glue_job_name = os.getenv("amp_dna_qa_glue_job_name")
    amp_dna_qa_output_bucketname = os.getenv("amp_dna_qa_output_bucketname")
    amp_start_glue_crawler_lambda_name = os.getenv("amp_start_glue_crawler_lambda_name")
    amp_all_segments_crawler_name = os.getenv("amp_all_segments_crawler_name")
    amp_dna_qa_success_fail_email_alert_lambda_name = os.getenv(
        "amp_dna_qa_success_fail_email_alert_lambda_name"
    )
    amp_dna_all_job_success_lambda_name = os.getenv(
        "amp_dna_all_job_success_lambda_name"
    )

    try:
        # Retrieve execution input from the event
        logging.info("Retrieving execution input from the event")
        execution_input = (
            event.get("resultset", {}).get("Execution", {}).get("Input", {})
        )

        print(execution_input)

        parameters = execution_input.get("parameters", {})
        file_names = execution_input.get("file_names", {})
        folder_names = execution_input.get("folder_names", {})

        # Extract year, month, and segment from parameters
        logging.info("Extracting year, month, and segment from parameters")
        folder_year = parameters.get("year")
        folder_month = parameters.get("month")
        folder_segment = parameters.get("segment")

        if not (folder_year and folder_month and folder_segment):
            raise ValueError(
                "Missing required folder information (year, month, segment)"
            )

        # Define folder structures
        logging.info("Defining folder structures")
        folder_structure_for_processing = f"s3://{amp_dna_processing}/segment={folder_segment}/year={folder_year}/month={folder_month}"
        folder_structure_for_ems_output = f"s3://{amp_dna_processing}/segment={folder_segment}/year={folder_year}/month={folder_month}/emsouput"
        folder_structure_for_qa_output = f"s3://{amp_dna_qa_output_bucketname}/segment={folder_segment}/year={folder_year}/month={folder_month}/qaoutput"

        # Input and output folder parameters for dna_step00
        logging.info("Defining input and output folder parameters for dna_step00")
        output_folderforstep1 = f"{folder_structure_for_processing}/Step00"
        qa_sq_ems_input_file = "QA_sq_EMS_Input"
        ds_ems_input_file = "ds_ems_input_file"
        sq_used_count_file = "sq_used_count"
        vehicle_data_all_data_file = "vehicle_data_all_data"

        # Input and output folder parameters for dna_step03
        logging.info("Defining input and output folder parameters for dna_step03")
        sftp_file_name_zip = parameters.get("emsoutput")
        auto_dna_return_file = os.path.splitext(sftp_file_name_zip)[0]
        auto_dna_return_file_path = folder_structure_for_ems_output
        ems_input_path = (
            f"{folder_structure_for_processing}/Step00/ds_ems_input_file.parquet/"
        )
        output_folder_for_step03 = f"{folder_structure_for_processing}/Step03"
        lnk_pr_dropped = "PR_records"
        lnk_ems_to_qa_file = "sq_QA_EMS_Updated"
        lnk_ems_updated = "EMS_Output_Updated"
        lnk_ems_updated_full = "ds_Output_Updated_Full"
        required_columns_for_step03 = "513"
        sq_used_count_csv_input_file = (
            f"{folder_structure_for_processing}/Step00/sq_used_count.csv/"
        )

        # Inputs for STS transfer
        logging.info("Defining inputs for STS transfer")
        output_bucket_onprem = amp_dna_processing
        output_prefix_onprem = (
            f"segment={folder_segment}/year={folder_year}/month={folder_month}/emsouput"
        )
        sftp_file_name = f"{sftp_file_name_zip}"

        # Input and output folder parameters for dna_step04
        logging.info("Defining input and output folder parameters for dna_step04")
        ds_ems_output_updated = (
            f"{folder_structure_for_processing}/Step03/EMS_Output_Updated.parquet/"
        )
        ds_ems_input = (
            f"{folder_structure_for_processing}/Step00/ds_ems_input_file.parquet/"
        )
        ds_dna_extract = (
            f"{folder_structure_for_processing}/Step00/vehicle_data_all_data.parquet/"
        )
        ds_ca_fix = f"{folder_structure_for_processing}/Step00/ds_fixed_seq_numbers_file.parquet/"
        db2_evd = folder_names.get("step04EVD")
        db2_evd_file = file_names.get("step04EVD")
        ds_full_vehicle_file = "ds_full_vehicle_file"
        ds_vehicle_detail = "ds_Vehicle_Detail"
        sq_debug_file = "sq_debug_file"
        sq_fixed_seq_num_op_file = "sq_fixed_seq_num"
        outputpath_for_steop04 = f"{folder_structure_for_processing}/Step04"

        # Input and output folder parameters for dna_step05
        logging.info("Defining input and output folder parameters for dna_step05")
        inputpath_for_step05 = (
            f"{folder_structure_for_processing}/Step04/ds_Vehicle_Detail.parquet/"
        )
        outputfilename1_for_step05 = "ds_full_vehicle_data"
        outputfilename2_for_step05 = "Vehicle_One"
        outputfilename3_for_step05 = "ds_standard_vehicle"
        outputfilename4_for_step05 = "QA_Vehicle_File"
        outputfilepath_for_step05 = f"{folder_structure_for_processing}/Step05"

        # Input and output folder parameters for dna_step06
        logging.info("Defining input and output folder parameters for dna_step06")
        vehicle_11 = "Vehicle_11"
        ds_full_vehicle_data = (
            f"{folder_structure_for_processing}/Step05/ds_full_vehicle_data.parquet/"
        )

        lnk_veh_standard_outputpath = f"{folder_structure_for_processing}/Step06"

        # Input and output folder parameters for dna_step07
        logging.info("Defining input and output folder parameters for dna_step07")
        vehicle_standard = "Vehicle_Standard"
        ds_standard_vehicle = (
            f"{folder_structure_for_processing}/Step05/ds_standard_vehicle.parquet/"
        )
        lnk_veh_standard_outputpath_for_step07 = (
            f"{folder_structure_for_processing}/Step07"
        )

        # Input and output folder parameters for dna_step08
        logging.info("Defining input and output folder parameters for dna_step08")
        output_folder_for_step08 = f"{folder_structure_for_processing}/Step08"
        demographic_output_file = "Demographic_File"
        demographic_std_output_file = "Demographic_Standard"
        sq_demographic_velocity_output_file = "sq_Demographic_Velocity"
        ds_full_vehicle_seqnum_input_file = (
            f"{folder_structure_for_processing}/Step06/ds_full_vehicle_seqNum.parquet"
        )
        ems_output_updated_input_file = (
            f"{folder_structure_for_processing}/Step03/EMS_Output_Updated.parquet/"
        )
        sq_ems_input_file = (
            f"{folder_structure_for_processing}/Step00/ds_ems_input_file.parquet/"
        )
        state_county_dma_input_file = file_names.get("step08statecountydma")
        input_folder_state_county = folder_names.get("step08statecountydma")
        ethnic_codes_input_file = file_names.get("step09ethnicmapping")
        input_folder_ethnic = folder_names.get("step091ethnicmapping")

        # Input and output folder parameters for dna_step09
        logging.info("Defining input and output folder parameters for dna_step09")
        output_folder_for_step09 = f"{folder_structure_for_processing}/Step09"
        sq_age_file = "sq_Age"
        sq_ethnic_file = "sq_Ethnic"
        sq_gender_file = "sq_Gender"
        sq_income_file = "sq_Income"
        ds_demo_data_file = "ds_DemoData"
        demo_geo_ethnic = "DemoGeoEthnic"
        sq_ethnic_codes_path = folder_names.get("step09ethnicmapping")
        sq_ethnic_codes_path_file = file_names.get("step09ethnicmapping")
        state_county_zip_dna_path = folder_names.get("step09statecountydma")
        state_county_zip_dna_path_file = file_names.get("step09statecountydma")
        ds_ems_input_path = (
            f"{folder_structure_for_processing}/Step00/ds_ems_input_file.parquet/"
        )
        ds_ems_output_updated_path = (
            f"{folder_structure_for_processing}/Step03/ds_Output_Updated_Full.parquet/"
        )
        ds_full_vehicle_data_path = (
            f"{folder_structure_for_processing}/Step04/ds_full_vehicle_file.parquet/"
        )

        # Input and output folder parameters for dna_step09_1
        logging.info("Defining input and output folder parameters for dna_step09_1")
        demo_geo_ethnic_ds_input_file = (
            f"{folder_structure_for_processing}/Step09/DemoGeoEthnic.parquet/"
        )
        ethnic_codes_input_file_for_step9_1 = file_names.get("step091ethnicmapping")
        input_folder_ethnic_for_step9_1 = folder_names.get("step091ethnicmapping")
        output_folder_for_step9_1 = f"{folder_structure_for_processing}/Step09_1"
        sq_demogeo_csv_output_file = "sq_DemoGeo"

        # Input and output folder parameters for dna_step10
        logging.info("Defining input and output folder parameters for dna_step10")
        sq_historical_file_path = folder_names.get("step10previousfile")
        sq_historical_file = file_names.get("step10previousfile")
        output_folder_for_step10 = f"{folder_structure_for_processing}/Step10"
        ds_demographicdatawithgeo = (
            f"{folder_structure_for_processing}/Step09/ds_DemoData.parquet/"
        )
        lnk_age_csv_output = "sq_Age"
        lnk_ethnic_cd_output = "sq_Ethnic"
        lnk_gender_out_output = "sq_Gender"
        lnk_geo_demo_output = "sq_DemoGeo_csv"
        lnk_income_out_output = "sq_Income"

        qa_ems_input = f"{folder_structure_for_processing}/Step00/QA_sq_EMS_Input.txt/"
        qa_ems_output = (
            f"{folder_structure_for_processing}/Step03/sq_QA_EMS_Updated.txt/"
        )
        qa_final_demo = (
            f"{folder_structure_for_processing}/Step08/Demographic_File.txt/"
        )
        qa_final_veh = f"{folder_structure_for_processing}/Step06/Vehicle_11.txt/"
        qa_interim_one = f"{folder_structure_for_processing}/Step05/Vehicle_One.txt/"
        qa_interim_two = (
            f"{folder_structure_for_processing}/Step05/QA_Vehicle_File.txt/"
        )
        qa_s3_path = folder_structure_for_qa_output
        qa_std_demo = (
            f"{folder_structure_for_processing}/Step08/Demographic_Standard.txt/"
        )
        qa_std_vehicle = (
            f"{folder_structure_for_processing}/Step07/Vehicle_Standard.txt/"
        )
        qa_velocity = (
            f"{folder_structure_for_processing}/Step08/sq_Demographic_Velocity.txt/"
        )
        qa_am_insource = parameters.get("step00monthlyinput")
        qa_amkt_extract = parameters.get("step00dnaextract")

        # Prepare JSON payload
        logging.info("Preparing JSON payload")
        input_json = {
            "amp_dna_qa_success_fail_email_alert_lambda_name": amp_dna_qa_success_fail_email_alert_lambda_name,
            "amp_dna_all_job_success_lambda_name": amp_dna_all_job_success_lambda_name,
            "amp_dna_trigger_qa_email": amp_dna_trigger_qa_email,
            "job_audit_bucket_name": job_audit_bucket_name,
            "qa_ems_input": qa_ems_input,
            "qa_ems_output": qa_ems_output,
            "qa_final_demo": qa_final_demo,
            "qa_final_veh": qa_final_veh,
            "qa_interim_one": qa_interim_one,
            "qa_interim_two": qa_interim_two,
            "qa_s3_path": qa_s3_path,
            "qa_std_demo": qa_std_demo,
            "qa_std_vehicle": qa_std_vehicle,
            "qa_velocity": qa_velocity,
            "qa_am_insource": qa_am_insource,
            "qa_amkt_extract": qa_amkt_extract,
            "output_bucket_onprem": output_bucket_onprem,
            "output_prefix_onprem": output_prefix_onprem,
            "sftp_file_name": sftp_file_name,
            "sq_demogeo_csv_output_file": sq_demogeo_csv_output_file,
            "output_folder_for_step9_1": output_folder_for_step9_1,
            "inputpath_for_step05": inputpath_for_step05,
            "outputfilename1_for_step05": outputfilename1_for_step05,
            "outputfilename2_for_step05": outputfilename2_for_step05,
            "outputfilename3_for_step05": outputfilename3_for_step05,
            "outputfilename4_for_step05": outputfilename4_for_step05,
            "outputfilepath_for_step05": outputfilepath_for_step05,
            "lnk_income_out_output": lnk_income_out_output,
            "lnk_geo_demo_output": lnk_geo_demo_output,
            "lnk_gender_out_output": lnk_gender_out_output,
            "lnk_ethnic_cd_output": lnk_ethnic_cd_output,
            "lnk_age_csv_output": lnk_age_csv_output,
            "ds_demographicdatawithgeo": ds_demographicdatawithgeo,
            "output_folder_for_step10": output_folder_for_step10,
            "sq_historical_file": sq_historical_file,
            "sq_historical_file_path": sq_historical_file_path,
            "output_folder_for_step09": output_folder_for_step09,
            "sq_Age_file": sq_age_file,
            "sq_Ethnic_file": sq_ethnic_file,
            "sq_Gender_file": sq_gender_file,
            "sq_Income_file": sq_income_file,
            "ds_DemoData_file": ds_demo_data_file,
            "DemoGeoEthnic": demo_geo_ethnic,
            "sq_Ethnic_Codes_path": sq_ethnic_codes_path,
            "sq_Ethnic_Codes_path_file": sq_ethnic_codes_path_file,
            "State_County_Zip_DMA_path": state_county_zip_dna_path,
            "State_County_Zip_DMA_path_file": state_county_zip_dna_path_file,
            "ds_EMS_Input_path": ds_ems_input_path,
            "ds_EMS_Output_Updated_path": ds_ems_output_updated_path,
            "ds_full_vehicle_data_path": ds_full_vehicle_data_path,
            "demo_geo_ethnic_ds_input_file": demo_geo_ethnic_ds_input_file,
            "ethnic_codes_input_file_for_step9_1": ethnic_codes_input_file_for_step9_1,
            "input_folder_ethnic_for_step9_1": input_folder_ethnic_for_step9_1,
            "ethnic_codes_input_file": ethnic_codes_input_file,
            "input_folder_ethnic": input_folder_ethnic,
            "output_folder_for_step08": output_folder_for_step08,
            "demographic_output_file": demographic_output_file,
            "demographic_std_output_file": demographic_std_output_file,
            "sq_demographic_velocity_output_file": sq_demographic_velocity_output_file,
            "ds_full_vehicle_seqnum_input_file": ds_full_vehicle_seqnum_input_file,
            "ds_full_vehicle_seqNum": "ds_full_vehicle_seqNum",
            "ems_output_updated_input_file": ems_output_updated_input_file,
            "sq_ems_input_file": sq_ems_input_file,
            "state_county_dma_input_file": state_county_dma_input_file,
            "input_folder_state_county": input_folder_state_county,
            "Vehicle_Standard": vehicle_standard,
            "ds_standard_vehicle": ds_standard_vehicle,
            "lnk_Veh_standard_outputpath_for_step07": lnk_veh_standard_outputpath_for_step07,
            "Vehicle_11": vehicle_11,
            "ds_full_vehicle_data": ds_full_vehicle_data,
            "ds_ems_output_updated": ds_ems_output_updated,
            "lnk_Veh_standard_outputpath": lnk_veh_standard_outputpath,
            "ds_ems_input": ds_ems_input,
            "ds_dna_extract": ds_dna_extract,
            "ds_ca_fix": ds_ca_fix,
            "db2_evd": db2_evd,
            "db2_evd_file": db2_evd_file,
            "ds_full_vehicle_file": ds_full_vehicle_file,
            "ds_vehicle_detail": ds_vehicle_detail,
            "sq_debug_file": sq_debug_file,
            "sq_fixed_seq_num_op_file": sq_fixed_seq_num_op_file,
            "outputpath_for_steop04": outputpath_for_steop04,
            "Auto_DNA_Return_File": auto_dna_return_file,
            "Auto_DNA_Return_File_path": auto_dna_return_file_path,
            "Output_Folder_for_step03": output_folder_for_step03,
            "ems_input_path": ems_input_path,
            "lnk_PR_dropped": lnk_pr_dropped,
            "lnk_ems_to_qa_file": lnk_ems_to_qa_file,
            "lnk_ems_updated": lnk_ems_updated,
            "lnk_ems_updated_full": lnk_ems_updated_full,
            "required_columns_for_step03": required_columns_for_step03,
            "sq_used_count_csv_input_file": sq_used_count_csv_input_file,
            "folder_names": folder_names,
            "file_names": file_names,
            "parameters": parameters,
            "environment": environment,
            "amp_test_dna": amp_test_dna,
            "output_folderforstep1": output_folderforstep1,
            "qa_sq_ems_input_file": qa_sq_ems_input_file,
            "ds_ems_input_file": ds_ems_input_file,
            "sq_used_count_file": sq_used_count_file,
            "vehicle_data_all_data_file": vehicle_data_all_data_file,
            "amp_dna_step03_glue_job_name": amp_dna_step03_glue_job_name,
            "amp_dna_step04_glue_job_name": amp_dna_step04_glue_job_name,
            "amp_dna_step05_glue_job_name": amp_dna_step05_glue_job_name,
            "amp_dna_step06_glue_job_name": amp_dna_step06_glue_job_name,
            "amp_dna_step07_glue_job_name": amp_dna_step07_glue_job_name,
            "amp_dna_step08_glue_job_name": amp_dna_step08_glue_job_name,
            "amp_dna_step09_glue_job_name": amp_dna_step09_glue_job_name,
            "amp_dna_step9_1_glue_job_name": amp_dna_step9_1_glue_job_name,
            "amp_dna_step10_glue_job_name": amp_dna_step10_glue_job_name,
            "amp_dna_qa_glue_job_name": amp_dna_qa_glue_job_name,
            "amp_start_glue_crawler_lambda_name": amp_start_glue_crawler_lambda_name,
            "amp_all_segments_crawler_name": amp_all_segments_crawler_name,
        }

        # Print formatted JSON
        formatted_json = json.dumps(input_json, indent=2)
        logging.info(f"formatted_json: {formatted_json}")

        # Send message to SNS topic
        try:
            logging.info("Sending message to SNS topic")
            sns_client.publish(
                TopicArn=amp_dna_trigger_email,
                Message=json.dumps(input_json),  # Convert to JSON string for SNS
                Subject="DNA Step Function Input for step02",
            )
        except Exception as e:
            print(f"Error publishing to SNS: {e}")
            raise e

    except Exception as e:
        print(f"Error processing event: {e}")
        raise e

    # Return JSON object directly in body
    logging.info("Returning JSON object")
    return {"statusCode": 200, "body": input_json}  # Return the JSON object directly
