import json
import logging
import os
import sys
import tempfile

import boto3
import pysftp
from botocore.exceptions import ClientError

# Initialize clients
s3_client = boto3.client("s3")
events_client = boto3.client("events")
stepfunctions_client = boto3.client("stepfunctions")

# Configure logging
logging.basicConfig(level=print, stream=sys.stdout)  # NOSONAR


class EventBridgeRuleNotFound(Exception):
    pass


def get_secret(secret_name):
    try:
        client = boto3.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response["SecretString"])
        return secret
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        raise e


def get_secret_from_another_secret(secret_name):
    """
    Get the secret from the Secret Manager.
    :param environment:
    :param secret_client:
    :return:
    """
    try:
        secret_client = boto3.client(
            service_name="secretsmanager", region_name="us-east-1"
        )
        print(f"Retrieving secret: {secret_name}")
        return secret_client.get_secret_value(SecretId=secret_name).get("SecretString")
    except ClientError as e:
        logging.error(f"Failed to get secret: {e}")
        raise e


def cleanup_temp_files():
    """
    Delete any temporary files in the /tmp directory that may have been left from previous runs.
    """
    temp_dir = tempfile.gettempdir()
    for filename in os.listdir(temp_dir):
        if filename.startswith("tmp"):
            try:
                os.remove(os.path.join(temp_dir, filename))
                logging.info(f"Removed previous temporary file: {filename}")
            except Exception as e:
                logging.error(
                    f"Failed to remove previous temporary file: {filename}. Error: {e}"
                )


def check_sftp_file_exists(secret_name, sftp_file_name):
    secret = get_secret(secret_name)
    print(secret)
    secret_map = secret["secret_private_key_name"]
    print(secret_map)

    sftp_host = secret["Server"]
    sftp_host = f"{sftp_host}"
    print(sftp_host)
    sftp_username = secret["User"]
    sftp_username = f"{sftp_username}"
    print(sftp_username)

    sftp_remote_dir = secret["outboundfolder"]
    sftp_remote_dir = f"{sftp_remote_dir}"
    print(sftp_remote_dir)
    sftp_file_name_with_zip = f"{sftp_file_name}"
    print(sftp_file_name_with_zip)
    private_key = get_secret_from_another_secret(secret_map)
    print(private_key)
    print("Writing private key to temporary file")

    tmp_private_key_path = None
    try:
        with tempfile.NamedTemporaryFile("w", delete=False) as tmp_key_file:
            tmp_key_file.write(private_key)
            tmp_private_key_path = tmp_key_file.name
            print(f"Temporary private key path: {tmp_private_key_path}")

        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None

        try:
            with pysftp.Connection(
                host=sftp_host,
                username=sftp_username,
                private_key=tmp_private_key_path,
                cnopts=cnopts,
            ) as sftp:
                print("SFTP connection established.")
                logging.info("SFTP connection established.")
                sftp.chdir(sftp_remote_dir)
                sftp.stat(sftp_file_name_with_zip)
                file_exists = True
        except FileNotFoundError as e:
            print(f"File Not Found: {e}")
            file_exists = False
        except Exception as e:
            logging.error(f"An error occurred: {e}")
            raise e
    finally:
        if tmp_private_key_path and os.path.exists(tmp_private_key_path):
            os.remove(tmp_private_key_path)
            print(f"Temporary private key file {tmp_private_key_path} deleted.")

    return file_exists


def lambda_handler(event, context):  # NOSONAR
    """
    This lambda function will trigger the Step function 2, if the file not exists then
    enable the event bridge rule to trigger this lambda to check the file exists in sftp or not.
    If the file exists then disable this lambda and enable_eventbridge_rule_trigger_step to trigger
    the step function.
    :param event: event
    :param context: None
    :return: file_exists
    """

    resultset = event.get("resultset")

    logging.info(f"Resultset: {resultset}")
    if resultset is None:
        resultset = event

    sftp_file_name = resultset["Execution"]["Input"]["parameters"]["emsoutput"]
    secret_name = resultset["Execution"]["Input"]["secret_name"]
    amp_step03_step10_readproperties_lambda_name = resultset["Execution"]["Input"][
        "amp_step03_step10_readproperties_lambda_name"
    ]
    amp_disable_event_bridge_lambda_name = os.getenv(
        "amp_disable_event_bridge_lambda_name"
    )
    amp_dna_all_job_success_lambda_name = os.getenv(
        "amp_dna_all_job_success_lambda_name"
    )

    amp_step03_step10_integration_state_machine_arn = os.getenv(
        "amp_step03_step10_integration_state_machine_arn"
    )

    amp_dna_this_lambda_name_arn = os.getenv("amp_dna_this_lambda_name_arn")

    amp_iam_role_arn = os.getenv("amp_iam_role_arn")

    # Event Bridge Rule Names
    logging.info("Extracting EventBridge rule names from environment variables")
    trigger_this_lambda_eventbridge_rule_name = os.getenv(
        "trigger_this_lambda_eventbridge_rule_name"
    )
    trigger_step_function_2_eventbridge_rule_name = os.getenv(
        "trigger_step_function_2_eventbridge_rule_name"
    )

    # Prepare step_input
    step_input = {
        "resultset": resultset,
        "amp_step03_step10_readproperties_lambda_name": amp_step03_step10_readproperties_lambda_name,
        "trigger_step_function_2_eventbridge_rule_name": trigger_step_function_2_eventbridge_rule_name,
        "amp_disable_event_bridge_lambda_name": amp_disable_event_bridge_lambda_name,
        "amp_dna_all_job_success_lambda_name": amp_dna_all_job_success_lambda_name,
    }

    logging.info("Checking if the file exists")

    file_exists = check_sftp_file_exists(secret_name, sftp_file_name)
    if file_exists:
        logging.info("File exists")
        print("File exists")

        try:
            logging.info(
                f"Disabling EventBridge rule {trigger_this_lambda_eventbridge_rule_name}"
            )
            print(
                f"Disabling EventBridge rule {trigger_this_lambda_eventbridge_rule_name}"
            )
            disable_eventbridge_rule_lambda(trigger_this_lambda_eventbridge_rule_name)
            logging.info(
                f"EventBridge rule '{trigger_this_lambda_eventbridge_rule_name}' disabled successfully."
            )

            # Trigger Step Function
            logging.info("Trigger Step Function 2")
            enable_eventbridge_rule_trigger_step(
                trigger_step_function_2_eventbridge_rule_name,
                step_input,
                amp_step03_step10_integration_state_machine_arn,
                amp_iam_role_arn,
            )
            print("Step Function 2 triggered successfully.")

        except Exception as e:
            logging.error(f"Error: {e}")
            raise e
    else:
        # Enable the EventBridge rule to check for the file again
        logging.info("Enable the EventBridge rule to check for the file again")
        enable_eventbridge_rule_trigger_lambda(
            trigger_this_lambda_eventbridge_rule_name,
            resultset,
            amp_dna_this_lambda_name_arn,
        )

    return {"status": file_exists}


def enable_eventbridge_rule_trigger_step(
    rule_name,
    target_input,
    amp_step03_step10_integration_state_machine_arn,
    amp_iam_role_arn,
):
    """
    Enable the event bridge rule to trigger the step function 2
    :param rule_name: rule_name
    :param target_input: dict - Input for the target.
    :param amp_step03_step10_integration_state_machine_arn: str - ARN of the step function state machine.
    :param amp_iam_role_arn: str - ARN of the IAM role.
    :return: None
    """
    try:
        # Check if the rule exists
        logging.info(
            f"Check if the rule exists: Enabling EventBridge rule: {rule_name}"
        )
        response = events_client.describe_rule(Name=rule_name)
        if response["State"] == "DISABLED":
            print("Enabling EventBridge rule")
            events_client.enable_rule(Name=rule_name)
            logging.info(f"EventBridge rule '{rule_name}' enabled.")
        else:
            print("EventBridge rule is already enabled")
            logging.info(f"EventBridge rule '{rule_name}' is already enabled.")

        logging.info(f"Remove existing targets: {rule_name}")
        print(f"Remove existing targets: {rule_name}")
        delete_existing_event_targets(rule_name)

        logging.info(f"Add target with input: {rule_name}")
        print(
            f"amp_step03_step10_integration_arn {amp_step03_step10_integration_state_machine_arn}"
        )
        print(f"amp_iam_role_arn: {amp_iam_role_arn}")
        events_client.put_targets(
            Rule=rule_name,
            Targets=[
                {
                    "Id": "1",
                    "Arn": amp_step03_step10_integration_state_machine_arn,
                    "Input": json.dumps(target_input),
                    "RoleArn": amp_iam_role_arn,
                }
            ],
        )
        logging.info(f"Input to target sent: {target_input}")
    except events_client.exceptions.ResourceNotFoundException:
        logging.error(f"EventBridge rule step function '{rule_name}' does not exist.")
        raise EventBridgeRuleNotFound(f"EventBridge rule '{rule_name}' does not exist.")
    except Exception as e:
        logging.error(f"Error enabling EventBridge rule: {e}")
        raise e


def enable_eventbridge_rule_trigger_lambda(
    trigger_this_lambda_eventbridge_rule_name, result_set, amp_dna_this_lambda_name_arn
):
    """
    Enable event bridge rule to trigger this lambda to check the file exists
    :param amp_dna_this_lambda_name_arn: str - ARN of the Lambda function.
    :param trigger_this_lambda_eventbridge_rule_name: str - Name of the EventBridge rule.
    :param result_set: dict - Result set to send as input.
    :return: None
    """
    try:
        response = events_client.describe_rule(
            Name=trigger_this_lambda_eventbridge_rule_name
        )
        if response["State"] == "DISABLED":
            events_client.enable_rule(Name=trigger_this_lambda_eventbridge_rule_name)
            logging.info(
                f"EventBridge rule '{trigger_this_lambda_eventbridge_rule_name}' enabled."
            )
        else:
            logging.info(
                f"EventBridge rule '{trigger_this_lambda_eventbridge_rule_name}' is already enabled."
            )

        logging.info(
            f"Remove existing targets: {trigger_this_lambda_eventbridge_rule_name}"
        )
        delete_existing_event_targets(trigger_this_lambda_eventbridge_rule_name)

        # Add target with input, without RoleArn
        logging.info("Add target with input, without RoleArn")
        events_client.put_targets(
            Rule=trigger_this_lambda_eventbridge_rule_name,
            Targets=[
                {
                    "Id": "2",
                    "Arn": amp_dna_this_lambda_name_arn,
                    "Input": json.dumps(result_set),
                }
            ],
        )
        logging.info(f"Input to target sent: {result_set}")
    except events_client.exceptions.ResourceNotFoundException:
        logging.error(
            f"EventBridge rule lambda function '{trigger_this_lambda_eventbridge_rule_name}' does not exist."
        )
        raise EventBridgeRuleNotFound(
            f"EventBridge rule '{trigger_this_lambda_eventbridge_rule_name}' does not exist."
        )
    except Exception as e:
        logging.error(f"Error enabling EventBridge rule: {e}")
        raise e


def disable_eventbridge_rule_lambda(rule_name):
    """
    Disable event bridge rule that triggers this lambda
    :param rule_name: str - Name of the EventBridge rule.
    :return: None
    """
    try:
        events_client.disable_rule(Name=rule_name)
        logging.info(f"EventBridge rule '{rule_name}' disabled.")
    except events_client.exceptions.ResourceNotFoundException:
        raise EventBridgeRuleNotFound(f"EventBridge rule '{rule_name}' does not exist.")
    except Exception as e:
        logging.error(f"Error disabling EventBridge rule: {e}")
        raise e


def delete_existing_event_targets(rule_name):
    """
    Delete the existing targets.
    :param rule_name: str - Name of the EventBridge rule.
    :return: None
    """
    # Remove existing targets
    targets = events_client.list_targets_by_rule(Rule=rule_name)["Targets"]
    if targets:
        target_ids = [target["Id"] for target in targets]
        events_client.remove_targets(Rule=rule_name, Ids=target_ids)
        logging.info(f"Existing targets removed: {target_ids}")
