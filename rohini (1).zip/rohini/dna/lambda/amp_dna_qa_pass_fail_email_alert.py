import csv
import datetime
import logging
import sys
from io import StringIO

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR


def lambda_handler(event, context):  # NOSONAR
    """
    This Lambda function reads the last modified file from the specified S3 path,
    reads the content of the file, and sends an email notification to the specified SNS topic.
    :param event: amp_dna_email_notification, segment, s3_path
    :param context: None
    :return: File analysis sent to SNS topic successfully
    """
    s3 = boto3.client("s3")
    sns = boto3.client("sns")

    amp_dna_email_notification = event["amp_dna_email_notification"]
    segment = event["segment"]
    s3_path = event["s3_path"]

    if not s3_path.startswith("s3://"):
        logging.error("Invalid S3 path provided in the event.")
        return {"statusCode": 400, "body": "Invalid S3 path provided in the event."}

    bucket_name, folder_path = s3_path[len("s3://") :].split("/", 1)
    env = next(
        (e for e in ["sandbox", "dev", "uat", "prod"] if e in bucket_name), "unknown"
    )

    try:
        logging.info(f"Reading the last modified file from the S3 path: {s3_path}")
        response = s3.list_objects_v2(
            Bucket=bucket_name, Prefix=folder_path, Delimiter="/"
        )
        if "CommonPrefixes" not in response:
            return {
                "statusCode": 404,
                "body": "No subfolders found in the specified folder.",
            }

        overall_results = []
        for prefix in response["CommonPrefixes"]:
            subfolder = prefix["Prefix"]
            subfolder_response = s3.list_objects_v2(
                Bucket=bucket_name, Prefix=subfolder
            )
            if "Contents" not in subfolder_response:
                continue

            files = subfolder_response["Contents"]
            file_key = max(files, key=lambda x: x["LastModified"])["Key"]

            response = s3.get_object(Bucket=bucket_name, Key=file_key)
            file_content = response["Body"].read().decode("utf-8")
            file_url = f"https://{bucket_name}.s3.amazonaws.com/{file_key}"

            reader = csv.DictReader(StringIO(file_content))
            subfolder_total_count = subfolder_pass_count = subfolder_fail_count = 0
            subfolder_failed_content = []

            for row in reader:
                logging.info(f"Row: {row}")
                subfolder_total_count += 1
                if row.get("result") == "PASS":
                    subfolder_pass_count += 1
                elif row.get("result") == "FAIL":
                    subfolder_fail_count += 1
                    row["file_url"] = file_url
                    subfolder_failed_content.append(row)

            subfolder_http_url = f"https://us-east-1.console.aws.amazon.com/s3/buckets/{bucket_name}?region=us-east-1&bucketType=general&prefix={subfolder}&showversions=false"
            overall_results.append(
                {
                    "subfolder": subfolder,
                    "subfolder_url": subfolder_http_url,
                    "total_count": subfolder_total_count,
                    "pass_count": subfolder_pass_count,
                    "fail_count": subfolder_fail_count,
                    "failed_content": subfolder_failed_content,
                }
            )

        message_parts = []
        overall_status = "Passed"
        for result in overall_results:
            failed_content_str = (
                "\n\n".join(
                    [
                        ", ".join(
                            [f"{k}: {v}" for k, v in row.items() if k != "file_url"]
                        )
                        for row in result["failed_content"]
                    ]
                )
                or "No Failed Content"
            )

            logging.info(f"result: {result}")

            failed_content_str = (
                "\nFailed Content:\n" + failed_content_str
                if failed_content_str != "No Failed Content"
                else "\nFailed Content: No Failed Content"
            )

            message_parts.append(
                f"Subfolder: {result['subfolder']}\nURL: {result['subfolder_url']}\nTotal Count: {result['total_count']}\nPass Count: {result['pass_count']}\nFail Count: {result['fail_count']}{failed_content_str}"
            )

            if result["fail_count"] > 0:
                overall_status = "Failed"

        message = "\n\n\n".join(message_parts)
        new_filename = f"AMP_{segment}_QA CHECKS_{datetime.datetime.now().strftime('%Y-%m-%d')} - QA Checks - {env} - {overall_status}"
        sns.publish(
            TopicArn=amp_dna_email_notification, Message=message, Subject=new_filename
        )

        return {
            "statusCode": 200,
            "body": "File analysis sent to SNS topic successfully",
        }
    except s3.exceptions.NoSuchKey:
        logging.error("No file found at the specified S3 path.")
        return {"statusCode": 404, "body": "No file found at the specified S3 path."}
    except Exception as e:
        logging.error(f"Error processing event: {e}")
        return {"statusCode": 500, "body": f"Error: {str(e)}"}
