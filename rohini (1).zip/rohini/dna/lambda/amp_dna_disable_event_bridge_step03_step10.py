import json
import logging
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

# Initialize the EventBridge client
events_client = boto3.client("events")


class CustomException(Exception):
    pass


def lambda_handler(event, context):  # NOSONAR
    """
    This Lambda function disables an EventBridge rule.
    That rule which triggers the Step Function 2.
    :param event: disable_rule_name
    :param context: None
    :return: EventBridge rule disabled successfully
    """
    # Extract the rule name from the event
    rule_name = event.get("disable_rule_name")

    if not rule_name:
        raise ValueError("Missing 'rule_name' in event")

    logging.info(f"Attempting to disable EventBridge rule '{rule_name}'")

    try:
        # Disable the EventBridge rule
        response = events_client.describe_rule(Name=rule_name)
        if response["State"] != "DISABLED":
            events_client.disable_rule(Name=rule_name)
            logging.info(f"EventBridge rule '{rule_name}' disabled.")
        else:
            logging.info(f"EventBridge rule '{rule_name}' is already disabled.")

        return {
            "statusCode": 200,
            "body": json.dumps(
                {"message": f"EventBridge rule '{rule_name}' disabled successfully."}
            ),
        }
    except events_client.exceptions.ResourceNotFoundException:
        error_message = f"EventBridge rule '{rule_name}' does not exist."
        logging.error(f"ERROR: {error_message}")
        raise CustomException(error_message)
    except Exception as e:
        logging.error(f"Error disabling EventBridge rule: {e}")
        raise CustomException(e)
