import os

import boto3


def lambda_handler(event, context):  # NOSONAR
    new_crawler = os.getenv("athena_crawler_name")
    try:
        glue = boto3.client("glue")
        response = glue.start_crawler(Name=new_crawler)
        return {"statusCode": 200, "body": response}
    except Exception as e:
        return {"statusCode": 500, "body": f"Error: {e}"}
