import json
import logging
import os
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR


def lambda_handler(event, context):  # NOSONAR
    """
    This Lambda function reads the properties file from the specified S3 path,
    reads the content of the file, and triggers the Step Function 1.
    :param event: event
    :param context: None
    :return: Step Function 1 triggered successfully
    """

    # Initialize AWS clients
    logging.info("Initializing AWS clients")
    sns_client = boto3.client("sns")
    s3_client = boto3.client("s3")
    stepfunctions = boto3.client("stepfunctions")

    # Retrieve environment variables
    logging.info("Retrieving environment variables")
    job_audit_bucket_name = os.getenv("job_audit_bucket_name")
    environment = os.getenv("environment")
    amp_dna_trigger_email = os.getenv("amp_dna_trigger_email")
    amp_dna_processing = os.getenv("amp_dna_processing")
    amp_dna_output = os.getenv("amp_dna_output")
    secret_name = os.getenv("secret_name")
    amp_dna_step00_ems_input_file = os.getenv("amp_dna_step00_ems_input_file")
    amp_dna_step01_format_ems_txt_file = os.getenv("amp_dna_step01_format_ems_txt_file")
    amp_dna_trigger_stepfun_and_self_lambda = os.getenv(
        "amp_dna_trigger_stepfun_and_self_lambda"
    )
    amp_step03_step10_readproperties_lambda_name = os.getenv(
        "amp_step03_step10_readproperties_lambda_name"
    )
    amp_dna_sts_file_transfer = os.getenv("amp_dna_sts_file_transfer")
    amp_dna_glue_exception_handling_lambda_name = os.getenv(
        "amp_dna_glue_exception_handling_lambda_name"
    )
    amp_dna_lambda_exception_handling_lambda_name = os.getenv(
        "amp_dna_lambda_exception_handling_lambda_name"
    )
    file_names = {}
    folder_names = {}
    input_json = {}

    for record in event["Records"]:
        bucket_name = record["s3"]["bucket"]["name"]
        object_key = record["s3"]["object"]["key"]

        try:
            response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
            file_content = response["Body"].read().decode("utf-8")

            lines = file_content.split("\n")
            parameters = {}
            s3_params = [
                "step00monthlyinput",
                "step00dnaextract",
                "step04EVD",
                "step08statecountydma",
                "step09statecountydma",
                "step09ethnicmapping",
                "step091ethnicmapping",
                "step10previousfile",
                "step00lnk_state_lkup_file",
            ]

            folder_year = None
            folder_month = None
            folder_segment = None

            for line in lines:
                if "=" in line:
                    key, value = line.split("=", 1)
                    parameters[key.strip()] = value.strip()
                    # Extract folder year, month, and segment if available
                    if key.strip() == "year":
                        folder_year = value.strip()
                    elif key.strip() == "month":
                        folder_month = value.strip()
                    elif key.strip() == "segment":
                        folder_segment = value.strip()

            if not (folder_year and folder_month and folder_segment):
                raise ValueError(
                    "Missing required folder information (year, month, segment)"
                )

            # Process the s3_params
            logging.info("Processing S3 parameters")
            for param in s3_params:
                if param in parameters:
                    full_path = parameters[param]
                    path_parts = full_path.split("/")
                    folder_name = "/".join(path_parts[:-1])
                    file_name = path_parts[-1]
                    folder_names[param] = folder_name
                    file_names[param] = file_name

            # Folder structure for processing files
            logging.info("Constructing folder structure for processing files")
            folder_structure_for_processing = f"s3://{amp_dna_processing}/segment={folder_segment}/year={folder_year}/month={folder_month}"

            # Folder structure for output files
            logging.info("Constructing folder structure for output files")
            folder_structure_for_output = f"s3://{amp_dna_output}/segment={folder_segment}/year={folder_year}/month={folder_month}"

            # Input and output folder parameters for dna_step00
            logging.info(
                "Constructing input and output folder parameters for dna_step00"
            )
            output_folderforstep1 = f"{folder_structure_for_processing}/Step00"
            ems_output_folderofstep1 = (
                f"{folder_structure_for_processing}/Step00/ds_ems_input_file.csv/"
            )

            # Step01 input file name
            lnk_ems_ds_input_path_step00 = (
                f"{folder_structure_for_processing}/Step00/ds_ems_input_file.parquet/"
            )

            qa_sq_ems_input_file = "QA_sq_EMS_Input"
            ds_ems_input_file = "ds_ems_input_file"
            sq_used_count_file = "sq_used_count"
            vehicle_data_all_data_file = "vehicle_data_all_data"
            ds_fixed_seq_numbers_file = "ds_fixed_seq_numbers_file"

            input_file_path = f"{output_folderforstep1}/{qa_sq_ems_input_file}.txt/"

            input_json = json.dumps(
                {
                    "amp_dna_glue_exception_handling_lambda_name": amp_dna_glue_exception_handling_lambda_name,
                    "amp_dna_lambda_exception_handling_lambda_name": amp_dna_lambda_exception_handling_lambda_name,
                    "job_audit_bucket_name": job_audit_bucket_name,
                    "ds_fixed_seq_numbers_file": ds_fixed_seq_numbers_file,
                    "lnk_ems_ds_input_path_step00": lnk_ems_ds_input_path_step00,
                    "folder_structure_for_processing": folder_structure_for_processing,
                    "folder_structure_for_output": folder_structure_for_output,
                    "folder_names": folder_names,
                    "file_names": file_names,
                    "parameters": parameters,
                    "environment": environment,
                    "input_file_path": input_file_path,
                    "operation_upload": "upload",
                    "amp_dna_step00_ems_input_file": amp_dna_step00_ems_input_file,
                    "amp_dna_step01_format_ems_txt_file": amp_dna_step01_format_ems_txt_file,
                    "amp_dna_sts_file_transfer": amp_dna_sts_file_transfer,
                    "amp_dna_trigger_stepfun_and_self_lambda": amp_dna_trigger_stepfun_and_self_lambda,
                    "output_folderforstep1": output_folderforstep1,
                    "qa_sq_ems_input_file": qa_sq_ems_input_file,
                    "ds_ems_input_file": ds_ems_input_file,
                    "sq_used_count_file": sq_used_count_file,
                    "vehicle_data_all_data_file": vehicle_data_all_data_file,
                    "ems_output_folderofstep1": ems_output_folderofstep1,
                    "amp_step03_step10_readproperties_lambda_name": amp_step03_step10_readproperties_lambda_name,
                    "amp_dna_trigger_email": amp_dna_trigger_email,
                    "secret_name": secret_name,
                }
            )

            sns_topic_arn = amp_dna_trigger_email
            subject = "DNA Step Function Input"
            message_body = "Step function Started..."
            message_json = f"Subject: {subject}\n\n{message_body}\n\n{input_json}"

            # Send message to SNS topic
            try:
                sns_client.publish(
                    TopicArn=sns_topic_arn, Message=message_json, Subject=subject
                )
            except Exception as e:
                print(f"Error publishing to SNS: {e}")

        except Exception as e:
            print(f"Error processing S3 object {bucket_name}/{object_key}: {e}")

    # Trigger the Step Function
    logging.info("Triggering Step Function 1")
    try:
        logging.info(f"Input JSON: {input_json}")
        stepfunctions.start_execution(
            stateMachineArn=os.getenv("statemachinearn_step00"), input=input_json
        )
    except Exception as e:
        logging.error(f"Error triggering Step Function: {e}")

    return {"statusCode": 200, "body": json.dumps("Lambda executed successfully!")}
