import json
import logging
import os
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR


def lambda_handler(event, context):  # NOSONAR
    sns_client = boto3.client("sns")
    s3_client = boto3.client("s3")
    logging.info(f"event: {event}")

    amp_dna_email_notification = os.getenv("amp_dna_trigger_email")

    def is_json(myjson):
        try:
            json.loads(myjson)
        except json.JSONDecodeError:
            return False
        return True

    try:
        event_data = event["errordetails"]["Cause"]
    except KeyError as e:
        logging.error(f"KEYERROR: {e}")
        event_data = event["errordetails"]["cause"]

    try:
        if is_json(event_data):
            logging.info("logging event_data is json")
            event_data = json.loads(event_data)
        else:
            logging.info("event_data is a string")
            event_data = {"cause": event_data}

        logging.info(f"event_data_error: {event_data}")

        glue_job_name = event_data.get("JobName")
        glue_job_state = event_data.get("JobRunState")
        glue_job_error = event_data.get("ErrorMessage")

        if glue_job_name is None:
            logging.info(f"glue_job_name: {glue_job_name}")
            glue_job_name = "One of the Glue Job is Failed"
        if glue_job_state is None:
            logging.info(f"glue_job_state: {glue_job_state}")
            glue_job_state = "Failed"
        if glue_job_error is None:
            logging.info(f"glue_job_error: {glue_job_error}")
            glue_job_error = event_data["cause"]

        jobdetails = {
            "glue_job_name": glue_job_name,
            "glue_job_state": glue_job_state,
            "glue_job_error": glue_job_error,
        }

        # Extract input parameters
        client_name = event["parameters"]["segment"]
        year = event["parameters"]["year"]
        month = event["parameters"]["month"]
        job_audit_bucket_name = event["job_audit_bucket_name"]

        # Prepare SNS message
        sns_topic_arn = amp_dna_email_notification
        subject = f"Glue Job failed for {client_name}_year={year}_month={month}"
        message_body = f"AMP_Segment= {client_name}\n  glue_job_details: {jobdetails}"

        # Construct message_json
        logging.info("Constructing message_json")
        message_json = json.dumps({"subject": subject, "message_body": message_body})

        # Send message to SNS topic
        logging.info("Sending message to SNS topic")
        sns_client.publish(TopicArn=sns_topic_arn, Message=message_json)

        # Create header and data row for CSV
        header = [
            "segment",
            "year",
            "month",
            "stepfunction state name",
            "status Description",
        ]
        data = [client_name, year, month, glue_job_name, glue_job_error]

        # Create properties file content
        properties_content = f"""
        segment={client_name}
        year={year}
        month={month}
        stepfunction_state_name={glue_job_name}
        status_description={glue_job_error}
        """

        # Save properties content to S3
        logging.info("Saving properties content to S3")
        properties_key = (
            f"segment={client_name}/{client_name}_year_{year}_month_{month}.jobaudit"
        )

        # Delete existing file if it exists
        try:
            s3_client.delete_object(Bucket=job_audit_bucket_name, Key=properties_key)
        except s3_client.exceptions.NoSuchKey:
            logging.info(
                f"No existing file to delete: s3://{job_audit_bucket_name}/{properties_key}"
            )
        except Exception as e:
            logging.error(f"Error deleting existing file: {e}")

        try:
            s3_client.put_object(
                Bucket=job_audit_bucket_name,
                Key=properties_key,
                Body=properties_content,
            )
            logging.info(
                f"Properties file saved to s3://{job_audit_bucket_name}/{properties_key}"
            )
        except Exception as e:
            logging.error(f"Error saving properties file to S3: {e}")

        return {
            "statusCode": 200,
            "body": "Message sent to SNS topic and properties file updated successfully",
        }

    except Exception as e:
        logging.error(f"Error processing event: {e}")
        return {"statusCode": 500, "body": f"Error processing event: {e}"}
