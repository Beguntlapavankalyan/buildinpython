import json
import logging
import sys

import boto3

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR


def lambda_handler(event, context):  # NOSONAR
    """
    This Lambda function sends an email notification to the specified
    SNS topic and updates a properties file in the specified S3 bucket.
    :param event: sns_topic_arn, bucket_name, segment, year, month
    :param context: None
    :return: Message sent to SNS topic and properties file updated successfully
    """
    sns_client = boto3.client("sns")
    s3_client = boto3.client("s3")
    amp_dna_email_notification = event["amp_dna_email_notification"]

    # Extract bucket name
    job_audit_bucket_name = event["job_audit_bucket_name"]
    try:
        # Extract input parameters
        client_name = event["parameters"]["segment"]
        year = event["parameters"]["year"]
        month = event["parameters"]["month"]

        glue_job_name = "All states completed"
        glue_job_error = "Successfully completed all jobs"

        jobdetails = {
            "glue_job_state": glue_job_name,
            "glue_job_error": glue_job_error,
        }
        logging.info(f"Job details: {jobdetails}")

        # Prepare SNS message
        subject = f"ALL Glue Job succeeded for {client_name}_year={year}_month={month}"
        message_body = (
            f"portal_jobdetails: {client_name}\n  glue_job_details: {jobdetails}"
        )

        # Construct message_json
        message_json = json.dumps({"subject": subject, "message_body": message_body})

        # Send message to SNS topic
        logging.info(f"Sending message to SNS topic: {amp_dna_email_notification}")
        sns_client.publish(TopicArn=amp_dna_email_notification, Message=message_json)

        # Create header and data row for CSV
        header = [
            "segment",
            "year",
            "month",
            "stepfunction state name",
            "status Description",
        ]
        data = [client_name, year, month, glue_job_name, glue_job_error]

        # Create properties file content
        properties_content = f"""
        segment={client_name}
        year={year}
        month={month}
        stepfunction_state_name={glue_job_name}
        status_description={glue_job_error}
        """

        # Save properties content to S3
        logging.info(
            f"Saving properties content to S3: s3://{job_audit_bucket_name}/jobaudit/{client_name}_year_{year}_month_{month}.properties"
        )
        properties_key = (
            f"segment={client_name}/{client_name}_year_{year}_month_{month}.properties"
        )

        # Delete existing file if it exists
        try:
            s3_client.delete_object(Bucket=job_audit_bucket_name, Key=properties_key)
        except s3_client.exceptions.NoSuchKey:
            logging.error(
                f"No existing file to delete: s3://{job_audit_bucket_name}/{properties_key}"
            )
        except Exception as e:
            logging.error(f"Error deleting existing file: {e}")

        try:
            s3_client.put_object(
                Bucket=job_audit_bucket_name,
                Key=properties_key,
                Body=properties_content,
            )
        except Exception as e:
            logging.error(f"Error saving properties file to S3: {e}")

        return {
            "statusCode": 200,
            "body": "Message sent to SNS topic and properties file updated successfully",
        }

    except Exception as e:
        logging.error(f"Error processing event: {e}")
        return {"statusCode": 500, "body": f"Error processing event: {e}"}
