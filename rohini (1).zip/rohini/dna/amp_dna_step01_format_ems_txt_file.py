import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_parquet_using_full_path,
                                            write_txt)
from pyspark.sql.functions import col, concat_ws, length, lit, rpad, when

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

args = getResolvedOptions(
    sys.argv,
    [
        "lnk_ems_ds_input_path_step00",
        "qa_sq_ems_input_file",
        "output_folder",
    ],
)

lnk_ems_ds_input_path_step00 = args["lnk_ems_ds_input_path_step00"]
qa_sq_ems_input_file = args["qa_sq_ems_input_file"]
output_folder = args["output_folder"]

logging.info("Reading second input csv file for ems_input")
lnk_ems_ds = read_parquet_using_full_path(
    glue_context=glue_context,
    spark=spark,
    full_path=lnk_ems_ds_input_path_step00,
    force_spark_read=True,
)

lnk_ems_in_to_qa = lnk_ems_ds.select(
    col("SEQ_NO"),
    lit(" " * 4).alias("filler1"),
    when(col("max_first_nm").isNull(), "")
    .otherwise(col("max_first_nm"))
    .alias("first_nm"),
    when(col("zip_4").isNull(), "").otherwise(col("zip_4")).alias("zip_4"),
    lit(" " * 5).alias("filler1_1"),
    when(col("max_middle_nm").isNull(), "")
    .otherwise(col("max_middle_nm"))
    .alias("middle_nm"),
    lit(" " * 5).alias("filler1_2"),
    when(col("max_last_nm").isNull(), "")
    .otherwise(col("max_last_nm"))
    .alias("last_nm"),
    lit(" " * 5).alias("filler1_3"),
    when(col("max_address_tx").isNull(), "")
    .otherwise(col("max_address_tx"))
    .alias("address_tx"),
    lit(" " * 4).alias("filler1_4"),
    when(col("max_city_nm").isNull(), "")
    .otherwise(col("max_city_nm"))
    .alias("city_nm"),
    lit(" " * 5).alias("filler1_5"),
    when(col("max_state_abbr").isNull(), "")
    .otherwise(col("max_state_abbr"))
    .alias("state_abbr"),
    lit(" " * 3).alias("filler1_6"),
    when(col("max_zip_cd").isNull(), "").otherwise(col("max_zip_cd")).alias("zip_cd"),
    lit(" " * 5).alias("file1_7"),
)

logging.info("Applying fixed lengths to write the final text file")
fixed_lengths = {
    "SEQ_NO": 20,
    "filler1": 4,
    "first_nm": 20,
    "filler1_1": 5,
    "middle_nm": 20,
    "filler1_2": 5,
    "last_nm": 35,
    "filler1_3": 5,
    "address_tx": 76,
    "filler1_4": 4,
    "city_nm": 20,
    "filler1_5": 5,
    "state_abbr": 2,
    "filler1_6": 3,
    "zip_cd": 5,
    "file1_7": 5,
    "zip_4": 4,
}

for col_name, length in fixed_lengths.items():
    lnk_ems_in_to_qa = lnk_ems_in_to_qa.withColumn(
        col_name, rpad(lnk_ems_in_to_qa[col_name].cast("string"), length, " ")
    )

lnk_ems_in_to_qa_2 = lnk_ems_in_to_qa.withColumn(
    "concatenated_data",
    concat_ws(
        "",
        "SEQ_NO",
        "filler1",
        "first_nm",
        "filler1_1",
        "middle_nm",
        "filler1_2",
        "last_nm",
        "filler1_3",
        "address_tx",
        "filler1_4",
        "city_nm",
        "filler1_5",
        "state_abbr",
        "filler1_6",
        "zip_cd",
        "file1_7",
        "zip_4",
    ),
)

lnk_ems_in_to_qa_2 = lnk_ems_in_to_qa_2.select("concatenated_data")

logging.info("Writing the lnk_ems_in_to_qa_2 file")
lnk_ems_in_to_qa_2 = lnk_ems_in_to_qa_2.coalesce(1)
write_txt(
    df=lnk_ems_in_to_qa_2,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=qa_sq_ems_input_file,
    delimiter="",
    txt_extension=".txt",
    force_ignore_txt=False,
    force_txt=False,
    header=False,
)
