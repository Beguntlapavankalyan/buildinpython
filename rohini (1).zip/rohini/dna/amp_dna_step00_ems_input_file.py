import logging
import sys

from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotiveetldev.utils import (initialize_context,
                                            read_csvs_by_prefix_with_header,
                                            write_parquet_or_csv)
from pyspark.sql import functions as F
from pyspark.sql.functions import (col, concat, count, date_format, isnull,
                                   length, lit, rpad, substring, to_date, trim,
                                   when)

load_dotenv()
glue_context, spark = initialize_context()
glueContext = glue_context

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

args = getResolvedOptions(
    sys.argv,
    [
        "sq_monthly_input_path",
        "sq_dna_extract_path",
        "output_folder",
        "sq_used_count_file",
        "ds_ems_input_file",
        "vehicle_data_all_data_file",
        "state_lkup_file_path",
        "automarket_monthly_input",
        "dna_ov_extract",
        "state_51",
        "ds_fixed_seq_numbers_file",
    ],
)

sq_monthly_input_path = args["sq_monthly_input_path"]
sq_dna_extract_path = args["sq_dna_extract_path"]
output_folder = args["output_folder"]
sq_used_count_file = args["sq_used_count_file"]
ds_ems_input_file = args["ds_ems_input_file"]
vehicle_data_all_data_file = args["vehicle_data_all_data_file"]
state_lkup_file_path = args["state_lkup_file_path"]
automarket_monthly_input = args["automarket_monthly_input"]
dna_ov_extract = args["dna_ov_extract"]
state_51 = args["state_51"]
ds_fixed_seq_numbers_file = args["ds_fixed_seq_numbers_file"]

logging.info("Reading sq_monthly_input_path file")
lnk_am_dna = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=sq_monthly_input_path,
    local_folder="",
    csvs_prefix=automarket_monthly_input,
    header=False,
    delimiter="|",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

logging.info("Reading sq_dna_extract_path file")
lnk_felix_tr = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=sq_dna_extract_path,
    local_folder="",
    csvs_prefix=dna_ov_extract,
    header=False,
    delimiter="|",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

logging.info("Reading state_lkup_file_path file")
lnk_state_lkup = read_csvs_by_prefix_with_header(
    glue_context=glue_context,
    spark=spark,
    s3_bucket_and_folder=state_lkup_file_path,
    local_folder="",
    csvs_prefix=state_51,
    header=True,
    delimiter=",",
    infer_schema=False,
    schema=None,
    force_spark_read=True,
)

# Add the new columns with null values
lnk_am_dn_columns = [
    "record_id",
    "vehicle_int_id",
    "qa_dmv_resident_int_Id",
    "qa_dmv_resident_ty",
    "purchase_date",
    "qa_dmv_addr_int_id",
    "pur_state_abbr",
    "max_first_nm",
    "max_middle_nm",
    "max_last_nm",
    "max_address_tx",
    "max_city_nm",
    "max_state_abbr",
    "max_zip_cd",
    "vin",
    "vin_pattern",
    "current_owner_in",
    "report_period_dt",
    "rmin_resident_int_id",
    "rmin_resident_ty",
    "rpt_bnbu_in",
    "report_period_yr",
    "report_period_mm",
]

logging.info("Processing lnk_am_dna file")
lnk_am_dna = lnk_am_dna.toDF(*lnk_am_dn_columns)
lnk_am_dna = lnk_am_dna.withColumn("svSeqNum", col("record_id").cast("bigint"))

logging.info("Filtering lnk_am_dna file")
lnk_non_ca_rec_filtered = lnk_am_dna.filter(
    (col("pur_state_abbr") != "CA")
    | (col("rpt_bnbu_in") == "X")
    | (col("rpt_bnbu_in") == "W")
    | (col("rpt_bnbu_in") == "S")
)

logging.info(
    "selecting columns from lnk_non_ca_rec_filtered and storing in lnk_non_ca_rec"
)
lnk_non_ca_rec = lnk_non_ca_rec_filtered.select(
    trim(col("vin")).alias("vin"),
    col("svseqnum").cast("bigint").alias("svSeqNum"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
)

# Applynig filter condition
lnk_rdr_records_filtered = lnk_am_dna.filter(
    (col("pur_state_abbr") == "CA")
    & (col("max_last_nm") != "STATE RESTRICTED")
    & (col("rpt_bnbu_in") != "X")
    & (col("rpt_bnbu_in") != "W")
    & (col("rpt_bnbu_in") != "S")
)

logging.info(
    "selecting columns from lnk_rdr_records_filtered and storing in lnk_rdr_records"
)
lnk_rdr_records = lnk_rdr_records_filtered.select(
    col("record_id").alias("record_id_rdr"),
    col("max_first_nm").alias("max_first_nm_rdr"),
    col("max_middle_nm").alias("max_middle_nm_rdr"),
    col("max_last_nm").alias("max_last_nm_rdr"),
    col("vin"),
)

# Applynig filter condition
lnk_ca_nonrdr_filtered = lnk_am_dna.filter(
    (col("pur_state_abbr") == "CA")
    & (col("max_last_nm") == "STATE RESTRICTED")
    & (col("rpt_bnbu_in") == "N")
    & (col("rpt_bnbu_in") != "W")
    & (col("rpt_bnbu_in") != "S")
)

logging.info(
    "selecting columns from lnk_ca_nonrdr_filtered and storing in lnk_ca_nonrdr"
)
lnk_ca_nonrdr = lnk_ca_nonrdr_filtered.select(
    col("svSeqNum").cast("bigint").alias("svSeqNum"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
)

for column in lnk_ca_nonrdr.columns:
    if column == "svSeqNum":
        lnk_ca_nonrdr = lnk_ca_nonrdr.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_ca_nonrdr = lnk_ca_nonrdr.withColumn(column, col(column).cast("string"))

logging.info("Applying left outer join")
jn_vins = lnk_ca_nonrdr.alias("nonrdr").join(
    lnk_rdr_records.alias("rdr"), col("nonrdr.vin") == col("rdr.vin"), "leftouter"
)

lnk_ca_combined = jn_vins.select(
    col("rdr.record_id_rdr"),
    col("rdr.max_first_nm_rdr"),
    col("rdr.max_middle_nm_rdr"),
    col("rdr.max_last_nm_rdr"),
    col("nonrdr.record_id"),
    col("nonrdr.vin"),
    col("nonrdr.vehicle_int_id"),
    col("nonrdr.qa_dmv_resident_int_Id"),
    col("nonrdr.qa_dmv_resident_ty"),
    col("nonrdr.purchase_date"),
    col("nonrdr.qa_dmv_addr_int_id"),
    col("nonrdr.pur_state_abbr"),
    col("nonrdr.max_first_nm"),
    col("nonrdr.max_middle_nm"),
    col("nonrdr.max_last_nm"),
    col("nonrdr.max_address_tx"),
    col("nonrdr.max_city_nm"),
    col("nonrdr.max_state_abbr"),
    col("nonrdr.max_zip_cd"),
    col("nonrdr.vin_pattern"),
    col("nonrdr.current_owner_in"),
    col("nonrdr.report_period_dt"),
    col("nonrdr.rmin_resident_int_id"),
    col("nonrdr.rmin_resident_ty"),
    col("nonrdr.rpt_bnbu_in"),
    col("nonrdr.report_period_yr"),
    col("nonrdr.report_period_mm"),
    col("nonrdr.svSeqNum").cast("bigint").alias("svSeqNum"),
)

for column in lnk_ca_combined.columns:
    if column == "svSeqNum":
        lnk_ca_combined = lnk_ca_combined.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_ca_combined = lnk_ca_combined.withColumn(column, col(column).cast("string"))

# Applying filter condition
lnk_combine_filtered = lnk_ca_combined.filter(trim(col("max_last_nm_rdr")) != "")

# Select the required columns
lnk_combine = lnk_combine_filtered.select(
    col("max_last_nm").alias("max_last_nm_before"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_first_nm_rdr"))
    .otherwise(col("max_first_nm"))
    .alias("max_first_nm"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_middle_nm_rdr"))
    .otherwise(col("max_middle_nm"))
    .alias("max_middle_nm"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_last_nm_rdr"))
    .otherwise(col("max_last_nm"))
    .alias("max_last_nm_fixed"),
    col("record_id_rdr").alias("svSeqNum"),
    col("record_id"),
    col("record_id_rdr"),
    col("max_first_nm_rdr"),
    col("max_middle_nm_rdr"),
    col("max_last_nm_rdr"),
)

for column in lnk_combine.columns:
    if column == "svSeqNum":
        lnk_combine = lnk_combine.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_combine = lnk_combine.withColumn(column, col(column).cast("string"))

lnk_fixed_records = lnk_ca_combined.select(
    col("vin"),
    col("svSeqNum").cast("bigint").alias("svSeqNum"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_first_nm_rdr"))
    .otherwise(col("max_first_nm"))
    .alias("max_first_nm"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_middle_nm_rdr"))
    .otherwise(col("max_middle_nm"))
    .alias("max_middle_nm"),
    when(trim(col("max_last_nm_rdr")) != "", col("max_last_nm_rdr"))
    .otherwise(col("max_last_nm"))
    .alias("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
)

for column in lnk_fixed_records.columns:
    if column == "svSeqNum":
        lnk_fixed_records = lnk_fixed_records.withColumn(
            column, col(column).cast("bigint")
        )
    else:
        lnk_fixed_records = lnk_fixed_records.withColumn(
            column, col(column).cast("string")
        )

logging.info("Doing UNION lnk_non_ca_rec and lnk_fixed_records")
lnk_am_input1 = lnk_non_ca_rec.union(lnk_fixed_records)

for column in lnk_am_input1.columns:
    if column == "svSeqNum":
        lnk_am_input1 = lnk_am_input1.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_am_input1 = lnk_am_input1.withColumn(column, col(column).cast("string"))

# Filter condition
lnk_am_input_filtered = lnk_am_input1.filter(
    (col("rpt_bnbu_in") != "W") & (col("rpt_bnbu_in") != "S")
)

logging.info("selecting columns from lnk_am_input_filtered and storing in lnk_am_input")
lnk_am_input = lnk_am_input_filtered.select(
    col("vin"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
    col("svSeqNum").cast("bigint").alias("svSeqNum"),
)

for column in lnk_am_input.columns:
    if column == "svSeqNum":
        lnk_am_input = lnk_am_input.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_am_input = lnk_am_input.withColumn(column, col(column).cast("string"))

# Applying filter condition
lnk_MC_filtered = lnk_am_input1.filter(
    (col("rpt_bnbu_in") == "W") | (col("rpt_bnbu_in") == "S")
)

logging.info("selecting columns from lnk_MC_filtered and storing in lnk_MC")
lnk_MC = lnk_MC_filtered.select(
    col("svSeqNum"),
    col("vin"),
    col("record_id").cast("string").alias("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
    concat(
        col("report_period_yr"),
        lit(":"),
        col("report_period_mm"),
        lit(":"),
        rpad(lit(""), 7, "0"),
        lit(":"),
        rpad(trim(col("record_id")), 7, " "),
    ).alias("SEQ_NO"),
    trim(col("max_first_nm")).substr(1, 20).alias("first_nm"),
    trim(col("max_middle_nm")).substr(1, 20).alias("middle_nm"),
    trim(col("max_last_nm")).substr(1, 35).alias("last_nm"),
    trim(col("max_address_tx")).alias("address_tx"),
    when(
        (trim(col("max_city_nm")) == "") | (trim(col("max_city_nm")) == "-"),
        lit(" " * 20),
    )
    .otherwise(trim(col("max_city_nm")).substr(1, 20))
    .alias("city_nm"),
    when(
        (trim(col("max_state_abbr")) == "") | (trim(col("max_state_abbr")) == "-"),
        lit(" " * 2),
    )
    .otherwise(trim(col("max_state_abbr")))
    .alias("st"),
    when(
        (trim(col("max_zip_cd")) == "") | (trim(col("max_zip_cd")) == "-"), lit(" " * 5)
    )
    .otherwise(trim(col("max_zip_cd")))
    .alias("zip_cd"),
    lit(" " * 4).alias("zip_4"),
)

for column in lnk_MC.columns:
    if column == "svSeqNum":
        lnk_MC = lnk_MC.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_MC = lnk_MC.withColumn(column, col(column).cast("string"))

logging.info("Combine lnk_combine file")
lnk_ca_records = lnk_combine.select("record_id", "record_id_rdr")

for column in lnk_ca_records.columns:
    lnk_ca_records = lnk_ca_records.withColumn(column, col(column).cast("string"))

lnk_ca_data_fix = lnk_combine.select("record_id", "svSeqNum")

for column in lnk_ca_data_fix.columns:
    if column == "svSeqNum":
        lnk_ca_data_fix = lnk_ca_data_fix.withColumn(column, col(column).cast("bigint"))
    else:
        lnk_ca_data_fix = lnk_ca_data_fix.withColumn(column, col(column).cast("string"))

# selecting columns from second input file
lnk_felix_tr_column_names = [
    "SEQUENCE_NUMBER",
    "VIN",
    "VIN_PATTERN",
    "VEHICLE_INT_ID",
    "ACTIVITY_DATE",
    "MAX_ACTIVITY_DT",
    "DISPOSAL_DATE",
    "PURCHASED_VEHICLE",
    "VIO_IN",
    "BNBU",
    "SOURCE_TY",
    "FIRST_NAME",
    "MIDDLE_NAME",
    "LAST_NAME",
    "MAIN_RANGE",
    "PRE_DIRECTIONAL",
    "STREET_NAME",
    "SUFFIX",
    "POST_DIRECTIONAL",
    "RR_NUMBER",
    "RR_BOX",
    "POB",
    "SCND_DESIGNATION",
    "SCND_RANGE",
    "CITY_NAME",
    "STATE_ABBR",
    "ZIP",
    "ZIP4",
    "WMI",
    "COUNTRY_CD",
    "NEW_EVD_MFR",
    "MODEL_YR",
    "MAKE_CD",
    "MAKE_TX",
    "MODEL_CD",
    "MODEL_TX",
    "MODEL_CLS_CD",
    "MODEL_CLASS_TX",
    "BODY_TX",
    "MIN_DOOR_CT",
    "MAX_DOOR_CT",
    "TRANS_CD",
    "TRANS_TY",
    "DRIVEWHEEL_TY",
    "WHEEL_BASE",
    "VEH_LENGTH",
    "TIRE_SIZE",
    "VEH_WT",
    "CYLINDER",
    "CAM_CONFIG",
    "TAX_HP",
    "FUEL_DELIVERY_TY",
    "FUEL_TY",
    "DISPLACEMENT",
    "MAKE_SALES_DESIGNATION",
    "TRIM_TX",
    "GEAR_CT",
    "MSRP",
    "DLR_NAME",
    "DLR_NUMBER",
    "DLR_TYPE",
    "LHDR_NAME",
    "PURCH_TYPE",
    "LENDER_TYPE",
    "AC_PURCHASE_DATE",
]

# Assign the column names to the DataFrame
lnk_felix_tr = lnk_felix_tr.toDF(*lnk_felix_tr_column_names)
lnk_felix_tr = (
    lnk_felix_tr.withColumn(
        "svSeqNum",
        col("SEQUENCE_NUMBER").cast("bigint"),
    )
    .withColumn("svActivityDate", to_date(trim(col("ACTIVITY_DATE")), "yyyy-MM-dd"))
    .withColumn(
        "svDisposalDate",
        when(
            col("DISPOSAL_DATE").isNull() | (length(trim(col("DISPOSAL_DATE"))) > 9),
            to_date(lit("1900-01-01"), "yyyy-MM-dd"),
        ).otherwise(to_date(col("DISPOSAL_DATE"), "yyyy-MM-dd")),
    )
)

logging.info("creating lnk_activity_date and selecting columns from lnk_felix_tr")
lnk_activity_date = lnk_felix_tr.select(
    col("svSeqNum").cast("bigint").alias("svSeqNum"),
    when(
        (length(col("ACTIVITY_DATE")) == 10)
        & (substring(col("ACTIVITY_DATE"), 5, 1) == "-")
        & (substring(col("ACTIVITY_DATE"), 8, 1) == "-"),
        to_date(col("ACTIVITY_DATE"), "yyyy-MM-dd"),
    )
    .otherwise(to_date(lit("1900-01-01"), "yyyy-MM-dd"))
    .cast("date")
    .alias("iActivityDate"),
)

logging.info("creating lnk_vin and selecting columns from lnk_felix_tr")
lnk_vin = lnk_felix_tr.select(
    col("svSeqNum").cast("bigint").alias("svSeqNum"), trim(col("VIN")).alias("vin")
)

logging.info("creating lnk_ds_output and selecting columns from lnk_felix_tr")
lnk_ds_output = lnk_felix_tr.select(
    trim(col("VIN")).alias("VIN"),
    col("VIO_IN").alias("CURRENT_VEHICLE_FLAG"),
    col("MAIN_RANGE").alias("RANGE"),
    col("NEW_EVD_MFR").alias("MANUFACTURER"),
    col("MODEL_YR").alias("MDYR"),
    col("MAKE_TX").alias("MAKE_TEXT"),
    col("MODEL_TX").alias("MODEL_TEXT"),
    col("MODEL_CLASS_TX").alias("MODEL_CLASS_TEXT"),
    col("BODY_TX").alias("STYLE"),
    col("MAKE_SALES_DESIGNATION").alias("IMPORT"),
    col("TRIM_TX").alias("TRIM_TEXT"),
    col("DLR_NAME").alias("DLR_Name"),
    col("DLR_NUMBER").alias("DLR_Number"),
    col("DLR_TYPE").alias("DLR_Type"),
    col("LHDR_NAME").alias("LHDR_Name"),
    col("LENDER_TYPE").alias("Lender_Type"),
    col("AC_PURCHASE_DATE").alias("Autocount_purch_date"),
    col("svActivityDate").cast("date").alias("svActivityDate"),
    col("svSeqNum").cast("bigint").alias("svSeqNum"),
    col("svDisposalDate").cast("date").alias("svDisposalDate"),
    col("SEQUENCE_NUMBER"),
    col("VIN_PATTERN"),
    col("VEHICLE_INT_ID"),
    col("ACTIVITY_DATE"),
    col("MAX_ACTIVITY_DT"),
    col("DISPOSAL_DATE"),
    col("PURCHASED_VEHICLE"),
    col("SOURCE_TY"),
    col("BNBU"),
    col("FIRST_NAME"),
    col("MIDDLE_NAME"),
    col("LAST_NAME"),
    col("PRE_DIRECTIONAL"),
    col("STREET_NAME"),
    col("SUFFIX"),
    col("POST_DIRECTIONAL"),
    col("RR_NUMBER"),
    col("RR_BOX"),
    col("POB"),
    col("SCND_DESIGNATION"),
    col("SCND_RANGE"),
    col("CITY_NAME"),
    col("STATE_ABBR"),
    col("ZIP"),
    col("ZIP4"),
    col("WMI"),
    col("COUNTRY_CD"),
    col("MODEL_YR"),
    col("MAKE_CD"),
    col("MODEL_CD"),
    col("MODEL_CLS_CD"),
    col("MIN_DOOR_CT"),
    col("MAX_DOOR_CT"),
    col("TRANS_CD"),
    col("TRANS_TY"),
    col("DRIVEWHEEL_TY"),
    col("WHEEL_BASE"),
    col("VEH_LENGTH"),
    col("TIRE_SIZE"),
    col("VEH_WT"),
    col("CYLINDER"),
    col("CAM_CONFIG"),
    col("TAX_HP"),
    col("FUEL_DELIVERY_TY"),
    col("FUEL_TY"),
    col("DISPLACEMENT"),
    col("GEAR_CT"),
    col("MSRP"),
    col("PURCH_TYPE"),
)

# Doing Aggregation
lnk_max_date = lnk_activity_date.groupBy("svSeqNum").agg(
    F.max("iActivityDate").cast("date").alias("maxActivityDate")
)

# Performing inner join
jn_vin_date = lnk_vin.join(
    lnk_max_date, lnk_vin["svSeqNum"] == lnk_max_date["svSeqNum"], "inner"
)

lnk_vin_date = jn_vin_date.select(
    lnk_vin["svSeqNum"], lnk_vin["vin"], lnk_max_date["maxActivityDate"]
)

# Performing the innerjoin
jn_seq_num = lnk_vin_date.join(
    lnk_ca_data_fix,
    lnk_vin_date["svSeqNum"] == lnk_ca_data_fix["svSeqNum"],
    "leftouter",
)

# Selecting columns based on dataframe
lnk_Vehs = jn_seq_num.select(
    lnk_ca_data_fix["record_id"],
    lnk_vin_date["svSeqNum"],
    lnk_vin_date["vin"],
    lnk_vin_date["maxActivityDate"],
)

lnk_fixed_seq = lnk_Vehs.select(
    col("vin").cast("string").alias("vin"),
    col("maxActivityDate").cast("date").alias("maxActivityDate"),
    when((trim(col("record_id")) == "") | isnull(col("record_id")), col("svSeqNum"))
    .otherwise(col("record_id"))
    .cast("bigint")
    .alias("svSeqNum"),
)

# Drop Duplicates
lnk_dedupe = lnk_fixed_seq.dropDuplicates(["vin", "svSeqNum"])

logging.info("Joining lnk_am_input and lnk_dedupe")
jn_vin_act_date = lnk_am_input.join(
    lnk_dedupe,
    (lnk_am_input["svSeqNum"] == lnk_dedupe["svSeqNum"])
    & (lnk_am_input["vin"] == lnk_dedupe["vin"]),
    "inner",
)
lnk_join = jn_vin_act_date.select(lnk_am_input["*"], lnk_dedupe["maxActivityDate"])

# Add the new columns
lnk_join = (
    lnk_join.withColumn(
        "svPurchaseDate",
        when(
            (col("rpt_bnbu_in") == "X")
            & (trim(col("purchase_date")) != "")
            & (isnull(col("purchase_date")) == False),
            to_date(
                date_format(to_date(col("purchase_date"), "yyyyMMdd"), "yyyy-MM-dd"),
                "yyyy-MM-dd",
            ),
        ).otherwise(to_date(lit("1900-01-01"), "yyyy-MM-dd")),
    )
    .withColumn("svActivityDate", col("maxActivityDate"))
    .withColumn(
        "svDateIsWithinRange",
        when(
            (col("rpt_bnbu_in") == "X")
            & (col("svPurchaseDate") != to_date(lit("1900-01-01"), "yyyy-MM-dd"))
            & (col("svActivityDate") != to_date(lit("1900-01-01"), "yyyy-MM-dd")),
            when(col("svPurchaseDate") >= col("svActivityDate"), 1).otherwise(0),
        ).otherwise(0),
    )
)

# Applying filter condition
lnk_non_purchase_filtered = lnk_join.filter(
    (col("rpt_bnbu_in") == "X") & (col("svDateIsWithinRange") == True)
)

lnk_non_purchase = lnk_non_purchase_filtered.select(
    "svSeqNum",
    "vin",
    "record_id",
    "vehicle_int_id",
    "qa_dmv_resident_int_Id",
    "qa_dmv_resident_ty",
    "purchase_date",
    "qa_dmv_addr_int_id",
    "pur_state_abbr",
    "max_first_nm",
    "max_middle_nm",
    "max_last_nm",
    "max_address_tx",
    "max_city_nm",
    "max_state_abbr",
    "max_zip_cd",
    "vin_pattern",
    "current_owner_in",
    "report_period_dt",
    "rmin_resident_int_id",
    "rmin_resident_ty",
    "rpt_bnbu_in",
    "report_period_yr",
    "report_period_mm",
)

# Applying filter condition
lnk_purchase_filtered = lnk_join.filter(col("rpt_bnbu_in") != "X")
lnk_purchase = lnk_purchase_filtered.select(
    "svSeqNum",
    "vin",
    "record_id",
    "vehicle_int_id",
    "qa_dmv_resident_int_Id",
    "qa_dmv_resident_ty",
    "purchase_date",
    "qa_dmv_addr_int_id",
    "pur_state_abbr",
    "max_first_nm",
    "max_middle_nm",
    "max_last_nm",
    "max_address_tx",
    "max_city_nm",
    "max_state_abbr",
    "max_zip_cd",
    "vin_pattern",
    "current_owner_in",
    "report_period_dt",
    "rmin_resident_int_id",
    "rmin_resident_ty",
    "rpt_bnbu_in",
    "report_period_yr",
    "report_period_mm",
)

logging.info("Union lnk_purchase and lnk_non_purchase")
lnk_data = lnk_non_purchase.union(lnk_purchase)
lnk_state_lkup = lnk_state_lkup.withColumnRenamed("State Abbr", "max_state_abbr")

# inner join
jn_State_lkp = lnk_data.join(
    lnk_state_lkup,
    lnk_data["max_state_abbr"] == lnk_state_lkup["max_state_abbr"],
    "inner",
)
lnk_veh_data = jn_State_lkp.select(lnk_data["*"])

logging.info("Performing fillna")
lnk_veh_data = lnk_veh_data.fillna(
    "",
    subset=[
        "rpt_bnbu_in",
        "max_zip_cd",
        "max_address_tx",
        "max_last_nm",
        "max_city_nm",
    ],
)

# Applying filter condition
lnk_new_purch_filtered = lnk_veh_data.filter(
    ((col("rpt_bnbu_in") == "N") | (col("rpt_bnbu_in") == "U"))
    & (col("max_zip_cd") != "00000")
    & (trim(col("max_zip_cd")) != "-")
    & (trim(col("max_zip_cd")) != "")
    & (col("max_zip_cd") != "99999")
    & (trim(col("max_address_tx")) != "")
    & (trim(col("max_address_tx")) != "UNKNOWN")
    & (col("max_last_nm") != "UNKNOWN")
    & (col("max_city_nm") != "UNKNOWN")
    & (trim(col("max_city_nm")) != "")
)

lnk_new_purch = lnk_new_purch_filtered.select(
    col("svSeqNum"),
    col("vin"),
    col("record_id").cast("string").alias("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    trim(col("max_last_nm")).alias("max_last_nm"),
    trim(col("max_address_tx")).alias("max_address_tx"),
    trim(col("max_city_nm")).alias("max_city_nm"),
    trim(col("max_state_abbr")).alias("max_state_abbr"),
    trim(col("max_zip_cd")).alias("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
    concat(
        col("report_period_yr"),
        lit(":"),
        col("report_period_mm"),
        lit(":"),
        rpad(lit(""), 7, "0"),
        lit(":"),
        rpad(trim(col("record_id")), 7, " "),
    ).alias("SEQ_NO"),
    trim(col("max_first_nm")).substr(1, 20).alias("first_nm"),
    trim(col("max_middle_nm")).substr(1, 20).alias("middle_nm"),
    trim(col("max_last_nm")).substr(1, 35).alias("last_nm"),
    trim(col("max_address_tx")).alias("address_tx"),
    when(
        (trim(col("max_city_nm")) == "") | (trim(col("max_city_nm")) == "-"),
        lit(" " * 20),
    )
    .otherwise(trim(col("max_city_nm")).substr(1, 20))
    .alias("city_nm"),
    when(
        (trim(col("max_state_abbr")) == "") | (trim(col("max_state_abbr")) == "-"),
        lit(" " * 2),
    )
    .otherwise(trim(col("max_state_abbr")))
    .alias("st"),
    when(
        (trim(col("max_zip_cd")) == "") | (trim(col("max_zip_cd")) == "-"), lit(" " * 5)
    )
    .otherwise(trim(col("max_zip_cd")))
    .alias("zip_cd"),
    lit(" " * 4).alias("zip_4"),
)

lnk_veh_data = lnk_veh_data.orderBy("record_id")

# Applying filter condition
lnk_ems_ds_filtered = lnk_veh_data.filter(
    (col("max_zip_cd") != "00000")
    & (trim(col("max_zip_cd")) != "-")
    & (trim(col("max_zip_cd")) != "")
    & (col("max_zip_cd") != "99999")
    & (trim(col("max_address_tx")) != "")
    & (trim(col("max_address_tx")) != "UNKNOWN")
    & (col("max_last_nm") != "UNKNOWN")
    & (col("max_city_nm") != "UNKNOWN")
    & (trim(col("max_city_nm")) != "")
)

lnk_ems_ds = lnk_ems_ds_filtered.select(
    trim(col("max_last_nm")).alias("max_last_nm"),
    trim(col("max_address_tx")).alias("max_address_tx"),
    trim(col("max_city_nm")).alias("max_city_nm"),
    trim(col("max_state_abbr")).alias("max_state_abbr"),
    trim(col("max_zip_cd")).alias("max_zip_cd"),
    concat(
        col("report_period_yr"),
        lit(":"),
        col("report_period_mm"),
        lit(":"),
        rpad(lit(""), 7, "0"),
        lit(":"),
        rpad(trim(col("record_id")), 7, " "),
    ).alias("SEQ_NO"),
    trim(col("max_first_nm")).substr(1, 20).alias("first_nm"),
    trim(col("max_middle_nm")).substr(1, 20).alias("middle_nm"),
    trim(col("max_last_nm")).substr(1, 35).alias("last_nm"),
    trim(col("max_address_tx")).alias("address_tx"),
    when(
        (trim(col("max_city_nm")) == "") | (trim(col("max_city_nm")) == "-"),
        lit(" " * 20),
    )
    .otherwise(trim(col("max_city_nm")).substr(1, 20))
    .alias("city_nm"),
    when(
        (trim(col("max_state_abbr")) == "") | (trim(col("max_state_abbr")) == "-"),
        lit(" " * 2),
    )
    .otherwise(trim(col("max_state_abbr")))
    .alias("st"),
    when(
        (trim(col("max_zip_cd")) == "") | (trim(col("max_zip_cd")) == "-"), lit(" " * 5)
    )
    .otherwise(trim(col("max_zip_cd")))
    .alias("zip_cd"),
    lit(" " * 4).alias("zip_4"),
    col("svSeqNum"),
    col("vin"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
)

# removing dulpicates
lnk_veh_data2 = lnk_ems_ds.dropDuplicates(
    ["max_last_nm", "max_address_tx", "max_city_nm", "max_zip_cd"]
)

# Apply filter conditions
lnk_used_np_filtered = lnk_veh_data2.filter((col("rpt_bnbu_in") != "N"))

lnk_used_np_filtered1 = lnk_used_np_filtered.filter((col("rpt_bnbu_in") != "U"))

# logging.info(f"Count of lnk_used_np_filtered: {lnk_used_np_filtered1.count()}")
# Persist the DataFrame after filtering
lnk_used_np_filtered1 = lnk_used_np_filtered1.persist()

lnk_used_np = lnk_used_np_filtered1.select(
    col("svSeqNum"),
    col("vin"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
    col("SEQ_NO"),
    col("first_nm"),
    col("middle_nm"),
    col("last_nm"),
    col("address_tx"),
    col("city_nm"),
    col("st"),
    col("zip_cd"),
    col("zip_4"),
)

lnk_veh_data3 = lnk_new_purch.union(lnk_used_np).union(lnk_MC)
lnk_used_np_filtered1.unpersist()

lnk_veh_data3 = lnk_veh_data3.withColumn(
    "SEQ_NO",
    concat(
        col("report_period_yr"),
        col("report_period_mm"),
        lit("0" * 7),
        trim(col("record_id")).substr(-7, 7),
    ),
)

lnk_ems_ds = lnk_veh_data3.select(
    lit(" ").alias("FIRST_NAME"),
    lit(" ").alias("MIDDLE_NAME"),
    lit(" ").alias("LAST_NAME"),
    lit(" ").alias("ADDRESS"),
    lit(" ").alias("CITY_NAME"),
    lit(" ").alias("STATE_ABBR"),
    lit(" ").alias("ZIP"),
    lit(" ").alias("ZIP4"),
    col("SEQ_NO"),
    col("svSeqNum"),
    col("vin"),
    col("record_id"),
    col("vehicle_int_id"),
    col("qa_dmv_resident_int_Id"),
    col("qa_dmv_resident_ty"),
    col("purchase_date"),
    col("qa_dmv_addr_int_id"),
    col("pur_state_abbr"),
    col("max_first_nm"),
    col("max_middle_nm"),
    col("max_last_nm"),
    col("max_address_tx"),
    col("max_city_nm"),
    col("max_state_abbr"),
    col("max_zip_cd"),
    col("vin_pattern"),
    col("current_owner_in"),
    col("report_period_dt"),
    col("rmin_resident_int_id"),
    col("rmin_resident_ty"),
    col("rpt_bnbu_in"),
    col("report_period_yr"),
    col("report_period_mm"),
    col("first_nm"),
    col("middle_nm"),
    col("last_nm"),
    col("address_tx"),
    col("city_nm"),
    col("st"),
    col("zip_cd"),
    col("zip_4"),
)

logging.info("Writing the lnk_ems_ds file to parquet file")
lnk_ems_ds = lnk_ems_ds.coalesce(1)
write_parquet_or_csv(
    df=lnk_ems_ds,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=ds_ems_input_file,
    delimiter=",",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)


lnk_used_cnt_filtered = lnk_veh_data3.filter(col("rpt_bnbu_in") == "U")
lnk_used_cnt = lnk_used_cnt_filtered.withColumn("group", lit(1))
lnk_used_cnt = lnk_used_cnt.select(col("group").cast("integer").alias("group"))

# Aggregation
lnk_half = lnk_used_cnt.groupBy("group").agg(count("*").alias("record_count"))

lnk_output = lnk_half.withColumn("half_count", col("record_count") / 10)
lnk_output = lnk_output.select("half_count")

logging.info("Writing the lnk_output file")
write_parquet_or_csv(
    df=lnk_output,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=sq_used_count_file,
    delimiter="|",
    force_csv=True,
    header=True,
)


logging.info("Writing the lnk_ems_ds file")
write_parquet_or_csv(
    df=lnk_ds_output,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=vehicle_data_all_data_file,
    delimiter=",",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)

logging.info("Writing the lnk_ems_ds file")
write_parquet_or_csv(
    df=lnk_ca_records,
    s3_bucket_and_folder=output_folder,
    local_folder="",
    file_name=ds_fixed_seq_numbers_file,
    delimiter=",",
    force_ignore_parquet=False,
    force_ignore_csv=True,
    force_csv=False,
    header=True,
)
