import json
import logging
import os
import sys
import tempfile
import zipfile

import boto3
import pysftp
from awsglue.utils import getResolvedOptions
from dotenv import load_dotenv
from experianautomotives_amputilities import SftpUtils

# load the environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)  # NOSONAR

last_logged_percent = 0


def load_args():
    args = getResolvedOptions(
        sys.argv,
        [
            "output_bucket_onprem",
            "output_prefix_onprem",
            "environment",
            "operation",
            "sftp_file_name",
            "input_file_path",
            "file_name",
            "secret_name",
        ],
    )
    return args


def upload_directory_to_s3(s3, directory_path, bucket_name, s3_prefix):
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            local_path = os.path.join(str(root), str(file))
            relative_path = os.path.relpath(local_path, directory_path)
            s3_path = os.path.join(str(s3_prefix), str(relative_path))
            s3.upload_file(local_path, bucket_name, s3_path)
            logging.info(f"Uploaded {local_path} to s3://{bucket_name}/{s3_path}")


def copy_zip_file_sftp_to_s3(
    s3,
    output_bucket_onprem,
    output_prefix_onprem,
    sftp_remote_dir,
    sftp_file_name,
    sftp,
    sftp_params,
):  # NOSONAR
    sftp = ensure_sftp_connection(sftp, sftp_params)
    local_zip_path = os.path.join(tempfile.gettempdir(), sftp_file_name)
    local_unzipped_path = None  # Initialize the variable

    try:
        # Download the file from SFTP
        sftp.get(os.path.join(sftp_remote_dir, sftp_file_name), local_zip_path)
        logging.info(f"Downloaded {sftp_file_name} to {local_zip_path}")

        # Unzip the file
        with zipfile.ZipFile(local_zip_path, "r") as zip_ref:
            local_unzipped_path = local_zip_path.replace(".zip", "")
            zip_ref.extractall(local_unzipped_path)
        logging.info(f"Unzipped file to {local_unzipped_path}")

        # Upload the unzipped directory to S3
        upload_directory_to_s3(
            s3, local_unzipped_path, output_bucket_onprem, output_prefix_onprem
        )
    except FileNotFoundError:
        logging.error(f"Unzipped file {local_unzipped_path} not found")
        raise
    except zipfile.BadZipFile:
        logging.error(f"File {local_zip_path} is not a zip file or it is corrupted")
        raise
    except Exception as e:
        logging.error(f"Error uploading file to S3: {e}")
        raise


def progress_callback(transferred, total):
    global last_logged_percent
    percent = (transferred / total) * 100
    if percent - last_logged_percent >= 10:
        last_logged_percent = percent
        logging.info(f"Upload progress: {percent:.2f}%")


def copy_file_from_s3_to_sftp(
    s3, input_file_path, file_name, sftp_remote_dir, sftp, sftp_params
):
    sftp = ensure_sftp_connection(sftp, sftp_params)

    # Extract bucket name and prefix from input_file_path
    bucket_name, s3_prefix = input_file_path.replace("s3://", "").split("/", 1)
    # Create a temporary file to store the downloaded S3 file
    try:
        # List files in the specified S3 bucket and prefix
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=s3_prefix)
        if "Contents" not in response:
            raise FileNotFoundError(f"No files found in S3 path: {input_file_path}")

        # Get the first file in the list
        s3_key = response["Contents"][0]["Key"]
        logging.info(f"Found file in S3: {s3_key}")

        # Create a temporary file to store the downloaded S3 file
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            local_file_path = tmp_file.name

        # Download the file from S3 to the local temporary file
        s3.download_file(bucket_name, s3_key, local_file_path)
        logging.info(f"Downloaded {s3_key} to {local_file_path}")

        # Upload the local file to the SFTP remote directory with the new file name
        sftp.put(
            local_file_path,
            os.path.join(sftp_remote_dir, file_name),
            callback=progress_callback,
        )
        logging.info(f"Uploaded {local_file_path} to {sftp_remote_dir}/{file_name}")
    except Exception as e:
        logging.error(f"Error in transferring file from S3 to SFTP: {e}")
        raise
    finally:
        # Clean up the local temporary file
        try:
            os.remove(local_file_path)
            logging.info(f"Removed temporary file: {local_file_path}")
        except Exception as e:
            logging.error(f"Failed to remove temporary file {local_file_path}: {e}")


def ensure_sftp_connection(sftp, sftp_params):
    """
    Ensures the SFTP connection is active, reconnecting if necessary.

    :param sftp: paramiko.SFTPClient - The SFTP connection.
    :param sftp_params: dict - Parameters for the SFTP connection.
    :return: paramiko.SFTPClient - The active SFTP connection.
    :raises: Exception - If an unexpected error occurs while checking the SFTP connection.
    """
    try:
        sftp.listdir()
        return sftp
    except (AttributeError, IOError, EOFError):
        logging.info("SFTP connection lost. Attempting to reconnect...")
        return connect_sftp(sftp_params)
    except Exception as e:
        logging.error(f"Unexpected error checking SFTP connection: {e}")
        raise


def get_secret(secret_name):
    try:
        client = boto3.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response["SecretString"])
        return secret
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        raise e


def reconnect_sftp(sftp_host, sftp_username, tmp_private_key_path, cnopts):
    try:
        sftp = pysftp.Connection(
            host=sftp_host,
            username=sftp_username,
            private_key=tmp_private_key_path,
            cnopts=cnopts,
        )
        logging.info("Reconnected to SFTP successfully.")
        return sftp  # Return the new SFTP connection
    except Exception as e:
        logging.error(f"Failed to reconnect to SFTP: {e}")
        raise e  # Raise the exception to be caught by the caller


def clear_tmp_file(file_name):
    tmp_dir = tempfile.gettempdir()
    file_path = os.path.join(tmp_dir, file_name)
    try:
        os.remove(file_path)
        logging.info(f"Removed temporary file: {file_name}")
    except FileNotFoundError:
        logging.warning(f"Temporary file not found: {file_name}")
    except Exception as e:
        logging.error(f"Failed to remove temporary file {file_name}: {e}")


def connect_sftp(sftp_params):
    """
    Establishes and returns an SFTP connection.

    :param sftp_params: dict - Parameters for the SFTP connection.
    :return: paramiko.SFTPClient - The SFTP connection.
    """
    logging.info("Establishing SFTP connection")
    utils_instance = SftpUtils.SftpUtils()
    return utils_instance.get_sftp_connection(
        hostname=sftp_params["hostname"],
        username=sftp_params["username"],
        environment=sftp_params["environment"],
        secret_name_map=sftp_params["secret_name_map"],
    )


def prepare_data(env, operation, secret_name):
    """
    Prepare the data for the SFTP connection to remote directory based on the
    environment and operation.

    :param env:
    :param operation:
    :param secret_name
    :return:
    """
    if operation not in ["download", "upload", "delivery"]:
        logging.error("Invalid operation. Please provide a valid operation")
        raise ValueError("Invalid operation. Please provide a valid operation")

    secret = get_secret(secret_name)

    if operation in ["upload"]:
        sftp_remote_dir = secret["inboundfolder"]
    else:
        sftp_remote_dir = secret["outboundfolder"]
    host_name = secret["Server"]
    username = secret["User"]
    secret_name_map = secret["secret_private_key_name"]

    if not sftp_remote_dir:
        raise KeyError(f"Invalid environment or operation: {env}, {operation}")

    logging.info(f"sftp_remote_dir: {sftp_remote_dir}")
    logging.info(f"Default hostname: {host_name}")
    sftp_params = {
        "hostname": host_name,
        "username": username,
        "environment": env,
        "secret_name_map": secret_name_map,
    }

    return (
        sftp_params,
        sftp_remote_dir,
    )


def main():
    logging.info("Starting main process......")
    args = load_args()
    operation = args["operation"]
    env = args["environment"]
    secret_name = args["secret_name"]
    s3 = boto3.client("s3")

    sftp_params, sftp_remote_dir = prepare_data(env, operation, secret_name)

    logging.info(f"Connecting to SFTP server with params: {sftp_params}")

    # Establish SFTP connection
    sftp_conn = connect_sftp(sftp_params)

    try:
        logging.info("Connection Established........")
        if operation == "download":
            copy_zip_file_sftp_to_s3(
                s3,
                args["output_bucket_onprem"],
                args["output_prefix_onprem"],
                f"{sftp_remote_dir}",
                args["sftp_file_name"],
                sftp_conn,
                sftp_params,
            )
        elif operation in ["upload", "delivery"]:
            copy_file_from_s3_to_sftp(
                s3,
                args["input_file_path"],
                args["file_name"],
                f"{sftp_remote_dir}",
                sftp_conn,
                sftp_params,
            )

    except Exception as e:
        logging.error(f"An error occurred: {e}")
        raise e
    finally:
        logging.info("Removed temp path")

        clear_tmp_file(args["sftp_file_name"])


if __name__ == "__main__":
    main()
